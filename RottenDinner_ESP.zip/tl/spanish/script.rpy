﻿# TODO: Translation updated at 2026-11-11 21:31

# game/script.rpy:96
translate spanish start_4a227b63:

    # u "Ugh..."
    u "Ugh..."

# game/script.rpy:98
translate spanish start_0ab4c36a:

    # u "Please stop it. I know perfectly well that it's time to get up. I didn't even go to bed..."
    u "Basta ya. Sé perfectamente que es hora de levantarse. Ni siquiera me acosté..."

# game/script.rpy:99
translate spanish start_44f41e23:

    # u "Ugh, I don't feel very well... Maybe I should stay at home?"
    u "Ugh, no me siento muy bien... ¿Y si me quedo en casa?"

# game/script.rpy:102
translate spanish start_7d23d33d:

    # u "Much better. I couldn't sleep all night again, it was like someone was scratching at my window."
    u "Mucho mejor. Otra vez no pude dormir en toda la noche, era como si alguien arañara mi ventana."

# game/script.rpy:103
translate spanish start_fad9b4bc:

    # u "From fear everything flew out of my head..."
    u "Del miedo se me borró todo de la cabeza..."

# game/script.rpy:111
translate spanish start_5f1bb856:

    # yn "Yeah... I remember now. You ruined my life [name], fuck you."
    yn "Sí... ya me acuerdo. Me arruinaste la vida, [name], vete a la mierda."

# game/script.rpy:112
translate spanish start_7b4812a6:

    # yn "It's Tuesday, right? Ever since school, I remembered this day as somehow drearily dull... Eh."
    yn "Es martes, ¿no? Desde la escuela, recuerdo este día como algo deprimentemente aburrido... Eh."

# game/script.rpy:113
translate spanish start_d8c70983:

    # yn "Another reason to stay home. But if I skip classes again, my head will be torn off."
    yn "Otra razón para quedarme en casa. Pero si vuelvo a faltar a clase, me arrancan la cabeza."

# game/script.rpy:114
translate spanish start_2429ed85:

    # "You rubbed your eyes and got out of bed, muttering unhappily because of the cold floor on which you stood barefoot."
    "Te frotaste los ojos y saliste de la cama, refunfuñando de mala gana por el frío del suelo bajo tus pies descalzos."

# game/script.rpy:115
translate spanish start_33b5b7e3:

    # "This week promises to be boring. Even more ordinary than usual. "
    "Esta semana promete ser aburrida. Aún más corriente de lo habitual. "

# game/script.rpy:116
translate spanish start_a31a3f08:

    # "You started thinking about everything that could have happened today and accidentally got lost in these thoughts. "
    "Empezaste a pensar en todo lo que podría pasar hoy y, sin darte cuenta, te perdiste en esos pensamientos. "

# game/script.rpy:117
translate spanish start_b443a09e:

    # "Finally, you managed to return to reality and you remembered that you used to start the morning with a selection of colorful accessories that seemed cool to you."
    "Por fin lograste volver a la realidad y recordaste que antes empezabas las mañanas eligiendo accesorios coloridos que te parecían geniales."

# game/script.rpy:118
translate spanish start_c5d62b68:

    # "But at university you stopped wearing them, thinking it was too childish."
    "Pero en la universidad dejaste de usarlos, pensando que era demasiado infantil."

# game/script.rpy:119
translate spanish start_b3952cdc:

    # yn "Heh, maybe I should remember the old days. "
    yn "Je, quizá debería recordar los viejos tiempos. "

# game/script.rpy:120
translate spanish start_7cd9e2fd:

    # yn "It was quite fun. I haven't had much left since then... But still, maybe I should wear this pendant today? Oh! I used to love this weird knick-knack. So-o..."
    yn "Era bastante divertido. Desde entonces no me ha quedado mucho... Pero aun así, ¿y si hoy me pongo este colgante? ¡Oh! Me encantaba esta rareza. Así que..."

# game/script.rpy:123
translate spanish start_b39001a4:

    # yn "Awesome. Now I'm definitely a freak. When I wear this thing, I'm incredibly lucky in stupid situations. Something like an amulet of failure. The most it. I'm not some kind of sectarian, honestly..."
    yn "Genial. Ahora sí que soy un bicho raro. Cuando llevo esto, tengo una suerte increíble en situaciones estúpidas. Algo así como un amuleto del fracaso. Lo máximo. No pertenezco a ninguna secta, en serio..."

# game/script.rpy:124
translate spanish start_1c797ce6:

    # yn "Why did I pour my blood here at all?.."
    yn "¿Para qué derramé mi sangre aquí, de todos modos?.."

# game/script.rpy:127
translate spanish start_1d3997ee:

    # "A cup of bitter coffee has already cooled down when you fully packed up and came to drink it. This cheap-ass coffee is really invigorating, but how disgusting it is."
    "La taza de café amargo ya se había enfriado cuando terminaste de arreglarte y fuiste a tomártela. Este café barato despierta de verdad, pero qué asco."

# game/script.rpy:128
translate spanish start_03547703:

    # yn "When I get a job, I'll buy myself a can of normal coffee. No, two cans. I have to spoil myself."
    yn "Cuando consiga trabajo, me compraré una lata de café normal. No, dos latas. Tengo que consentirme."

# game/script.rpy:130
translate spanish start_fdafc74f:

    # "The road to the university in the morning wasn't so terrible, but in the evening you had to look around. And keep a knife in your pocket. This district is really shitty."
    "El camino a la universidad por la mañana no era tan terrible, pero por la noche había que andar con cuidado. Y llevar un cuchillo en el bolsillo. Este barrio es una mierda."

# game/script.rpy:133
translate spanish start_ffa2dc58:

    # "And now, finally, you have come to your institute. The place where you became convinced that some people are rare scum."
    "Y ahora, por fin, llegaste a tu facultad. El lugar donde te convenciste de que algunas personas son escoria de la peor."

# game/script.rpy:134
translate spanish start_ca466594:

    # "Back in high school, you realized that life isn't sugar and it's not a teen show at all."
    "Ya en el instituto te diste cuenta de que la vida no es de color de rosa y de que esto no es una serie juvenil."

# game/script.rpy:135
translate spanish start_497671d8:

    # "That's why there's no group of cool kids or school queen surrounded by her personal maids."
    "Por eso aquí no hay un grupito de populares ni una reina de la escuela rodeada de sus doncellas personales."

# game/script.rpy:136
translate spanish start_27c0ab49:

    # "Everyone here is the same. Tired guys who want to get a college education. Well, it's probably not like that everywhere, you're just l u c k y."
    "Aquí todos son iguales. Gente agotada que solo quiere sacarse un título universitario. Bueno, seguramente no es así en todas partes, simplemente tienes s u e r t e."

# game/script.rpy:137
translate spanish start_040809c8:

    # yn "Don't start the morning so damn pessimistic!"
    yn "¡No empieces la mañana siendo tan condenadamente pesimista!"

# game/script.rpy:138
translate spanish start_9253ff0d:

    # "Still, some are different, though. But they really can't be envied, poor souls become punching bags from day one. "
    "Aun así, algunos son diferentes. Pero no hay por qué envidiarlos: los pobres se vuelven sacos de boxeo desde el primer día. "

# game/script.rpy:139
translate spanish start_30dce424:

    # "Why? Because so. Because the strong can do it to them. «Don't ask unnecessary questions and don't stand out» that's what life has taught you so far. "
    "¿Por qué? Porque sí. Porque los fuertes pueden hacérselo. «No hagas preguntas innecesarias y no destaques»: eso es lo que la vida te ha enseñado hasta ahora. "

# game/script.rpy:141
translate spanish start_6d4746b0:

    # yn "Huh? What happend?"
    yn "¿Eh? ¿Qué pasó?"

# game/script.rpy:142
translate spanish start_7f75edd2:

    # "You were trying to squeeze through the crowd. Is someone being beaten again? This is such a frequent occurrence that everyone had to forget about it and pass by, but..."
    "Intentabas abrirte paso entre la multitud. ¿Otra vez le están pegando a alguien? Es algo tan frecuente que todos tuvieron que acostumbrarse a olvidarlo y pasar de largo, pero..."

# game/script.rpy:143
translate spanish start_6a6c5cfe:

    # "They keep looking. Every time. You know how much the students of this university love the sight and smell of blood."
    "Siguen mirando. Siempre. Sabes cuánto les gusta a los estudiantes de esta universidad el espectáculo y el olor de la sangre."

# game/script.rpy:145
translate spanish start_1196e0f1:

    # "You come closer to see what is happening and swear that you have not joined this indifferent herd, no, you will definitely help. But you'll see first."
    "Te acercas para ver qué pasa y juras que no te has unido a este rebaño indiferente, no, claro que vas a ayudar. Pero primero mirarás."

# game/script.rpy:146
translate spanish start_15b9468f:

    # yn "Oh, I should've known. Hi, Nick."
    yn "Ah, debí imaginarlo. Hola, Nick."

# game/script.rpy:148
translate spanish start_8628a6bf:

    # "You didn't greet him seriously, most likely he hardly heard you at all."
    "No lo saludaste en serio; lo más probable es que apenas te haya oído."

# game/script.rpy:149
translate spanish start_7bc5a127:

    # "Nick is the main victim of this sinister place. His leg was broken on the first day. In the second, the contents of a trash can were poured on his head."
    "Nick es la principal víctima de este siniestro lugar. El primer día le rompieron una pierna. El segundo le vaciaron un bote de basura en la cabeza."

# game/script.rpy:150
translate spanish start_7ffaecda:

    # "And then you didn't remember much else. Just think of any stereotypical bullying in high school and multiply that by two. That's what this guy experienced. "
    "Y después ya no recordabas gran cosa. Piensa en cualquier acoso típico de instituto y multiplícalo por dos. Eso es lo que vivió este chico. "

# game/script.rpy:151
translate spanish start_52f1f3d8:

    # "Why are they bullying him? No one knows. And no one dares to try to find out. Everyone ignores and avoids him, fearing to fall under the hot hand of the main scumbags of the university."
    "¿Por qué lo acosan? Nadie lo sabe. Y nadie se atreve a intentar averiguarlo. Todos lo ignoran y lo evitan, temiendo caer bajo la mano dura de los peores canallas de la universidad."

# game/script.rpy:152
translate spanish start_a93e8554:

    # "And you're one of those people. Weak. Pathetic. Insignificant. But you can't even help yourself, let alone him."
    "Y eres una de esas personas. Débil. Lamentable. Insignificante. Pero ni siquiera puedes ayudarte a ti, mucho menos a él."

# game/script.rpy:153
translate spanish start_1b6afc32:

    # yn "Or maybe... Am I going to do something I'll regret all my life? Yeah this should be interesting."
    yn "¿O quizá... voy a hacer algo de lo que me arrepentiré toda la vida? Sí, esto va a ser interesante."

# game/script.rpy:157
translate spanish start_bbb56389:

    # yn "I'm tired of this. Someone has to sacrifice their ass and stand up for this poor thing."
    yn "Esto me tiene hasta la coronilla. Alguien tiene que jugársela y defender a este pobrecito."

# game/script.rpy:158
translate spanish start_b02575bd:

    # yn "Hey you! Stop it! In the end, leave him alone, this guy is already bleeding. For the second day in a row, and today is only Tuesday."
    yn "¡Eh, ustedes! ¡Paren ya! Déjenlo en paz de una vez, este tipo ya está sangrando. Dos días seguidos, y hoy apenas es martes."

# game/script.rpy:159
translate spanish start_e4a9f869:

    # yn "If you want to make fun of someone, then choose not the weakest of all."
    yn "Si quieren burlarse de alguien, no elijan al más débil de todos."

# game/script.rpy:160
translate spanish start_1f40a800:

    # "Everyone looked at you in horror. Someone from behind started laughing and whispering something like «Damn, dude, did you hear that? [name] is going to leave here in an ambulance right now.»"
    "Todos te miraron horrorizados. Alguien por detrás empezó a reír y a susurrar algo como «Carajo, ¿oíste eso? [name] va a salir de aquí en ambulancia ahora mismo.»"

# game/script.rpy:161
translate spanish start_7d9543d0:

    # b1 "Are you serious? I would laugh, but this act is so stupid that it's not even funny."
    b1 "¿Hablas en serio? Me reiría, pero esta estupidez ni siquiera da risa."

# game/script.rpy:162
translate spanish start_adc7ad73:

    # b2 "Leave while you can, freak. Can't you see we're having fun? Or do you want to join in?"
    b2 "Vete mientras puedas, bicho raro. ¿No ves que nos estamos divirtiendo? ¿O quieres unirte?"

# game/script.rpy:163
translate spanish start_f230d40d:

    # b1 "Yeah, but I don't think that you're going to be as resilient as that jerk."
    b1 "Sí, aunque dudo que aguantes tanto como ese idiota."

# game/script.rpy:164
translate spanish start_3ff4ee72:

    # "They're not kidding. And you know it. But some strange shiver went through your body. It seems like it was your masochistic tendencies."
    "No bromean. Y lo sabes. Pero un extraño escalofrío te recorrió el cuerpo. Parece que fueron tus tendencias masoquistas."

# game/script.rpy:165
translate spanish start_b7c0211d:

    # yn "Oh God-"
    yn "Ay, Dios..."

# game/script.rpy:169
translate spanish start_4209189e:

    # "You grabbed the bloody guy by the arm and pulled him out of the bullies midst. Despite his wounds, he ran fast."
    "Agarraste al chico ensangrentado del brazo y lo sacaste de en medio de los matones. A pesar de sus heridas, corrió rápido."

# game/script.rpy:172
translate spanish start_4d7da6f3:

    # "You ran like two rabbits being chased by hunters. Fear was running through your fingertips. There was no time to think about your stupidest act. Now you had to get out of here as fast as possible."
    "Corriste como dos conejos perseguidos por cazadores. El miedo te recorría las yemas de los dedos. No había tiempo de pensar en tu acto más estúpido. Ahora había que salir de allí lo más rápido posible."

# game/script.rpy:173
translate spanish start_e5a521e7:

    # "The corridors and stairs seemed endlessly long, as if there was no way out of this terrible place."
    "Los pasillos y las escaleras parecían interminables, como si no hubiera salida de este terrible lugar."

# game/script.rpy:176
translate spanish start_e30d954e:

    # b2 "{sc}I'LL CATCH UP WITH YOU AND RIP YOUR HEADS OFF!!!{/sc}"
    b2 "{sc}¡¡¡LOS ALCANZARÉ Y LES ARRANCARÉ LA CABEZA!!!{/sc}"

# game/script.rpy:178
translate spanish start_058b4ccb:

    # "You finally managed to quickly turn the corner and disappear from the sight of the thugs."
    "Por fin lograste doblar la esquina a toda prisa y desaparecer de la vista de los matones."

# game/script.rpy:181
translate spanish start_3326ca47:

    # "You didn't even look around the room you were in, because you fell to the floor and tried to catch your breath after all that running."
    "Ni siquiera miraste la sala en la que estabas, porque caíste al suelo e intentaste recuperar el aliento después de tanto correr."

# game/script.rpy:183
translate spanish start_c4160a60:

    # "The fact that you are still alive is a miracle. Now you have time to think about your idiotic act."
    "Que sigas con vida es un milagro. Ahora tienes tiempo de pensar en tu idiotez."

# game/script.rpy:185
translate spanish start_8d03c5dc:

    # yn "«For what? Why did I save him? It's not like we're friends, I just know his name because in my social circle I often like to mention shit that happens to this guy»"
    yn "«¿Para qué? ¿Por qué lo salvé? No es que seamos amigos, solo sé su nombre porque en mi círculo me gusta comentar las mierdas que le pasan a este chico»"

# game/script.rpy:186
translate spanish start_501d0249:

    # yn "«I didn't even know what he looked like, I just guessed»"
    yn "«Ni siquiera sabía cómo era, solo lo adiviné»"

# game/script.rpy:187
translate spanish start_3c62025a:

    # n "Hey, thank you..."
    n "Oye, gracias..."

# game/script.rpy:190
translate spanish start_4cc159fd:

    # "The guy squatted down in front of you. His bangs completely covered his eyes, you could see only the neat smile. Blood smeared all over his face, also staining white shirt."
    "El chico se agachó frente a ti. El flequillo le cubría por completo los ojos; solo se veía su sonrisa pulcra. La sangre le manchaba toda la cara y también la camisa blanca."

# game/script.rpy:191
translate spanish start_f8699540:

    # yn "Oh, so that's what you look like."
    yn "Ah, así que así eres."

# game/script.rpy:195
translate spanish start_4bf6386a:

    # n "You saved me without even knowing who I am? This situation has become a thousand times nicer."
    n "¿Me salvaste sin siquiera saber quién soy? Esta situación se ha vuelto mil veces más agradable."

# game/script.rpy:198
translate spanish start_f61facbb:

    # "Nick laughed very sweetly. His cheeks turned a little pink."
    "Nick rio con mucha dulzura. Sus mejillas se sonrojaron un poco."

# game/script.rpy:199
translate spanish start_970870cc:

    # yn "Yes, it was s really very nice of me... Argh, you didn't do anything to them, why would they do that to you? It annoys me just to think about it!"
    yn "Sí, fue muy amable de mi parte... ¡Argh, no les hiciste nada, ¿por qué te harían eso?! ¡Me irrita solo pensarlo!"

# game/script.rpy:203
translate spanish start_9a7c3dad:

    # n "I don't know. Maybe I'm just too pathetic? Anyway, let them do what they want."
    n "No lo sé. ¿Quizá soy demasiado patético? En fin, que hagan lo que quieran."

# game/script.rpy:204
translate spanish start_329ca9b4:

    # yn "What?! They literally beat you to a pulp! Do you want to die or something? I would have chosen a quicker and less painful way."
    yn "¡¿Qué?! ¡Te dejaron hecho puré! ¿Quieres morir o qué? Yo habría elegido un modo más rápido e indoloro."

# game/script.rpy:207
translate spanish start_ac594fe9:

    # "Nick laughed quietly again."
    "Nick volvió a reír en voz baja."

# game/script.rpy:208
translate spanish start_bc853dda:

    # n "I have to check something. Don't worry, as soon as I'm done, it'll stop..."
    n "Tengo que comprobar algo. No te preocupes, en cuanto termine, se detendrá..."

# game/script.rpy:209
translate spanish start_57d28520:

    # yn "What do you want to know? The limits of the human body or how quickly they'll kill you?"
    yn "¿Qué quieres saber? ¿Los límites del cuerpo humano o qué tan rápido te matan?"

# game/script.rpy:212
translate spanish start_83042bc1:

    # n "{cps=260}I'm just amused by your compassion for me. I'm literally going to kill and eat you and you know it perfectly well. Ah, poor me!{w=0.2}{nw}"
    n "{cps=260}Me divierte tu compasión hacia mí. Literalmente voy a matarte y comerte, y lo sabes perfectamente. ¡Ay, pobre de mí!{w=0.2}{nw}"

# game/script.rpy:213
translate spanish start_eaf9d10a:

    # yn "What?"
    yn "¿Qué?"

# game/script.rpy:214
translate spanish start_3493c308:

    # n "Don't worry, I'll be fine, I promise!"
    n "No te preocupes, estaré bien, ¡lo prometo!"

# game/script.rpy:218
translate spanish start_48784317:

    # n "That`s exactly what I said."
    n "Eso es exactamente lo que dije."

# game/script.rpy:219
translate spanish start_e7ec7a54:

    # yn "Okay... There's nothing I can do to interfere with your, uh, experiments. And it's none of my buisness, to be honest."
    yn "Está bien... No hay nada que yo pueda hacer para interferir con tus, eh, experimentos. Y la verdad es que no es asunto mío."

# game/script.rpy:220
translate spanish start_251de250:

    # "His whole image seems to look so defenseless that you can't help but feel pity for this guy, even though he obviosly doesn't need it."
    "Toda su imagen parece tan indefensa que no puedes evitar sentir lástima por este chico, aunque es obvio que no la necesita."

# game/script.rpy:224
translate spanish start_534abf6c:

    # n "To be honest, I don't feel any pain. But the humiliation... hurts me a little."
    n "Para ser sincero, no siento ningún dolor. Pero la humillación... me duele un poco."

# game/script.rpy:225
translate spanish start_bbe8e531:

    # yn "Hm? Are you analgesic?"
    yn "¿Hm? ¿Eres insensible al dolor?"

# game/script.rpy:226
translate spanish start_86264d51:

    # n "Yeah. I don't feel anything. Almost. But honestly..."
    n "Sí. No siento nada. Casi. Pero la verdad..."

# game/script.rpy:230
translate spanish start_1a4d369b:

    # n "...That disease only took away my sensitivity. But I can still smell things. Like the beautiful smell..."
    n "...Esa enfermedad solo me quitó la sensibilidad. Pero todavía puedo oler. Como ese hermoso olor a..."

# game/script.rpy:231
translate spanish start_cdb7b5dd:

    # yn "Um... Of flowers?"
    yn "Eh... ¿Flores?"

# game/script.rpy:232
translate spanish start_95b1442f:

    # n "Blood."
    n "Sangre."

# game/script.rpy:233
translate spanish start_61f3c6da:

    # yn "Uh, okay. This smell is kind of cool. Probably. "
    yn "Ah, está bien. Ese olor tiene su encanto. Probablemente. "

# game/script.rpy:234
translate spanish start_38e282b6:

    # "You tried to pick up some more words, but this conversation seemed to have reached a dead end. "
    "Intentaste encontrar más palabras, pero la conversación parecía haber llegado a un callejón sin salida. "

# game/script.rpy:235
translate spanish start_000ee2ad:

    # n "{cps=250}{sc}Your blood, stupid. I want to eat you, I want to taste every bite and chew it with your sweet blood. God, the thought of it is driving me crazy!{/sc}{w=0.1}{nw}"
    n "{cps=250}{sc}Tu sangre, idiota. Quiero comerte, quiero saborear cada bocado y masticarlo con tu dulce sangre. Dios, ¡pensarlo me está enloqueciendo!{/sc}{w=0.1}{nw}"

# game/script.rpy:236
translate spanish start_eda29cd7:

    # yn "«What was that? He's mumbling something unintelligible and quiet again, I can't make out a single word»"
    yn "«¿Qué fue eso? Otra vez murmura algo ininteligible y en voz baja, no logro entender ni una palabra»"

# game/script.rpy:237
translate spanish start_6901ae1c:

    # yn "Yeah, yeah. You know, I'm gonna go, I still have to save my ass from these guys who obviously hate me now. "
    yn "Sí, sí. Oye, me voy, todavía tengo que salvar mi pellejo de esos tipos que seguro me odian ahora. "

# game/script.rpy:238
translate spanish start_e765d762:

    # yn "It wouldn't have happened if I hadn't saved you... Oh, no! It's not that I regret doing it, I just don't understand WHY I did it!"
    yn "Nada de esto habría pasado si no te hubiera salvado... ¡Ay, no! No es que me arrepienta de haberlo hecho, ¡solo que no entiendo POR QUÉ lo hice!"

# game/script.rpy:239
translate spanish start_c52033aa:

    # yn "God, I'd better shut up. "
    yn "Dios, mejor me callo. "

# game/script.rpy:242
translate spanish start_e28b49a3:

    # n "Oh, I'm sorry for setting you up. And don't worry, I just thank you for saving me."
    n "Oh, perdona por haberte metido en problemas. Y no te preocupes, solo te agradezco que me salvaras."

# game/script.rpy:245
translate spanish start_e9512bc9:

    # n "You know, you're so... c-cute and charming, [name]. "
    n "Sabes, tienes tanto... e-encanto, [name]. "

# game/script.rpy:246
translate spanish start_750e4629:

    # n "No one has ever said such warm words to me..."
    n "Nadie me había dicho nunca palabras tan cálidas..."

# game/script.rpy:247
translate spanish start_2aec6112:

    # yn "You're flattering me, haha! It was definitely not your fault, so don't apologize.{w=0.2}{nw}"
    yn "¡Me halagas, jaja! Definitivamente no fue tu culpa, así que no te disculpes.{w=0.2}{nw}"

# game/script.rpy:248
translate spanish start_ea186625:

    # yn "Wait, you know me? We've never crossed paths in our lives. Literally never, because I'm studying in a different building."
    yn "Espera, ¿tú me conoces? Nunca nos hemos cruzado en la vida. Literalmente nunca, porque yo estudio en otro edificio."

# game/script.rpy:252
translate spanish start_9ab4c079:

    # n "Huh... I said too much again."
    n "Vaya... Volví a hablar de más."

# game/script.rpy:253
translate spanish start_ed375113:

    # yn "{sc}What the... What the fuck is wrong with your face?..{/sc}"
    yn "{sc}¿Qué... qué carajo le pasa a tu cara?...{/sc}"

# game/script.rpy:254
translate spanish start_f03aaa74:

    # n " "
    n " "

# game/script.rpy:255
translate spanish start_71d0ffdd:

    # yn "{sc}WHERE IS IT?!{/sc}"
    yn "{sc}¡¿DÓNDE ESTÁ?!{/sc}"

# game/script.rpy:256
translate spanish start_f03aaa74_1:

    # n " "
    n " "

# game/script.rpy:257
translate spanish start_3a82b975:

    # n "{cps=10} {sc}I`m so sorry.{/sc}{/cps}"
    n "{cps=10} {sc}Lo siento mucho.{/sc}{/cps}"

# game/script.rpy:258
translate spanish start_4fec9538:

    # n "{cps=10} {sc}I got a little overexcited.{/sc} {/cps}"
    n "{cps=10} {sc}Me emocioné un poco de más.{/sc} {/cps}"

# game/script.rpy:262
translate spanish start_a095b462:

    # n "Better?{w=0.5}{nw}"
    n "¿Mejor?{w=0.5}{nw}"

# game/script.rpy:269
translate spanish start_e742bd42:

    # yn "What a crazy day... "
    yn "Qué día tan loco... "

# game/script.rpy:270
translate spanish start_736c8414:

    # yn "I'm glad Nick is alive and doesn't look like he just got beaten up by three huge guys. I wonder why he thanked me and just left?"
    yn "Me alegra que Nick esté vivo y que no parezca que acaban de golpearlo tres tipos enormes. ¿Por qué me daría las gracias y se iría sin más?"

# game/script.rpy:271
translate spanish start_7e9d676a:

    # yn "He turned out to be shyer than I thought. I don't blame him, after all, he had been bullied for so long."
    yn "Resultó ser más tímido de lo que pensaba. No se lo reprocho, después de todo, lo han acosado durante tanto tiempo."

# game/script.rpy:272
translate spanish start_1de9522e:

    # "The lectures came to an end, you managed to survive and your body was not yet sick by the end of the day, but right now the anxiety was almost knocking you off your feet."
    "Las clases terminaron, lograste sobrevivir y tu cuerpo aún no se había enfermado al final del día, pero ahora mismo la ansiedad casi te tumbaba."

# game/script.rpy:273
translate spanish start_3670acb1:

    # "These streets have always frightened you, but right now every step you took seemed full of danger. And every rustle made you jump with fear."
    "Estas calles siempre te han asustado, pero ahora cada paso te parecía lleno de peligro. Y cada ruido te hacía saltar de miedo."

# game/script.rpy:274
translate spanish start_87af1c15:

    # yn "Am I that bored with my life? Why did I ever get into this? And now I'm shaking a hundred times more. Maybe I wanted to be intimidated..."
    yn "¿Tanto me aburre mi vida? ¿Por qué me metí en esto? Y ahora tiemblo cien veces más. Quizá quería que me intimidaran..."

# game/script.rpy:275
translate spanish start_1a5244f7:

    # yn "I should change the lock on my door again..."
    yn "Debería cambiar otra vez la cerradura de mi puerta..."

# game/script.rpy:276
translate spanish start_265697fc:

    # "You've come to a bend, it's still a long way to your house, and that part of the road has always scared you. You constantly felt like you could hear someone following you."
    "Llegaste a una curva, todavía queda mucho para tu casa, y ese tramo del camino siempre te ha dado miedo. Siempre sentías que oías a alguien siguiéndote."

# game/script.rpy:277
translate spanish start_131f292b:

    # "And right now, there was the rustling of clothes. Maybe it's just your imagination that's running wild because of the adrenaline rush."
    "Y ahora mismo se oyó un roce de ropa. Quizá es solo tu imaginación desbocada por la descarga de adrenalina."

# game/script.rpy:278
translate spanish start_8a2fd020:

    # "But you want to get out of here as soon as possible."
    "Pero quieres salir de aquí cuanto antes."

# game/script.rpy:279
translate spanish start_05fe24b2:

    # yn "Maybe I should turn around quietly and try to get out of here. But if I don't hurry, they might attack from behind."
    yn "Quizá debería girarme en silencio e intentar salir de aquí. Pero si no me apuro, podrían atacar por la espalda."

# game/script.rpy:280
translate spanish start_e3ba243d:

    # yn "{sc}IF THERE'S ANYONE THERE AT ALL! WHY AM I MAKING MYSELF PANIC?!{/sc}"
    yn "{sc}¡SI ES QUE HAY ALGUIEN AHÍ! ¡¿POR QUÉ ME ESTOY HACIENDO ENTRAR EN PÁNICO?!{/sc}"

# game/script.rpy:283
translate spanish start_77ce79ed:

    # yn "SCREW IT. I`M GOING HOME."
    yn "A LA MIERDA. ME VOY A CASA."

# game/script.rpy:285
translate spanish start_76e50bee:

    # "You run as fast as you can so you don't stop for a second near a dark alley."
    "Corres lo más rápido que puedes para no detenerte ni un segundo cerca de un callejón oscuro."

# game/script.rpy:286
translate spanish start_61707b16:

    # yn "Ugh, I actually... can't... running... that... fast."
    yn "Ugh, en realidad... no... puedo... correr... tan... rápido."

# game/script.rpy:288
translate spanish start_68f4d571:

    # b1 "DAMN! [name] IS RUNNING AWAY!"
    b1 "¡MALDITA SEA! ¡[name] SE ESTÁ ESCAPANDO!"

# game/script.rpy:289
translate spanish start_b94dd483:

    # "These words echo in your head. So it wasn't paranoia; you were really being waited on."
    "Esas palabras resuenan en tu cabeza. Así que no era paranoia; de verdad te estaban esperando."

# game/script.rpy:291
translate spanish start_d97a9a90:

    # "And they catch up with you."
    "Y te alcanzan."

# game/script.rpy:292
translate spanish start_6b88370e:

    # "There was a taste of blood in your mouth and your lungs are on fire. No. No. No."
    "Había un sabor a sangre en tu boca y tus pulmones arden. No. No. No."

# game/script.rpy:293
translate spanish start_2221d110:

    # "{sc}NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO{/sc}"
    "{sc}NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO NO{/sc}"

# game/script.rpy:297
translate spanish start_37a74593:

    # "Everything around you no longer had outlines, only darkness and someone's inarticulate curses somewhere high above your defenseless body on the wet sidewalk."
    "Todo a tu alrededor ya no tenía contornos, solo oscuridad y las maldiciones ininteligibles de alguien en lo alto, sobre tu cuerpo indefenso en la acera mojada."

# game/script.rpy:298
translate spanish start_e6589be4:

    # "You feel someone roughly flipping you onto your back. There were no blows, but you can already smell blood."
    "Sientes que alguien te da la vuelta bruscamente. No hubo golpes, pero ya hueles a sangre."

# game/script.rpy:302
translate spanish start_5d544010:

    # "Is that your nose bleeding? Is it a head wound? Is it bleeding from your ears?"
    "¿Es tu nariz la que sangra? ¿Una herida en la cabeza? ¿Te sangran los oídos?"

# game/script.rpy:303
translate spanish start_e6b9d6a8:

    # yn "Oh... My necklace."
    yn "Oh... Mi collar."

# game/script.rpy:304
translate spanish start_1c897626:

    # "You feel like you can feel splinters digging into your neck. The rotten blood from the necklace has stained you, and fresh blood has been added to it, oozing out of small but deep wounds."
    "Sientes como si te clavaran astillas en el cuello. La sangre podrida del collar te ha manchado, y se le ha sumado sangre fresca que brota de heridas pequeñas pero profundas."

# game/script.rpy:305
translate spanish start_c0f99592:

    # yn "«Oh my God, I can't see a fucking thing. But I can already feel the pain coming on»"
    yn "«Dios mío, no veo una mierda. Pero ya siento que viene el dolor»"

# game/script.rpy:306
translate spanish start_f8dece41:

    # "A wave of hot, throbbing pain slowly ran through your body. It felt like someone had stabbed you. Not deep, but obviously painful."
    "Una ola de dolor caliente y palpitante recorrió lentamente tu cuerpo. Se sentía como si te hubieran apuñalado. No muy hondo, pero evidentemente doloroso."

# game/script.rpy:307
translate spanish start_5d4f560b:

    # "You heard disgusted laughter and felt one of them roughly grab you by the hair."
    "Oíste risas repugnantes y sentiste que uno de ellos te agarraba bruscamente del pelo."

# game/script.rpy:308
translate spanish start_4b8bba52:

    # yn "Please let me go... Please..."
    yn "Por favor, suéltenme... Por favor..."

# game/script.rpy:309
translate spanish start_9f0843f8:

    # "You whispered so softly that hardly anyone could hear you. There was an upstairs commotion, as if the bastards were arguing."
    "Susurraste tan bajito que apenas alguien pudo oírte. Hubo un alboroto arriba, como si los bastardos estuvieran discutiendo."

# game/script.rpy:311
translate spanish start_80bac794:

    # "The tears began to flow. You squeezed your eyes shut. The screams got louder and louder, and then suddenly stopped."
    "Empezaron a brotar las lágrimas. Apretaste los ojos. Los gritos se hicieron cada vez más fuertes y, de pronto, cesaron."

# game/script.rpy:315
translate spanish start_69164057:

    # "The silence was cut by the disgusting sound of a knife rapidly entering someone's body."
    "El silencio fue cortado por el repugnante sonido de un cuchillo penetrando rápidamente en un cuerpo."

# game/script.rpy:317
translate spanish start_d8210727:

    # "{cps=10}But you didn't feel any pain."
    "{cps=10}Pero no sentiste ningún dolor."

# game/script.rpy:319
translate spanish start_c68ea965:

    # "You heard someone fall right in front of you. The smell of fresh blood hit your nose."
    "Oíste caer a alguien justo frente a ti. El olor a sangre fresca te golpeó la nariz."

# game/script.rpy:320
translate spanish start_39201ec3:

    # "You know very well how disgusting knife wounds smell, and now it stinks all over the place. But it wasn't just blood."
    "Sabes muy bien cómo huelen las heridas de cuchillo, y ahora el hedor llena todo el lugar. Pero no era solo sangre."

# game/script.rpy:321
translate spanish start_40e5d801:

    # "{cps=10}It was death."
    "{cps=10}Era muerte."

# game/script.rpy:322
translate spanish start_6b2cac90:

    # "{cps=10}You remembered perfectly well that smell of dead bodies from the morgues. "
    "{cps=10}Recordabas perfectamente ese olor a cadáveres de las morgues. "

# game/script.rpy:325
translate spanish start_7b95a0be:

    # "{cps=10}Only after the next sound of the knife, sharply severing the flesh, you realize that there is only one living person near you."
    "{cps=10}Solo después del siguiente sonido del cuchillo, cortando la carne con brusquedad, te das cuenta de que a tu lado solo queda una persona viva."

# game/script.rpy:326
translate spanish start_7f9a7594:

    # "{cps=10}{sc}And two corpses.{/sc}"
    "{cps=10}{sc}Y dos cadáveres.{/sc}"

# game/script.rpy:327
translate spanish start_d8e7d834:

    # "Your breathing hitched, no matter how hard you tried to pretend to faint, you failed."
    "Se te cortó la respiración; por más que intentaste fingir un desmayo, no lo conseguiste."

# game/script.rpy:329
translate spanish start_579dc013:

    # "The killer of the two thugs did not leave their bodies alone, relentlessly thrusting his blade into the guys, who were already definitely dead."
    "El asesino de los dos matones no dejó en paz sus cuerpos y siguió hundiendo implacablemente su hoja en esos tipos, que ya estaban definitivamente muertos."

# game/script.rpy:330
translate spanish start_0935a23c:

    # "They seem to enjoy it."
    "Parece que lo disfruta."

# game/script.rpy:331
translate spanish start_207d15d7:

    # "And honestly, you're not as scared to hear a person ripping their belly open..."
    "Y la verdad es que no te asusta tanto oír cómo alguien se abre el vientre..."

# game/script.rpy:332
translate spanish start_37a2f5ed:

    # "{cps=15}{sc}...as you are to hear that they're stopped.{/sc}"
    "{cps=15}{sc}...como oír que se ha detenido.{/sc}"

# game/script.rpy:333
translate spanish start_0f7542cc:

    # "In the silence there was a rustling of clothes next to you, echoing in your head. Someone grabbed your shoulder and started to lift you up."
    "En el silencio, un roce de ropa a tu lado resonó en tu cabeza. Alguien te agarró del hombro y empezó a levantarte."

# game/script.rpy:334
translate spanish start_f1748bdb:

    # "There was no strength to scream, you began to feel like you were losing consciousness, but the hope of survival made you perk up."
    "No tenías fuerzas para gritar, empezaste a sentir que perdías la consciencia, pero la esperanza de sobrevivir te reanimó."

# game/script.rpy:338
translate spanish start_2cfa4413:

    # "It didn't make any sense. Whether he killed you now or caught up with you and stabbed you in the back, you would die anyway. "
    "No tenía sentido. Ya fuera que te matara ahora o te alcanzara y te apuñalara por la espalda, morirías de todos modos. "

# game/script.rpy:339
translate spanish start_1c639c81:

    # "You began to choke back tears, the killer finally lifted you off the ground and just as you were about to be stabbed in the stomach with a blade, but... "
    "Empezaste a contener las lágrimas, el asesino por fin te levantó del suelo y justo cuando ibas a recibir la hoja en el estómago, pero... "

# game/script.rpy:340
translate spanish start_6b85a4da:

    # "They... pressed you against them? "
    "¿Te... estrechó contra sí? "

# game/script.rpy:341
translate spanish start_0d74b3ad:

    # "You could definitely feel the warmth of a human body and clearly hear someone else's heartbeat. The whole thing started to drive you crazy, and you finally fainted. "
    "Podías sentir claramente el calor de un cuerpo humano y oír con nitidez el latido de un corazón ajeno. Todo aquello empezó a enloquecerte, y por fin te desmayaste. "

# game/script.rpy:345
translate spanish start_73ff6995:

    # yn "..."
    yn "..."

# game/script.rpy:346
translate spanish start_39dc25eb:

    # "You heard the familiar disgusting sound of the alarm clock. "
    "Oíste el familiar y repugnante sonido del despertador. "

# game/script.rpy:350
translate spanish start_229d17da:

    # yn "{sc}I don't want to open my eyes.{/sc}"
    yn "{sc}No quiero abrir los ojos.{/sc}"

# game/script.rpy:351
translate spanish start_e398d2ba:

    # "You were able to see your room. Was it a crappy dream? "
    "Pudiste ver tu habitación. ¿Había sido un sueño de mierda? "

# game/script.rpy:353
translate spanish start_e55a7ae7:

    # "You touched your clavicles. There were small, deep cuts, already covered by a thin crust. "
    "Te tocaste las clavículas. Había pequeños cortes profundos, ya cubiertos por una fina costra. "

# game/script.rpy:354
translate spanish start_06451a83:

    # "Your hands were shaking. "
    "Te temblaban las manos. "

# game/script.rpy:355
translate spanish start_10f2d59f:

    # yn "I need to get up... I NEED TO GET UP."
    yn "Tengo que levantarme... TENGO QUE LEVANTARME."

# game/script.rpy:358
translate spanish start_c11308b9:

    # "You jumped off the bed abruptly and felt a disgusting weakness in your legs, which immediately caused you to fall to your knees. "
    "Saltaste de la cama de golpe y sentiste una repugnante debilidad en las piernas, que enseguida te hizo caer de rodillas. "

# game/script.rpy:360
translate spanish start_58f71b2d:

    # "You could feel yourself starting to choke. "
    "Sentías que empezabas a ahogarte. "

# game/script.rpy:361
translate spanish start_804520cf:

    # "Everything in front of eyes was disgustingly floating. "
    "Todo frente a tus ojos flotaba de forma repugnante. "

# game/script.rpy:362
translate spanish start_9ce893ac:

    # "Fear was pervasive. You remembered everything you had smelled and heard that day. The memories made you burst into tears of fear. "
    "El miedo lo impregnaba todo. Recordaste todo lo que habías olido y oído ese día. Los recuerdos te hicieron romper en lágrimas de miedo. "

# game/script.rpy:364
translate spanish start_14201874:

    # "You couldn't stop wheezing and trying to scream. Why are you still alive? What's going to happen to you? Who was that? Why did they do this? "
    "No podías dejar de jadear ni de intentar gritar. ¿Por qué sigues con vida? ¿Qué te va a pasar? ¿Quién era? ¿Por qué hicieron esto? "

# game/script.rpy:366
translate spanish start_5a05dfe8:

    # "You tried to put your thoughts in order, even though you were shaking like a fever. You remembered how you were once taught to breathe during a panic attack. "
    "Intentaste ordenar tus pensamientos, aunque temblabas como con fiebre. Recordaste cómo te enseñaron una vez a respirar durante un ataque de pánico. "

# game/script.rpy:368
translate spanish start_47c7d26a:

    # "You closed your eyes and tried to distract yourself so you wouldn't start sobbing and panting again. Experiencing too much has always been difficult for you. "
    "Cerraste los ojos e intentaste distraerte para no volver a sollozar y jadear. Sentir demasiado siempre te ha costado. "

# game/script.rpy:369
translate spanish start_994d4524:

    # "{cps=15}{sc}. . .{/sc}"
    "{cps=15}{sc}. . .{/sc}"

# game/script.rpy:370
translate spanish start_994d4524_1:

    # "{cps=15}{sc}. . .{/sc}"
    "{cps=15}{sc}. . .{/sc}"

# game/script.rpy:371
translate spanish start_994d4524_2:

    # "{cps=15}{sc}. . .{/sc}"
    "{cps=15}{sc}. . .{/sc}"

# game/script.rpy:372
translate spanish start_2d3ca500:

    # "After a few minutes, you could finally think more soberly, but your strength had completely left your body. "
    "Pasados unos minutos, por fin pudiste pensar con más calma, pero las fuerzas habían abandonado por completo tu cuerpo. "

# game/script.rpy:375
translate spanish start_3814d3c6:

    # yn "I can't lie here forever. I have to go to the police, and we'll find out what it was... "
    yn "No puedo quedarme en el suelo para siempre. Tengo que ir a la policía y averiguaremos qué fue eso... "

# game/script.rpy:376
translate spanish start_c77be0e5:

    # "You stroked your shoulders and felt the wounds left by your fingernails. "
    "Te acariciaste los hombros y sentiste las heridas que dejaron tus uñas. "

# game/script.rpy:377
translate spanish start_db37bd05:

    # "You got up off the floor and examined yourself for handcuffs, ropes, and crap like that, but obviously no one had kidnapped you or even tied you up. "
    "Te levantaste del suelo y te revisaste en busca de esposas, cuerdas y esas cosas, pero era evidente que nadie te había secuestrado ni siquiera atado. "

# game/script.rpy:378
translate spanish start_dfc5b76a:

    # "But then something came to you. "
    "Pero entonces algo se te vino a la mente. "

# game/script.rpy:379
translate spanish start_5575a960:

    # yn "{cps=15}{sc}This person knew where I live.{/sc}"
    yn "{cps=15}{sc}Esa persona sabía dónde vivo.{/sc}"

# game/script.rpy:382
translate spanish start_726afdd1:

    # "Before you knew it, you were tearing out of your room as fast as you could, everything in front of your eyes seemed to lose its contours."
    "Antes de darte cuenta, ya salías de tu habitación como una bala, a toda velocidad, y todo frente a tus ojos parecía perder sus contornos."

# game/script.rpy:383
translate spanish start_ecd41786:

    # "If they brought you here, chances are the killer is still in your house. "
    "Si te trajeron aquí, lo más probable es que el asesino siga en tu casa. "

# game/script.rpy:384
translate spanish start_b02c548c:

    # "The icy horror made your mind go blank."
    "El horror helado te dejó la mente en blanco."

# game/script.rpy:385
translate spanish start_f049741a:

    # "You almost ran out into the street when someone blocked your way. "
    "Casi saliste corriendo a la calle cuando alguien te cerró el paso. "

# game/script.rpy:386
translate spanish start_8bc2b9af:

    # "Out of fright you screamed and hit the man in front of you as hard as you could. "
    "Del susto gritaste y golpeaste con todas tus fuerzas al hombre que tenías enfrente. "

# game/script.rpy:388
translate spanish start_4b22578e:

    # "But you were grabbed by the shoulders and stopped where you were. "
    "Pero te agarraron por los hombros y te detuvieron en seco. "

# game/script.rpy:391
translate spanish start_05b7a91a:

    # n "Ugh, [name], that hurt... Probably.{w=0.3}{nw}"
    n "Ugh, [name], eso dolió... Probablemente.{w=0.3}{nw}"

# game/script.rpy:393
translate spanish start_a0877c53:

    # yn "{sc}GODDAM NICK! YOU ARE TOTALLY OUT OF TIME!{/sc}"
    yn "{sc}¡MALDITO NICK! ¡NO ES EL MOMENTO!{/sc}"

# game/script.rpy:394
translate spanish start_984b39ac:

    # yn "GET OUT OF THE WAY!"
    yn "¡QUÍTATE DE EN MEDIO!"

# game/script.rpy:395
translate spanish start_71a9e3fa:

    # "You didn't even try to control your voice and yelled it right in the guy's face. "
    "Ni siquiera intentaste controlar la voz y se lo gritaste en plena cara al chico. "

# game/script.rpy:398
translate spanish start_17dffe2f:

    # n "Oh God, [name], I'm sorry! Did something happen? You look so scared... "
    n "Oh, Dios, ¡[name], perdón! ¿Pasó algo? Se te nota el miedo en la cara... "

# game/script.rpy:399
translate spanish start_f2289cf0:

    # "In truth, Nick's voice brought you to your senses and you felt your heartbeat gradually return to normal. You tried to catch your breath again. "
    "En realidad, la voz de Nick te devolvió a la realidad y sentiste que tu corazón se calmaba poco a poco. Intentaste recuperar el aliento otra vez. "

# game/script.rpy:400
translate spanish start_c6bba307:

    # yn "Oh.... I'm sorry... It's just... God, this is totally fucked up. "
    yn "Oh.... Perdón... Es que... Dios, esto es una locura total. "

# game/script.rpy:403
translate spanish start_fb6641b2:

    # "Nick gently extended his arms toward you, perhaps to embrace you, but immediately yanked them away. "
    "Nick extendió suavemente los brazos hacia ti, quizá para abrazarte, pero los retiró de inmediato. "

# game/script.rpy:404
translate spanish start_67de71e7:

    # yn "I really can't talk right now, I have to go to the police. "
    yn "De verdad no puedo hablar ahora, tengo que ir a la policía. "

# game/script.rpy:407
translate spanish start_fcd47781:

    # n "Maybe you should just call them? Your neighborhood isn't the most favorable, and it's already so late. Something might happen to you. "
    n "¿Y si mejor los llamas? Tu barrio no es el más favorable, y ya es muy tarde. Podría pasarte algo. "

# game/script.rpy:408
translate spanish start_865ab9c0:

    # "You realize that sounds pretty sensible. "
    "Te das cuenta de que suena bastante sensato. "

# game/script.rpy:411
translate spanish start_fb9da21c:

    # yn "You're right... Please sit with me for a while. I don't want to be alone. At least until the police arrive. "
    yn "Tienes razón... Por favor, quédate un rato conmigo. No quiero estar sin compañía. Al menos hasta que llegue la policía. "

# game/script.rpy:412
translate spanish start_2cff8b7e:

    # n "Sure, no problem."
    n "Claro, sin problema."

# game/script.rpy:416
translate spanish start_e0d56a25:

    # "You and Nick went home. The guy looked around and closed the door behind him. "
    "Tú y Nick fueron a tu casa. El chico miró alrededor y cerró la puerta tras de sí. "

# game/script.rpy:417
translate spanish start_3f7c6d36:

    # yn "I can't offer much choice in what to eat to be honest. Can I make you some coffee? "
    yn "La verdad es que no puedo ofrecerte mucho para comer. ¿Te preparo un café? "

# game/script.rpy:419
translate spanish start_48d879f4:

    # n "Let me do it myself, while you call the police. "
    n "Déjame hacerlo a mí, mientras tú llamas a la policía. "

# game/script.rpy:422
translate spanish start_aede0fe9:

    # n "I'll be here, I promise."
    n "Aquí estaré, lo prometo."

# game/script.rpy:423
translate spanish start_5ec4e741:

    # n "{cps=180}{sc}Forever.{/sc}{w=0.1}{nw}"
    n "{cps=180}{sc}Para siempre.{/sc}{w=0.1}{nw}"

# game/script.rpy:424
translate spanish start_b34efa41:

    # yn "Yes, thank you... The phone is somewhere in the room, I'll be right there. "
    yn "Sí, gracias... El teléfono está en algún lugar de la habitación, enseguida vuelvo. "

# game/script.rpy:426
translate spanish start_c2821f8f:

    # "You went back to your bedroom and started looking for your cell phone. "
    "Volviste a tu dormitorio y empezaste a buscar tu celular. "

# game/script.rpy:427
translate spanish start_56cd531a:

    # "{cps=3}. . ."
    "{cps=3}. . ."

# game/script.rpy:428
translate spanish start_5f3a9af4:

    # "When you turned each thing over for the third time, your patience snapped. So the maniac didn't kill you, but took your phone instead? "
    "Cuando revisaste cada cosa por tercera vez, se te acabó la paciencia. ¿Así que el maniático no te mató, pero se llevó tu teléfono? "

# game/script.rpy:429
translate spanish start_8b8cc865:

    # "What a goody-goody. You felt somehow... cheap. "
    "Qué buenazo. Te sentiste, de algún modo... poca cosa. "

# game/script.rpy:430
translate spanish start_6f008c80:

    # yn "God... Why am I doing this? Why didn't I just ask Nick for the phone? I mean, he should definitely have one. "
    yn "Dios... ¿Por qué hago esto? ¿Por qué no le pedí el teléfono a Nick? Digo, seguro que él tiene uno. "

# game/script.rpy:432
translate spanish start_b59b403d:

    # "Nick was already drinking his coffee and you saw the cup with the second one on the table beside him. "
    "Nick ya se estaba tomando su café y viste la taza con el segundo café sobre la mesa, a su lado. "

# game/script.rpy:434
translate spanish start_13c93a5c:

    # "You took the chilled drink and drank it all in a few big gulps. "
    "Tomaste la bebida fría y te la bebiste toda de unos cuantos tragos grandes. "

# game/script.rpy:435
translate spanish start_63cb5e5c:

    # yn "I can't find my phone, can I use yours? "
    yn "No encuentro mi teléfono, ¿puedo usar el tuyo? "

# game/script.rpy:436
translate spanish start_24dc3abd:

    # yn "Oh and thank you. "
    yn "Ah, y gracias. "

# game/script.rpy:439
translate spanish start_dbd7f913:

    # n "You're welcome! Tell me what happened, so I can tell them everything in detail. "
    n "¡De nada! Cuéntame qué pasó, así puedo contárselo todo con detalle. "

# game/script.rpy:442
translate spanish start_6f0a3b88:

    # yn "After all that hectic day, I went home, and those two jerks were waiting for me. They caught up with me and threw me on the ground, where..."
    yn "Después de ese día tan agitado, volví a casa y esos dos imbéciles me estaban esperando. Me alcanzaron y me tiraron al suelo, donde..."

# game/script.rpy:443
translate spanish start_68cf01db:

    # yn "I don't know, they probably wanted to intimidate me with a knife. "
    yn "No sé, seguro querían intimidarme con un cuchillo. "

# game/script.rpy:444
translate spanish start_95ea29dd:

    # yn "I can still feel the wound they left on my stomach with the blade. "
    yn "Todavía siento la herida que me dejaron en el estómago con la hoja. "

# game/script.rpy:445
translate spanish start_6960e634:

    # yn "But then... somebody..."
    yn "Pero entonces... alguien..."

# game/script.rpy:447
translate spanish start_df436cd0:

    # yn "{sc}«Wait, what the hell»{/sc}"
    yn "{sc}«Espera, qué demonios»{/sc}"

# game/script.rpy:448
translate spanish start_738f8fc4:

    # yn "«Why am I missing out on so many weird things?»"
    yn "«¿Por qué se me pasan tantas cosas raras?»"

# game/script.rpy:449
translate spanish start_365fc7a2:

    # "You looked at Nick, who was waiting for you to continue the story. "
    "Miraste a Nick, que esperaba a que continuaras la historia. "

# game/script.rpy:459
translate spanish what_01dab904:

    # yn "What is going on? Why am I acting like I don't have a choice? Why do I make such stupid decisions?"
    yn "¿Qué está pasando? ¿Por qué actúo como si no tuviera elección? ¿Por qué tomo decisiones tan estúpidas?"

# game/script.rpy:460
translate spanish what_67ace80e:

    # yn "Why am I telling you this? Why am I wasting my time when I can tell the police everything myself? Why did I let you into my house at all?!"
    yn "¿Por qué te estoy contando esto? ¿Por qué pierdo el tiempo cuando puedo contárselo todo a la policía directamente? ¡¿Por qué te dejé entrar en mi casa?!"

# game/script.rpy:461
translate spanish what_09402dad:

    # yn "WHY AM I LIKE A FREAKING ROBOT?!"
    yn "¡¿POR QUÉ ESTOY ACTUANDO COMO UN MALDITO ROBOT?!"

# game/script.rpy:464
translate spanish what_878bffdb:

    # n "Oh, God."
    n "Ay, Dios."

# game/script.rpy:466
translate spanish what_e506e697:

    # n "Did you realize that just now?"
    n "¿Te acabas de dar cuenta?"

# game/script.rpy:467
translate spanish what_3e8becdd:

    # "It was as if this words didn't make any sense. "
    "Era como si esas palabras no tuvieran ningún sentido. "

# game/script.rpy:468
translate spanish what_132f2fcd:

    # "You didn't know what he was talking about, but you didn't know what you were talking about either. "
    "No sabías de qué hablaba, pero tampoco sabías de qué hablabas tú. "

# game/script.rpy:469
translate spanish what_22e7819b:

    # "You began to shake with the madness that was slowly consuming you. "
    "Empezaste a temblar por la locura que te iba consumiendo poco a poco. "

# game/script.rpy:470
translate spanish what_0ef87ffd:

    # "No, wait. "
    "No, espera. "

# game/script.rpy:471
translate spanish what_5c79329f:

    # m "{sc}{i}I'M{/i} THE ONE WHO'S STARTING TO SHAKE!{/sc}"
    m "{sc}¡{i}YO{/i} SOY QUIEN EMPIEZA A TEMBLAR!{/sc}"

# game/script.rpy:472
translate spanish what_e1288e5c:

    # m "{sc}WHO THE FUCK ARE {i}YOU{/i}?!{/sc}"
    m "{sc}¡¿QUIÉN CARAJO ERES {i}TÚ{/i}?!{/sc}"

# game/script.rpy:473
translate spanish what_b9a4b5e2:

    # n "Just look at you! So cute, so scared..."
    n "¡Mírate! Qué ternura, con tanto miedo..."

# game/script.rpy:474
translate spanish what_b9cbcc0d:

    # n "Paranoid android."
    n "Androide paranoico."

# game/script.rpy:475
translate spanish what_4b26246f:

    # m "WHY CAN'T I MAKE DECISIONS ANYMORE?! WHY IS SOMEONE CONTROLLING ME?!"
    m "¡¿POR QUÉ YA NO PUEDO TOMAR DECISIONES?! ¡¿POR QUÉ ALGUIEN ME CONTROLA?!"

# game/script.rpy:476
translate spanish what_b8fa7388:

    # n "Hey, be quiet, darling. No one will answer you unless I want them to. "
    n "Eh, cállate, cariño. Nadie te responderá a menos que yo quiera. "

# game/script.rpy:477
translate spanish what_052cf66d:

    # n "Look what I can do. "
    n "Mira lo que puedo hacer. "

# game/script.rpy:480
translate spanish what_330a753c:

    # m "WHAT THE FUCK."
    m "QUÉ CARAJO."

# game/script.rpy:483
translate spanish what_e25846a9:

    # n "Oh, it's not the nicest place for you."
    n "Oh, este no es el lugar más agradable para ti."

# game/script.rpy:484
translate spanish what_a55c58b7:

    # n "How about the beach?"
    n "¿Qué tal la playa?"

# game/script.rpy:487
translate spanish what_c12fca79:

    # n "Of course. "
    n "Por supuesto. "

# game/script.rpy:488
translate spanish what_0ba278ca:

    # n "He never misses a chance to make fun of me. "
    n "Nunca pierde la oportunidad de burlarse de mí. "

# game/script.rpy:489
translate spanish what_ad101147:

    # n "You just embarrassed me in front of the love of my life! "
    n "¡Me acabas de avergonzar delante del amor de mi vida! "

# game/script.rpy:490
translate spanish what_68438b86:

    # n "Oh. That's enough. I'm not in the mood for jokes anymore, let's go back to the beginning."
    n "Oh. Ya basta. Ya no estoy de humor para bromas, volvamos al principio."

# game/script.rpy:499
translate spanish stupid_fd7a33ab:

    # n "What do you mean, no? Forgive me, my love, but I don't accept that answer. "
    n "¿Cómo que no? Perdóname, mi amor, pero no acepto esa respuesta. "

# game/script.rpy:500
translate spanish stupid_9ee6de32:

    # n "Come on, go back to the beginning, I promise you'll be fine. "
    n "Vamos, vuelve al principio, te prometo que estarás bien. "

# game/script.rpy:504
translate spanish stupid_7a0d38c7:

    # n "Oh, it's so annoying."
    n "Oh, qué fastidio."

# game/script.rpy:505
translate spanish stupid_f5727894:

    # n "Okay, have it your way. You'll get tired of it someday."
    n "Está bien, como quieras. Algún día te cansarás."

# game/script.rpy:506
translate spanish stupid_b2281ab1:

    # m "BITCH!"
    m "¡HIJO DE PUTA!"

# game/script.rpy:515
translate spanish con2_fc73c616:

    # yn "...someone killed them all but me."
    yn "...alguien los mató a todos menos a mí."

# game/script.rpy:516
translate spanish con2_1571fad6:

    # yn "«I have this strange feeling that something is going wrong»"
    yn "«Tengo la extraña sensación de que algo va mal»"

# game/script.rpy:519
translate spanish con2_b8d82f39:

    # n "That sounds awful."
    n "Suena horrible."

# game/script.rpy:520
translate spanish con2_e89a709b:

    # n "Poor thing... Those freaks scared you so much."
    n "Pobre criatura... Esos bichos raros te asustaron mucho."

# game/script.rpy:521
translate spanish con2_50056432:

    # yn "Scared me? You didn't seem to hear what I was saying. "
    yn "¿Asustarme? Parece que no oíste lo que dije. "

# game/script.rpy:522
translate spanish con2_cb333283:

    # "You felt a little bit dizzy."
    "Sentiste un poco de mareo."

# game/script.rpy:523
translate spanish con2_96d93dc2:

    # yn "Someone KILLED TWO PEOPLE right in front of me! "
    yn "¡Alguien MATÓ A DOS PERSONAS justo delante de mí! "

# game/script.rpy:528
translate spanish con2_94a1ada1:

    # n "Yes. I heard you. Someone killed the people who wanted to beat you, who hurt you and frightened you. "
    n "Sí. Te oí. Alguien mató a las personas que querían golpearte, que te hicieron daño y te asustaron. "

# game/script.rpy:529
translate spanish con2_1baeb43f:

    # n "Should I regret it?"
    n "¿Debería arrepentirme?"

# game/script.rpy:530
translate spanish con2_19644c78:

    # yn "IT DOESN'T MATTER WHAT THEY WANTED TO DO!"
    yn "¡NO IMPORTA LO QUE QUISIERAN HACER!"

# game/script.rpy:531
translate spanish con2_1e78b669:

    # yn "Oh crap, what's wrong with my head?! "
    yn "Mierda, ¡¿qué le pasa a mi cabeza?! "

# game/script.rpy:533
translate spanish con2_7c46c12e:

    # "You squeezed your temples to muffle the throbbing pain that rippled through them. "
    "Te apretaste las sienes para amortiguar el dolor palpitante que las recorría. "

# game/script.rpy:534
translate spanish con2_ecd2436c:

    # n "It's such a shame we have slightly different outlooks on life. "
    n "Es una lástima que tengamos visiones de la vida un poco distintas. "

# game/script.rpy:536
translate spanish con2_e8836b4c:

    # n "But I still think that you... beautiful. Incredible."
    n "Pero sigo pensando que tú... eres una belleza. Increíble."

# game/script.rpy:537
translate spanish con2_ee4b36d1:

    # n "You know, it's even so touching that you care even about people who deserve to die. "
    n "Sabes, hasta resulta conmovedor que te importen incluso las personas que merecen morir. "

# game/script.rpy:539
translate spanish con2_a8b2a859:

    # yn "What are you talking about... Damn, I'm going to throw up..."
    yn "¿De qué hablas... Maldición, voy a vomitar..."

# game/script.rpy:541
translate spanish con2_0983096a:

    # "You clutched at your stomach. It was almost impossible to breathe, everything was spinning. "
    "Te agarraste el estómago. Casi no podías respirar, todo daba vueltas. "

# game/script.rpy:543
translate spanish con2_8571a93b:

    # "Suddenly Nick grabbed you and pulled you to him, covering your mouth with his hand."
    "De pronto Nick te agarró y te atrajo hacia sí, cubriéndote la boca con la mano."

# game/script.rpy:546
translate spanish con2_2f311b05:

    # "You felt your body cramp up and the warm, sour contents of your stomach pour out of your mouth, which couldn't come out because of the guy's firm grip."
    "Sentiste que el cuerpo se te contraía y que el contenido tibio y ácido de tu estómago subía por la boca, sin poder salir por la firme sujeción del chico."

# game/script.rpy:547
translate spanish con2_130831d3:

    # "You started kicking and trying to escape from his grasp, but Nick only squeezed you harder and clamped his hand over your nose, leaving you with nothing to do but swallow your own vomit, causing you to start throwing up again. "
    "Empezaste a patalear y a intentar zafarte de su agarre, pero Nick solo te apretó más y te tapó la nariz con la mano, y no te quedó más remedio que tragarte tu propio vómito, lo que te provocó otra arcada. "

# game/script.rpy:548
translate spanish con2_22905bfd:

    # "The guy let you go. You fell to the floor and started coughing. Nick knelt down and pulled you gently against him, stroking your head. "
    "El chico te soltó. Caíste al suelo y empezaste a toser. Nick se arrodilló y te estrechó con suavidad contra sí, acariciándote la cabeza. "

# game/script.rpy:549
translate spanish con2_6160bdaa:

    # yn "{sc}DON'T TOUCH ME, MOTHERFUCKER!!! DON'T COME NEAR ME!!!{/sc}"
    yn "{sc}¡NO ME TOQUES, MALDITO BASTARDO!!! ¡NO TE ACERQUES!!!{/sc}"

# game/script.rpy:550
translate spanish con2_92d2333f:

    # "You couldn't resist, your eyelids were heavy. This bastard must have put something in your coffee. "
    "No pudiste resistirte, los párpados te pesaban. Este bastardo debió de echarle algo a tu café. "

# game/script.rpy:551
translate spanish con2_d058df47:

    # n "I'm sorry, I'm sorry... I think I overdosed, but if you vomited it out, I'd have to knock you out by force. And I don't want to hurt you... That's so rude. "
    n "Perdón, perdón... Creo que me pasé con la dosis, pero si lo vomitabas, tendría que dejarte inconsciente por la fuerza. Y no quiero hacerte daño... Eso sería muy grosero. "

# game/script.rpy:552
translate spanish con2_709cbd32:

    # n "I only want to love you, darling. I'll be the gentlest. When you wake up, I'll give you something, I promise. Come on, go to sleep, my love."
    n "Solo quiero amarte, cariño. Seré lo más delicado posible. Cuando despiertes, te daré algo, lo prometo. Vamos, duérmete, mi amor."

# game/script.rpy:553
translate spanish con2_a3589482:

    # "The guy gently stroked your hair, but the only thing you wanted to do was stab him. But despite all your resistance, your consciousness sank into darkness. "
    "El chico te acarició el pelo con suavidad, pero lo único que querías era apuñalarlo. Pero a pesar de toda tu resistencia, tu consciencia se hundió en la oscuridad. "

# game/script.rpy:556
translate spanish con2_56cd531a:

    # "{cps=3}. . ."
    "{cps=3}. . ."

# game/script.rpy:557
translate spanish con2_e49ad0bf:

    # "{cps=15}It seems like you've been dreaming. A dark, gloomy dream. No, it's more like a nightmare. "
    "{cps=15}Parece que has estado soñando. Un sueño oscuro y sombrío. No, más bien una pesadilla. "

# game/script.rpy:558
translate spanish con2_4c6583bd:

    # "{cps=15}No one heard your soul-shattering screams. All you had to do was sob in despair, in loneliness, in powerlessness. "
    "{cps=15}Nadie oyó tus gritos desgarradores. Solo te quedaba sollozar de desesperación, de soledad, de impotencia. "

# game/script.rpy:559
translate spanish con2_51c2b598:

    # "{cps=15}You let out a heavy, silent sigh and felt the tears running down your cheeks. Your still numb body was unresponsive, and you could hardly open your eyelids."
    "{cps=15}Soltaste un suspiro pesado y silencioso y sentiste las lágrimas rodando por tus mejillas. Tu cuerpo, todavía entumecido, no respondía, y apenas podías abrir los párpados."

# game/script.rpy:560
translate spanish con2_ac8d03a5:

    # n "Darling? Hey, look over here for a while. Come on, you can rest a little more after this."
    n "¿Cariño? Oye, mira para acá un momento. Vamos, después de esto podrás descansar un poco más."

# game/script.rpy:562
translate spanish con2_f76b0508:

    # "You heard a voice that made you shiver. Your heart raced and your stomach twisted with another wave of fear. "
    "Oíste una voz que te hizo estremecer. Tu corazón se aceleró y tu estómago se retorció con otra oleada de miedo. "

# game/script.rpy:564
translate spanish con2_e671ec81:

    # "You opened your eyes slowly, trying to hold back the tears in your throat."
    "Abriste los ojos lentamente, intentando contener las lágrimas en la garganta."

# game/script.rpy:565
translate spanish con2_eec1135b:

    # "Right in front of you sat Nick, holding out a rather large box wrapped in red decorative paper and tied with black ribbon. "
    "Justo frente a ti estaba sentado Nick, ofreciéndote una caja bastante grande envuelta en papel decorativo rojo y atada con una cinta negra. "

# game/script.rpy:566
translate spanish con2_7f067ae9:

    # "You flinched and started coughing sharply. The stench of dead meat hit you sharply in the nose, and it stung your eyes."
    "Te sobresaltaste y empezaste a toser con fuerza. El hedor a carne muerta te golpeó la nariz y te picó en los ojos."

# game/script.rpy:567
translate spanish con2_bb1a3d1a:

    # "You didn't have the strength to tell Nick everything you were thinking about him, not even your empty stomach could spew out anything but gastric juice. "
    "No tenías fuerzas para decirle a Nick todo lo que pensabas de él, ni siquiera tu estómago vacío pudo expulsar otra cosa que jugos gástricos."

# game/script.rpy:569
translate spanish con2_be074f32:

    # n "Oh? I can see in your eyes that you're not impressed by the smell. I'm sorry, uh... I didn't mean to. I just forgot to put them in the fridge. "
    n "¿Oh? Veo en tus ojos que el olor no te impresiona. Lo siento, eh... No fue mi intención. Solo olvidé meterlos en la nevera. "

# game/script.rpy:571
translate spanish con2_25616a2a:

    # n "Anyway, I tried for you! Picked only the best pieces!"
    n "En fin, ¡me esforcé por ti! ¡Escogí solo los mejores trozos!"

# game/script.rpy:572
translate spanish con2_825cde07:

    # "Your brain wasn't thinking at all. All you could do was shed tears, unable to utter a word. "
    "Tu cerebro no pensaba en absoluto. Lo único que podías hacer era derramar lágrimas, incapaz de pronunciar palabra. "

# game/script.rpy:573
translate spanish con2_2054a89d:

    # n "It seems like it's hard for you to talk right now, honey. Let me help you."
    n "Parece que ahora te cuesta hablar, cariño. Déjame ayudarte."

# game/script.rpy:577
translate spanish con2_5fd2c426:

    # n "Hehe! You're embarrassing me! It's the least I can do for you. "
    n "¡Jeje! ¡Me avergüenzas! Es lo mínimo que puedo hacer por ti. "

# game/script.rpy:578
translate spanish con2_4160332c:

    # n "It was really disgusting to touch those freaks, though. I was in such a hurry that I didn't even have time to clean myself up! "
    n "Aunque fue realmente asqueroso tocar a esos bichos raros. ¡Tenía tanta prisa que ni siquiera tuve tiempo de limpiarme! "

# game/script.rpy:579
translate spanish con2_1c0c83ff:

    # n "Sorry about that. I really won't embarrass you anymore. I have to match you, to be as beautiful as you are! "
    n "Perdón por eso. De verdad no volveré a avergonzarte. ¡Tengo que estar a tu altura, ser tan hermoso como tú! "

# game/script.rpy:580
translate spanish con2_1a61e19f:

    # n "But of course this is impossible. I'll never be able to equal you, my love. Oh! Look at your present!"
    n "Pero claro, es imposible. Nunca podré igualarte, mi amor. ¡Oh! ¡Mira tu regalo!"

# game/script.rpy:582
translate spanish con2_a671972f:

    # "You shook and immediately felt everything lose its shape. "
    "Te sacudiste y enseguida sentiste que todo perdía su forma. "

# game/script.rpy:583
translate spanish con2_455ee9b8:

    # "The box was filled to the top with rotten meat and organs that gave off a stench. If you could have screamed, you would have blown your voice. "
    "La caja estaba llena hasta el borde de carne podrida y órganos que desprendían hedor. Si hubieras podido gritar, te habrías desgarrado la voz. "

# game/script.rpy:584
translate spanish con2_82e12439:

    # "Nick blushed and smiled merrily, apparently feeling proud of his... gift. "
    "Nick se sonrojó y sonrió alegremente, con evidente orgullo por su... regalo. "

# game/script.rpy:586
translate spanish con2_e96a8695:

    # "Your consciousness has blacked out again. "
    "Tu consciencia volvió a apagarse. "

# game/script.rpy:589
translate spanish con2_937303d3:

    # "{sc}. . .{/sc}"
    "{sc}. . .{/sc}"

# game/script.rpy:591
translate spanish con2_195c196a:

    # no "...I'm so sorry that you have to have a body."
    no "...Lamento tanto que tengas que tener un cuerpo."

# game/script.rpy:593
translate spanish con2_0c80a8b0:

    # no "One that'll hurt you, and be the subject of so much of your fear~"
    no "Uno que te hará daño y será objeto de tanto de tu miedo~"

# game/script.rpy:595
translate spanish con2_99f8ea31:

    # "{cps=3}{sc}. . .{/sc}"
    "{cps=3}{sc}. . .{/sc}"

# game/script.rpy:598
translate spanish con2_5ca8c9a1:

    # no "...If thought is life and strength and breath and the want of thought is death;"
    no "...Si el pensamiento es vida, fuerza y aliento, y la falta de pensamiento es muerte;"

# game/script.rpy:599
translate spanish con2_860d30e2:

    # no "Then I am a happy fly if I live or if I die~"
    no "Entonces soy una mosca feliz, ya viva o ya muera~"

# game/script.rpy:601
translate spanish con2_99f8ea31_1:

    # "{cps=3}{sc}. . .{/sc}"
    "{cps=3}{sc}. . .{/sc}"

# game/script.rpy:603
translate spanish con2_9b7c1653:

    # "{sc}?{/sc}"
    "{sc}?{/sc}"

# game/script.rpy:604
translate spanish con2_0fedee4e:

    # "From time to time you would regain consciousness, but only for a moment. In the background there were sounds and soft chanting that you could hardly make out."
    "De vez en cuando recuperabas la consciencia, pero solo por un instante. Al fondo había sonidos y un suave canto que apenas lograbas distinguir."

# game/script.rpy:605
translate spanish con2_765ccb6e:

    # "You never realized how much time had passed, but judging by how much your body was numb, you were in the same position for a long. "
    "Nunca supiste cuánto tiempo había pasado, pero a juzgar por lo entumecido que tenías el cuerpo, llevabas mucho tiempo en la misma posición. "

# game/script.rpy:606
translate spanish con2_fadca28b:

    # "There was a nasty sour taste in your mouth, it was hard even to breathe."
    "Tenías un sabor agrio y desagradable en la boca, hasta respirar costaba."

# game/script.rpy:607
translate spanish con2_cb419d67:

    # "You only heard some noise in the background, no sign that Nick was in the room. You decided to try to open your eyes and look around."
    "Solo oías algo de ruido al fondo, sin señal de que Nick estuviera en la habitación. Decidiste intentar abrir los ojos y mirar a tu alrededor."

# game/script.rpy:609
translate spanish con2_e6ff9898:

    # "It was useless, there were only blurry spots in front of your eyes. You tried to move your arm, but to no avail."
    "Fue inútil, solo había manchas borrosas ante tus ojos. Intentaste mover el brazo, pero no lo lograste."

# game/script.rpy:610
translate spanish con2_183df1bc:

    # yn "...Am I tied up?"
    yn "...¿Me han atado?"

# game/script.rpy:611
translate spanish con2_8bf2ab4f:

    # "You whispered it softly, more to see if you could still speak at all."
    "Lo susurraste con suavidad, más para comprobar si aún podías hablar."

# game/script.rpy:613
translate spanish con2_0b74f5a1:

    # n "Honey? Ah! Are you awake? To tell you the truth, I was starting to worry that you wouldn't wake up when dinner was ready, but you're right on time! As always... so perfect!"
    n "¿Cariño? ¡Ah! ¿Ya despertaste? A decir verdad, empezaba a preocuparme de que no despertaras cuando la cena estuviera lista, ¡pero llegas justo a tiempo! Como siempre... ¡qué perfección!"

# game/script.rpy:615
translate spanish con2_4459f1c4:

    # "Cold sweat broke out on your body and your breath caught in horror. You tried to shout, but nothing came out, only a wheeze escaped from your mouth."
    "Te brotó un sudor frío por todo el cuerpo y se te cortó el aliento de horror. Intentaste gritar, pero no salió nada, solo se te escapó un resuello de la boca."

# game/script.rpy:616
translate spanish con2_0775facc:

    # n "Oh, yes, sorry for the inconvenience... But I really tied you up! At least so that you don't fall off your chair. I don't want you to hurt yourself!"
    n "Ah, sí, perdón por las molestias... ¡Pero sí te até! Al menos para que no te caigas de la silla. ¡No quiero que te lastimes!"

# game/script.rpy:617
translate spanish con2_d63ecf6a:

    # "Nick gently stroked your cheek. You tried to bite him, but it didn't work."
    "Nick te acarició suavemente la mejilla. Intentaste morderlo, pero no funcionó."

# game/script.rpy:618
translate spanish con2_4aa3ede9:

    # "His hand was unimaginably icy."
    "Su mano estaba increíblemente helada."

# game/script.rpy:619
translate spanish con2_39ab1abc:

    # n "Come on, don't be so naughty. I don't feel pain anyway! Do you want to bite me? Only if you do it out of love for me!"
    n "Vamos, pórtate bien. ¡De todos modos no siento dolor! ¿Quieres morderme? ¡Solo si lo haces por amor a mí!"

# game/script.rpy:620
translate spanish con2_a65f96c0:

    # "Nick exhaled hotly and put his wrist to your mouth, but you just gathered all your strength and spat on his hand."
    "Nick exhaló con calor y te acercó la muñeca a la boca, pero tú solo reuniste todas tus fuerzas y le escupiste en la mano."

# game/script.rpy:621
translate spanish con2_29d4070a:

    # "He didn't say anything to that, just grunted and gently grabbed your face, but you could feel his fingers trembling with anger."
    "No dijo nada al respecto, solo gruñó y te tomó con suavidad el rostro, pero sentiste cómo le temblaban los dedos de ira."

# game/script.rpy:622
translate spanish con2_1b2668a6:

    # n "Nothing, I understand... It's all good."
    n "Nada, lo entiendo... Todo está bien."

# game/script.rpy:623
translate spanish con2_632d9ddf:

    # "He seemed to be saying it to himself."
    "Parecía decírselo a sí mismo."

# game/script.rpy:624
translate spanish con2_29418cb8:

    # n "Come on, open your eyes. Look what I have for you!"
    n "Vamos, abre los ojos. ¡Mira lo que tengo para ti!"

# game/script.rpy:625
translate spanish con2_f77e424e:

    # "You blinked a few times. In truth, you felt your strength returning to you every minute."
    "Parpadeaste varias veces. En verdad, sentías que tus fuerzas volvían a ti a cada minuto."

# game/script.rpy:627
translate spanish con2_1da26060:

    # "The first thing you felt was the unexpectedly wonderful smell of fried meat, which made your mouth fill with saliva."
    "Lo primero que sentiste fue el olor inesperadamente delicioso de carne frita, que te llenó la boca de saliva."

# game/script.rpy:628
translate spanish con2_acab4583:

    # "Nick was holding a beautiful piece of meat in his hands, served with potatoes and fragrant herbs."
    "Nick sostenía en sus manos un hermoso trozo de carne, servido con papas y hierbas aromáticas."

# game/script.rpy:629
translate spanish con2_1e2d33fb:

    # "It seems that this bastard was more than good at cooking."
    "Parece que este bastardo cocinaba más que bien."

# game/script.rpy:630
translate spanish con2_0bb233b3:

    # yn "What the hell? You drugged my coffee, tied me up, even made me swallow my own vomit, and now you're cooking me food?"
    yn "¿Qué demonios? ¿Drogaste mi café, me ataste, incluso me hiciste tragarme mi propio vómito, y ahora me preparas la comida?"

# game/script.rpy:631
translate spanish con2_ab8bab3a:

    # yn "If you want to seem like a nice guy, then maybe you'll let me go first? Why did you do all this at all?"
    yn "Si quieres parecer buena persona, ¿por qué no me sueltas primero? ¿Por qué hiciste todo esto?"

# game/script.rpy:632
translate spanish con2_40ab1b36:

    # "You tried to swallow all the insults that you wanted to shout in his face, but decided that it was better to keep your mouth shut now."
    "Intentaste tragarte todos los insultos que querías gritarle en la cara, pero decidiste que ahora era mejor mantener la boca cerrada."

# game/script.rpy:633
translate spanish con2_abfc41cd:

    # n "But I'm already a good guy! I can see how your eyes are shining in anticipation of when you will be able to taste this wonderful meat!"
    n "¡Pero si ya soy buena persona! Veo cómo te brillan los ojos de ganas de probar esta maravillosa carne."

# game/script.rpy:634
translate spanish con2_58a6a481:

    # n "I'll be even more wonderful when I finally fulfill your wish."
    n "Seré aún más maravilloso cuando por fin cumpla tu deseo."

# game/script.rpy:635
translate spanish con2_9019ccdf:

    # n "In truth, you have no idea how much effort it cost me not to eat it ahead of time..."
    n "En verdad, no tienes idea del esfuerzo que me costó no comérmela antes de tiempo..."

# game/script.rpy:636
translate spanish con2_4ea45218:

    # n "God, I'm so good! Such incredible endurance is not given to every person!"
    n "¡Dios, qué bueno soy! ¡No a todo el mundo se le concede una resistencia tan increíble!"

# game/script.rpy:637
translate spanish con2_2320c13d:

    # n "This dish is not just a piece of meat. This is our division of love... Almost a child! Only we won't eat the baby, unlike this meat... Or will we?"
    n "Este plato no es solo un trozo de carne. Es el fruto de nuestro amor... ¡Casi un hijo! Solo que nosotros no nos comeremos al bebé, a diferencia de esta carne... ¿O sí?"

# game/script.rpy:638
translate spanish con2_57906827:

    # "Nick laughed viciously at his words, you were just trying to restrain yourself from starting to yell at him."
    "Nick se rio con maldad ante sus propias palabras, tú solo intentabas contenerte para no ponerte a gritarle."

# game/script.rpy:639
translate spanish con2_1b65d4fd:

    # n "Hey, you know what? I think I don't even mind letting you go! Come on, get up on both your feet and do whatever you want."
    n "Oye, ¿sabes qué? ¡Creo que ni me importa dejarte ir! Vamos, ponte en pie y haz lo que quieras."

# game/script.rpy:640
translate spanish con2_fe9e1255:

    # n "You can run away or you can stay..."
    n "Puedes huir o puedes quedarte..."

# game/script.rpy:641
translate spanish con2_9e8b83a3:

    # "You didn't believe Nick and growled angrily, but he came up to you and slowly untied the rope that chained you to the chair."
    "No le creíste a Nick y gruñiste con rabia, pero él se te acercó y desató lentamente la cuerda que te encadenaba a la silla."

# game/script.rpy:642
translate spanish con2_29cdf74d:

    # "You no longer tried to find logic in the actions of this madman. Finally, you felt that you could breathe deeply."
    "Ya no intentabas buscarle lógica a los actos de este loco. Por fin sentiste que podías respirar hondo."

# game/script.rpy:643
translate spanish con2_20f88881:

    # "But for now, your body is too weak to escape, so you decided to wait a little longer."
    "Pero por ahora tu cuerpo está demasiado débil para escapar, así que decidiste esperar un poco más."

# game/script.rpy:644
translate spanish con2_9201ab17:

    # n "Ah! Have you decided to stay with me?! God... I'm on fire! Ooh... It's so embarrassing."
    n "¡Ah! ¡¿Has decidido quedarte conmigo?! Dios... ¡Estoy ardiendo! Ooh... Qué vergüenza."

# game/script.rpy:645
translate spanish con2_fbb939bd:

    # n "Darling, you know exactly how to make happy a person who is in love with you!"
    n "Cariño, ¡sabes exactamente cómo hacer feliz a una persona que está enamorada de ti!"

# game/script.rpy:646
translate spanish con2_07b12182:

    # "Suddenly you shuddered. Pain went through your body. You could not understand the source of this feeling and began to frantically look around your body."
    "De repente te estremeciste. El dolor recorrió tu cuerpo. No lograbas entender de dónde venía esa sensación y empezaste a mirarte el cuerpo frenéticamente."

# game/script.rpy:647
translate spanish con2_cc25d0ac:

    # "You finally realized that your legs are so numb that you can't feel them."
    "Por fin te diste cuenta de que tenías las piernas tan entumecidas que no las sentías."

# game/script.rpy:648
translate spanish con2_bf7ee1c4:

    # n "Oh? Is something wrong?"
    n "¿Oh? ¿Pasa algo?"

# game/script.rpy:649
translate spanish con2_e978f52e:

    # "Nick was smiling like a child who had been bought a long-awaited toy."
    "Nick sonreía como un niño al que le han comprado un juguete largamente esperado."

# game/script.rpy:650
translate spanish con2_c81d24f6:

    # yn "I can't feel my legs. Help me get out from behind the table, I want to examine them. You don't want anything bad to happen to me, do you?"
    yn "No siento las piernas. Ayúdame a salir de detrás de la mesa, quiero examinarlas. No querrás que me pase nada malo, ¿verdad?"

# game/script.rpy:651
translate spanish con2_95887b5a:

    # "Nick started and hurriedly approached you."
    "Nick se sobresaltó y se te acercó apresuradamente."

# game/script.rpy:652
translate spanish con2_863655ea:

    # n "Of course! I would never forgive if something happened to you..."
    n "¡Claro que no! Jamás me lo perdonaría si te pasara algo..."

# game/script.rpy:653
translate spanish con2_fead5e77:

    # "Nick gently pushed you out from behind the table. And.."
    "Nick te apartó con suavidad de detrás de la mesa. Y..."

# game/script.rpy:655
translate spanish con2_8534ca42:

    # ". . ."
    ". . ."

# game/script.rpy:656
translate spanish con2_8534ca42_1:

    # ". . ."
    ". . ."

# game/script.rpy:658
translate spanish con2_f2c75886:

    # "Your heart seemed to stop, and a heart-rending scream burst out of your throat."
    "Tu corazón pareció detenerse y un grito desgarrador te brotó de la garganta."

# game/script.rpy:659
translate spanish con2_a8a2bc2c:

    # yn "{sc}Aa... AA... AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA{/sc}"
    yn "{sc}Aa... AA... AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA{/sc}"

# game/script.rpy:661
translate spanish con2_2c19c358:

    # yn "{sc}MY LEGS! MY LEGS!! WHERE ARE THEY?! I DON'T HAVE FUCKING LEGS?!{/sc}"
    yn "{sc}¡MIS PIERNAS! ¡¡MIS PIERNAS!! ¡¿DÓNDE ESTÁN?! ¡¿NO TENGO PIERNAS, MALDITA SEA?!{/sc}"

# game/script.rpy:662
translate spanish con2_b537531e:

    # yn "{sc}GOD TELL ME I'M JUST DREAMING! FUCK! FUCK! FUCK!!!{/sc}"
    yn "{sc}¡DIOS, DIME QUE SOLO ESTOY SOÑANDO! ¡MIERDA! ¡MIERDA! ¡MIERDA!!!{/sc}"

# game/script.rpy:664
translate spanish con2_24796dbe:

    # n ". . ."
    n ". . ."

# game/script.rpy:665
translate spanish con2_b4e0d75d:

    # "You were choking on tears and were hysterical. Nick was standing right in front of you and watching it."
    "Te ahogabas en llanto, presa de la histeria. Nick estaba justo frente a ti, mirándolo todo."

# game/script.rpy:666
translate spanish con2_c84bb242:

    # n "Oh? Did it really hit your psyche so hard?"
    n "¿Oh? ¿De verdad te golpeó tanto la psique?"

# game/script.rpy:667
translate spanish con2_90c3a848:

    # n "It's just your legs! I will love you absolutely in any way, my dear. I don't care what you look like!"
    n "¡Son solo tus piernas! Te amaré absolutamente de cualquier manera, mi cielo. ¡No me importa cómo te veas!"

# game/script.rpy:668
translate spanish con2_5bacdc7b:

    # "You didn't hear what Nick was saying, it felt like your eardrums burst from the volume of your scream."
    "No oías lo que decía Nick, sentías que los tímpanos te habían reventado por el volumen de tu grito."

# game/script.rpy:669
translate spanish con2_232f0dc4:

    # "You didn't realize how much time had passed. But in the end, your voice was so hoarse that it hurt you to even breathe."
    "No te diste cuenta de cuánto tiempo había pasado. Pero al final tu voz estaba tan ronca que hasta respirar te dolía."

# game/script.rpy:671
translate spanish con2_a504ea09:

    # "There was no spark in your eyes anymore, there was no life in them. They were empty."
    "Ya no había chispa en tus ojos, no había vida en ellos. Estaban vacíos."

# game/script.rpy:672
translate spanish con2_e52d71cf:

    # "Nick has already tried to force you to eat meat several times, but you only screamed and vomited when you thought that this delicious-smelling dish is your precious flesh."
    "Nick ya había intentado obligarte a comer carne varias veces, pero tú solo gritabas y vomitabas al pensar que ese plato de olor delicioso era tu preciosa carne."

# game/script.rpy:673
translate spanish con2_c6b8e07f:

    # "There was silence in the room. You couldn't scream or cry anymore. You couldn't do anything else. Absolutely nothing."
    "Había silencio en la habitación. Ya no podías gritar ni llorar. No podías hacer nada más. Absolutamente nada."

# game/script.rpy:674
translate spanish con2_1d45277c:

    # "The guy was smiling sweetly, as if everything was fine."
    "El chico sonreía con dulzura, como si todo estuviera bien."

# game/script.rpy:675
translate spanish con2_0809974e:

    # n "My love..."
    n "Mi amor..."

# game/script.rpy:676
translate spanish con2_c56d371b:

    # n "Do you want to taste a piece?"
    n "¿Quieres probar un trozo?"

# game/script.rpy:688
translate spanish con2_46d81511:

    # n "...Really?"
    n "...¿En serio?"

# game/script.rpy:690
translate spanish con2_206f683e:

    # n "I want to give you a gift that was made by my hands... "
    n "Quiero darte un regalo hecho por mis manos... "

# game/script.rpy:691
translate spanish con2_65ba8bbe:

    # n "I was out of breath while I was dragging the two idiots' bodies back to my house away from that dump... "
    n "Me quedé sin aliento mientras arrastraba los cuerpos de esos dos idiotas de vuelta a mi casa, lejos de ese basurero... "

# game/script.rpy:692
translate spanish con2_22bd4f91:

    # n "I dug through their rotten, filthy corpses, I got dirty in their disgusting blood... "
    n "Hurgué entre sus cadáveres podridos y asquerosos, me ensucié con su repugnante sangre... "

# game/script.rpy:693
translate spanish con2_384b01c8:

    # n "I even made a box with my own hands!"
    n "¡Hasta hice una caja con mis propias manos!"

# game/script.rpy:695
translate spanish con2_9b582ece:

    # n "And you now refuse to simply accept it?!"
    n "¡¿Y ahora te niegas a simplemente aceptarlo?!"

# game/script.rpy:696
translate spanish con2_99feedc8:

    # n "Oh, my God! I'm in love with a monster!"
    n "¡Oh, Dios mío! ¡Estoy enamorado de un monstruo!"

# game/script.rpy:697
translate spanish con2_c837ad22:

    # n "You're just a moral freak! That's awful! "
    n "¡Eres un monstruo moral! ¡Qué horror! "

# game/script.rpy:698
translate spanish con2_bd111aef:

    # n "Do you want to make me cry? Good for you!"
    n "¿Quieres hacerme llorar? ¡Bien por ti!"

# game/script.rpy:699
translate spanish con2_875af66a:

    # n "I hope you enjoyed your act to the fullest. "
    n "Espero que hayas disfrutado tu acto al máximo. "

# game/script.rpy:700
translate spanish con2_7762bf74:

    # n "Because you're going to die and fall into the same box. And don't worry, I'll keep your corpse in my fridge forever!"
    n "Porque vas a morir y a caer en la misma caja. Y no te preocupes, ¡guardaré tu cadáver en mi nevera para siempre!"

# game/script.rpy:702
translate spanish con2_296a9a0a:

    # "You cried out in pain. A knife was stuck in your leg, Nick stabbed you several times, after which he cut the femoral artery."
    "Gritaste de dolor. Tenías un cuchillo clavado en la pierna; Nick te apuñaló varias veces y después te cortó la arteria femoral."

# game/script.rpy:703
translate spanish con2_894532a9:

    # "You were choking and crying in pain, but no one will find your corpse. He won't leave a single piece of it. In the name of love."
    "Te ahogabas y llorabas de dolor, pero nadie encontrará tu cadáver. No dejará ni un solo trozo. En nombre del amor."

# game/script.rpy:721
translate spanish con2_b5b20689:

    # yn "I don't want to die in an alley in the clutches of a serial killer..."
    yn "No quiero morir en un callejón entre las garras de un asesino en serie..."

# game/script.rpy:722
translate spanish con2_bdda06d6:

    # "{cps=20}The icy hands on your shoulders squeezed you tightly, but clasping your eyes, you hit someone's face upwards at random."
    "{cps=20}Las manos heladas sobre tus hombros te apretaron con fuerza, pero, con los ojos cerrados, golpeaste a ciegas hacia arriba el rostro de alguien."

# game/script.rpy:724
translate spanish con2_6f82758d:

    # "{cps=20}The man sighed heavily, but... let you go. Without waiting a second, you run away from there as fast as you can."
    "{cps=20}El hombre suspiró con pesadez, pero... te soltó. Sin esperar ni un segundo, huyes de allí a toda velocidad."

# game/script.rpy:727
translate spanish con2_46182524:

    # "All your senses were switched off, you were ruled only by the desire to survive."
    "Todos tus sentidos estaban apagados, te guiaba únicamente el deseo de sobrevivir."

# game/script.rpy:728
translate spanish con2_b1a599a7:

    # "{cps=15}You ran."
    "{cps=15}Corriste."

# game/script.rpy:729
translate spanish con2_b1a599a7_1:

    # "{cps=15}You ran."
    "{cps=15}Corriste."

# game/script.rpy:730
translate spanish con2_3b38fdea:

    # "{cps=15}Y o u r a n."
    "{cps=15}C o r r i s t e."

# game/script.rpy:731
translate spanish con2_8affa4b4:

    # "{cps=15}And ran."
    "{cps=15}Y corriste."

# game/script.rpy:732
translate spanish con2_8affa4b4_1:

    # "{cps=15}And ran."
    "{cps=15}Y corriste."

# game/script.rpy:733
translate spanish con2_e0190749:

    # "{cps=15}A n d r a n."
    "{cps=15}Y c o r r i s t e."

# game/script.rpy:738
translate spanish con2_29c83436:

    # "You quickly jump around some corner because you feel like you're about to faint."
    "Doblas rápidamente alguna esquina porque sientes que estás a punto de desmayarte."

# game/script.rpy:739
translate spanish con2_268dc66d:

    # "You need to catch your breath, or you won't be able to escape."
    "Necesitas recuperar el aliento, o no podrás escapar."

# game/script.rpy:740
translate spanish con2_1692dab7:

    # "You breathe as quietly as you can, but the sound echoes in your head, drowning out the ringing in your ears."
    "Respiras lo más silenciosamente que puedes, pero el sonido resuena en tu cabeza, ahogando el zumbido de tus oídos."

# game/script.rpy:741
translate spanish con2_e2924adf:

    # "It feels like you're screaming instead of trying to catch your breath."
    "Sientes como si gritaras en lugar de intentar recobrar el aliento."

# game/script.rpy:742
translate spanish con2_cc735bec:

    # "The steps seem to be gone. Perhaps the maniac who was chasing you ran ahead without noticing that you were hiding."
    "Parece que los pasos han desaparecido. Quizá el maniático que te perseguía se adelantó sin darse cuenta de que te escondías."

# game/script.rpy:748
translate spanish con2_ac22dfda:

    # "You slowly slide down the wet brick wall, wiping your face, neck, and collarbones with your sleeve."
    "Te deslizas lentamente por la pared de ladrillo mojada, limpiándote la cara, el cuello y las clavículas con la manga."

# game/script.rpy:749
translate spanish con2_4ebd1b65:

    # "It was soaked with blood, which was still flowing from the small wounds."
    "Estaba empapada de sangre, que aún manaba de las pequeñas heridas."

# game/script.rpy:750
translate spanish con2_60cfce55:

    # yn "Uh... So far, I don't feel any pain."
    yn "Eh... Por ahora, no siento ningún dolor."

# game/script.rpy:751
translate spanish con2_67f4d654:

    # yn "But in the hospital, it will be painful to pull out those tiny shards of glass."
    yn "Pero en el hospital va a doler sacar esos diminutos fragmentos de vidrio."

# game/script.rpy:752
translate spanish con2_99f8ea31_2:

    # "{cps=3}{sc}. . .{/sc}"
    "{cps=3}{sc}. . .{/sc}"

# game/script.rpy:753
translate spanish con2_286442c1:

    # "For a while you sat quietly in your hiding place."
    "Durante un rato permaneciste en silencio en tu escondite."

# game/script.rpy:754
translate spanish con2_2dff8907:

    # "{cps=15}Silence."
    "{cps=15}Silencio."

# game/script.rpy:755
translate spanish con2_0f4d1c22:

    # "It was frightening and reassuring at the same time."
    "Daba miedo y tranquilizaba al mismo tiempo."

# game/script.rpy:756
translate spanish con2_86678b93:

    # "But the fear that right now the maniac realized that they were not chasing anyone else, and had already turned around to find you, made your heart beat again with terrible speed."
    "Pero el miedo de que el maniático ya se hubiera dado cuenta de que no perseguía a nadie más y se hubiera dado la vuelta para buscarte hizo que tu corazón volviera a latir a una velocidad terrible."

# game/script.rpy:757
translate spanish con2_95ccc3c0:

    # "You slowly walk up without making a sound, and then you walk out onto the unlit road. It's cold in here. It's very cold."
    "Te levantas lentamente sin hacer ruido y sales a la calle sin iluminar. Aquí hace frío. Hace mucho frío."

# game/script.rpy:763
translate spanish con2_b7f3a85f:

    # no "{cps=10}So dumb."
    no "{cps=10}Qué estupidez."

# game/script.rpy:765
translate spanish con2_d305e9a3:

    # "A hot, throbbing pain pierced your stomach."
    "Un dolor caliente y palpitante te atravesó el estómago."

# game/script.rpy:767
translate spanish con2_a9b63117:

    # no "{cps=10}Such a stupid death, [name]."
    no "{cps=10}Qué muerte tan estúpida, [name]."

# game/script.rpy:780
translate spanish con2_c0ba3f03:

    # yn "Screw it. I'll just carefully take another road."
    yn "Qué más da. Simplemente tomaré con cuidado otro camino."

# game/script.rpy:781
translate spanish con2_1a45f80a:

    # "You try to speed up your step as much as possible, while remaining completely silent."
    "Intentas acelerar el paso todo lo posible, sin dejar de guardar un silencio absoluto."

# game/script.rpy:782
translate spanish con2_80dfc9f6:

    # "Rude voices rang out from the dark alley, a shiver ran through and you thanking heaven for not going in that direction."
    "Se oyeron voces groseras desde el oscuro callejón, un escalofrío te recorrió y diste gracias al cielo por no haber ido en esa dirección."

# game/script.rpy:786
translate spanish con2_f3f8b098:

    # "The new road took twice as long, but it was all lit up by street lamps, and you never saw suspicious people on your way."
    "El nuevo camino tardó el doble, pero estaba iluminado por completo con farolas, y nunca viste gente sospechosa en tu trayecto."

# game/script.rpy:787
translate spanish con2_de439059:

    # yn "Ah, the entranceway. I missed you already."
    yn "Ah, el portal. Ya te echaba de menos."

# game/script.rpy:793
translate spanish con2_fe05ffb9:

    # "The living room is dirty and smelly, but once you're here you're more relaxed."
    "La sala está sucia y huele mal, pero una vez que estás aquí te relajas más."

# game/script.rpy:794
translate spanish con2_52c15052:

    # "You pour yourself a coffee and get some yogurt out of the fridge."
    "Te sirves un café y sacas un yogur de la nevera."

# game/script.rpy:795
translate spanish con2_9661e328:

    # "It's a combination you don't like very much, but it has been your daily diet for quite some time. "
    "Es una combinación que no te gusta mucho, pero ha sido tu dieta diaria desde hace bastante tiempo. "

# game/script.rpy:796
translate spanish con2_58070ef6:

    # yn "Phew, I'll be sure to look for openings tomorrow... In the meantime, I'm going to bed, tomorrow is going to be a hard day."
    yn "Uf, mañana buscaré vacantes sin falta... Mientras tanto, me voy a la cama, mañana será un día difícil."

# game/script.rpy:801
translate spanish con2_afa04d57:

    # "You fall immediately onto the soft mattress and your eyelids are heavy, today's emotions have squeezed all the strength out of you."
    "Te dejas caer enseguida sobre el suave colchón y los párpados te pesan, las emociones de hoy te han exprimido todas las fuerzas."

# game/script.rpy:802
translate spanish con2_d2c28fd4:

    # "You rarely think about tomorrow, it's too hard. There is almost no one in your life, there is no one to hold on to. So do you have any sense or incentive to live?"
    "Rara vez piensas en el mañana, es demasiado duro. Casi no hay nadie en tu vida, no hay a quién aferrarte. Entonces, ¿tienes algún sentido o motivo para vivir?"

# game/script.rpy:803
translate spanish con2_a4c25be6:

    # yn "Haha, it seems that my annoying daily routine and desire to help at least someone has prompted me to do an idiotic thing."
    yn "Jaja, parece que mi molesta rutina diaria y mi deseo de ayudar al menos a alguien me han empujado a hacer una idiotez."

# game/script.rpy:804
translate spanish con2_b8be6ce5:

    # yn "But in general... Maybe it wasn't stupid. Maybe he'll fight back, thanks to me. "
    yn "Pero en general... Quizá no fue una estupidez. Quizá se defienda, gracias a mí. "

# game/script.rpy:807
translate spanish con2_e370e239:

    # "You smiled warmly. You'd like to believe that. "
    "Sonreíste con calidez. Te gustaría creerlo. "

# game/script.rpy:808
translate spanish con2_c879d2d3:

    # "You closed your eyes and thought about what awaits you tomorrow. But you'll get through it, life is not all sugar. You have to be able to cope with challenges."
    "Cerraste los ojos y pensaste en lo que te espera mañana. Pero lo superarás, la vida no es todo color de rosa. Hay que saber afrontar los desafíos."

# game/script.rpy:810
translate spanish con2_64b32245:

    # yn "Good night, my daily loneliness."
    yn "Buenas noches, mi soledad de cada día."

# game/script.rpy:812
translate spanish con2_0a6e67ed:

    # "{cps=10}Good night."
    "{cps=10}Buenas noches."

# game/script.rpy:826
translate spanish con2_27ee1063:

    # yn "I'm sorry, little one, but I still value my life. I have three more years to study here..."
    yn "Lo siento, pequeño, pero aun así valoro mi vida. Me quedan tres años más estudiando aquí..."

# game/script.rpy:827
translate spanish con2_80fc0724:

    # yn "...And I don't want to turn them into my personal hell."
    yn "...Y no quiero convertirlos en mi infierno personal."

# game/script.rpy:828
translate spanish con2_6f6c828d:

    # "You felt a prick of conscience, but only for a second. After all, you'd ignored bullying this guy for years, so what now?"
    "Sentiste una punzada de remordimiento, pero solo por un segundo. Después de todo, llevabas años ignorando el acoso a este chico, ¿y ahora qué?"

# game/script.rpy:829
translate spanish con2_0d48ebf3:

    # "Will you become a hero? Will you become the protector of the weak? You're not going to lie to yourself. It's stupid and pointless. "
    "¿Te convertirás en héroe? ¿En protector de los débiles? No vas a mentirte. Es estúpido y no sirve de nada. "

# game/script.rpy:834
translate spanish con2_76322b20:

    # "None of your friends are here today. These idiots are sick, or rather drunk and hangover. "
    "Hoy no vino ninguno de tus amigos. Esos idiotas están enfermos, o más bien borrachos y con resaca. "

# game/script.rpy:835
translate spanish con2_c19ceff1:

    # "You don't really like alcohol, even though your whole life is leading you down the path of alcohol or addiction."
    "No te gusta mucho el alcohol, aunque toda tu vida te conduce por el camino del alcohol o de las adicciones."

# game/script.rpy:836
translate spanish con2_3ad6e80b:

    # "But by happy coincidence, you became neither."
    "Pero, por una feliz coincidencia, no te convertiste en ninguna de las dos cosas."

# game/script.rpy:837
translate spanish con2_98cd9cbf:

    # "Even though everyone who's ever been to your house, the first thing they ask you is, «Are you getting high?»"
    "Aunque todo el que ha estado en tu casa, lo primero que te pregunta es «¿Te drogas?»"

# game/script.rpy:838
translate spanish con2_3201f261:

    # "You only smile crookedly at this. "
    "Tú solo sonríes de medio lado ante eso. "

# game/script.rpy:840
translate spanish con2_38ca1b88:

    # yn "Phew, finally a bell."
    yn "Uf, por fin el timbre."

# game/script.rpy:845
translate spanish con2_a6e157ff:

    # "You take a seat at the back desk. It's cozy."
    "Te sientas en el pupitre del fondo. Es acogedor."

# game/script.rpy:846
translate spanish con2_1e5857c4:

    # "Honestly, you love lessons, but you can't stand exams."
    "Sinceramente, te encantan las clases, pero no soportas los exámenes."

# game/script.rpy:847
translate spanish con2_cde71f34:

    # "When exam time came, all the knowledge instantly left your head. "
    "Cuando llegaba la época de exámenes, todo el conocimiento se te iba de la cabeza al instante. "

# game/script.rpy:848
translate spanish con2_cb28a83c:

    # "And during the tests, you received a satisfactory grade only thanks to your natural restraint, innate charm and entreaties. "
    "Y durante las pruebas, solo obtenías una nota suficiente gracias a tu compostura natural, tu encanto innato y tus ruegos. "

# game/script.rpy:849
translate spanish con2_f04eb076:

    # yn "If there were any of these knuckleheads here it would be more fun."
    yn "Si estuviera aquí alguno de esos cabezas huecas, sería más divertido."

# game/script.rpy:850
translate spanish con2_8f10da12:

    # "The whispering, the sound of a pencil sliding across paper, someone's quiet laughter all put you to sleep."
    "Los susurros, el sonido de un lápiz deslizándose sobre el papel, la risa tranquila de alguien: todo te adormece."

# game/script.rpy:854
translate spanish con2_363ee4f3:

    # yn "Uh... I'm so tired. Why?"
    yn "Uh... Qué cansancio tengo. ¿Por qué?"

# game/script.rpy:855
translate spanish con2_6349d066:

    # "Somehow you found it easier to sleep here than at home."
    "De alguna manera te resultaba más fácil dormir aquí que en casa."

# game/script.rpy:856
translate spanish con2_38b5a4ef:

    # "There you were constantly haunted by strange sounds and a feeling as if someone was watching you."
    "Allí te perseguían constantemente ruidos extraños y la sensación de que alguien te observaba."

# game/script.rpy:857
translate spanish con2_02c53fc2:

    # yn "It's so peaceful here."
    yn "Aquí hay tanta paz."

# game/script.rpy:858
translate spanish con2_94564a3c:

    # yn "I want to get some sleep."
    yn "Quiero dormir un rato."

# game/script.rpy:864
translate spanish con2_a3b4c77d:

    # "As soon as you close your eyes, you begin to hear the sound of slowly dripping water."
    "En cuanto cierras los ojos, empiezas a oír el sonido del agua goteando lentamente."

# game/script.rpy:865
translate spanish con2_52648d50:

    # "You don't feel your sweatshirt getting wet, so whatever."
    "No sientes que tu sudadera se moje, así que da igual."

# game/script.rpy:866
translate spanish con2_197a24e0:

    # "You start squirming in your chair. Something happens, something unpleasant."
    "Empiezas a retorcerte en la silla. Pasa algo, algo desagradable."

# game/script.rpy:867
translate spanish con2_8fb85877:

    # "Nothing hurts and no one is touching you, but you definitely feel uncomfortable."
    "Nada te duele y nadie te toca, pero sin duda sientes incomodidad."

# game/script.rpy:868
translate spanish con2_30ea0e11:

    # "It's like someone's staring at you."
    "Es como si alguien te estuviera mirando fijamente."

# game/script.rpy:869
translate spanish con2_1fcd8b43:

    # "You cover your face with your sleeve."
    "Te cubres la cara con la manga."

# game/script.rpy:870
translate spanish con2_81520882:

    # "The freaking noise of the drops got louder and louder."
    "El maldito ruido de las gotas se hacía cada vez más fuerte."

# game/script.rpy:871
translate spanish con2_76f6e29e:

    # "And louder."
    "Y más fuerte."

# game/script.rpy:872
translate spanish con2_4ecdac55:

    # "{sc}And louder.{/sc}"
    "{sc}Y más fuerte.{/sc}"

# game/script.rpy:873
translate spanish con2_76f6e29e_1:

    # "And louder."
    "Y más fuerte."

# game/script.rpy:874
translate spanish con2_4ecdac55_1:

    # "{sc}And louder.{/sc}"
    "{sc}Y más fuerte.{/sc}"

# game/script.rpy:875
translate spanish con2_76f6e29e_2:

    # "And louder."
    "Y más fuerte."

# game/script.rpy:876
translate spanish con2_0385cb6d:

    # "{sc}AND LOUDER.{/sc}"
    "{sc}Y MÁS FUERTE.{/sc}"

# game/script.rpy:880
translate spanish con2_d87b2cd5:

    # yn "{sc}DAMN IT!!!{/sc}"
    yn "{sc}¡¡¡MALDICIÓN!!!{/sc}"

# game/script.rpy:881
translate spanish con2_afec88c9:

    # "You jumped up from your seat."
    "Te levantaste de un salto de tu asiento."

# game/script.rpy:882
translate spanish con2_805e23b3:

    # "Everyone started staring at you."
    "Todos empezaron a mirarte fijamente."

# game/script.rpy:883
translate spanish con2_948dfe60:

    # "And it was disgustingly awkward."
    "Y fue asquerosamente incómodo."

# game/script.rpy:884
translate spanish con2_88f5f45f:

    # l "[name], your nose is bleeding! Go to the nurse!"
    l "¡[name], te sangra la nariz! ¡Ve a la enfermería!"

# game/script.rpy:885
translate spanish con2_dcac18c9:

    # "You touch your face. Your fingers are covered in blood."
    "Te tocas la cara. Tus dedos están cubiertos de sangre."

# game/script.rpy:886
translate spanish con2_5225432a:

    # "How did you not notice that? It's bleeding nonstop. Your nose is aching too."
    "¿Cómo no lo notaste? Sangra sin parar. También te duele la nariz."

# game/script.rpy:888
translate spanish con2_450ac57a:

    # yn "Sorry..."
    yn "Perdón..."

# game/script.rpy:892
translate spanish con2_377b73a0:

    # "You walk down the long hallway to the nurse's office and look under your feet."
    "Caminas por el largo pasillo hacia la enfermería mirando el suelo bajo tus pies."

# game/script.rpy:893
translate spanish con2_9184a53c:

    # "Truth be told, you only had to wash your face with cold water, but her office smells really cool."
    "A decir verdad, solo tenías que lavarte la cara con agua fría, pero su consulta huele de maravilla."

# game/script.rpy:894
translate spanish con2_3325bad0:

    # "That smell has become pretty native to you."
    "Ese olor se te ha vuelto bastante familiar."

# game/script.rpy:897
translate spanish con2_8d3d61a4:

    # "Suddenly you feel like you're bumping into someone. The collision wasn't violent, but someone ahead of you seems to have dropped the books from their hands. "
    "De repente sientes que chocas con alguien. El choque no fue violento, pero parece que alguien delante de ti dejó caer los libros que llevaba en las manos. "

# game/script.rpy:898
translate spanish con2_ff1d3097:

    # yn "Oh, sorry!"
    yn "¡Oh, perdón!"

# game/script.rpy:899
translate spanish con2_baffb17d:

    # "You don't even have time to reach out your bloody helping hand before the person in front of you has already picked up the fallen textbooks and jumped up on both feet."
    "Ni siquiera tienes tiempo de tender tu mano ensangrentada para ayudar antes de que la persona frente a ti ya haya recogido los libros caídos y se haya puesto en pie de un salto."

# game/script.rpy:900
translate spanish con2_5777c038:

    # u "Don't worry. People rarely apologize to me, haha, so I forgive you."
    u "No te preocupes. Rara vez me piden disculpas, jaja, así que te perdono."

# game/script.rpy:904
translate spanish con2_32ad1976:

    # "Oh shoot."
    "Oh, rayos."

# game/script.rpy:907
translate spanish con2_4f19cda6:

    # "Your cheeks seem to be getting even redder."
    "Tus mejillas parecen ponerse aún más rojas."

# game/script.rpy:908
translate spanish con2_2142c545:

    # "You felt a pang of conscience."
    "Sentiste una punzada de remordimiento."

# game/script.rpy:909
translate spanish con2_52249236:

    # yn "Aah, Nick... Hi..."
    yn "Aah, Nick... Hola..."

# game/script.rpy:913
translate spanish con2_fef46180:

    # n "You know my name?"
    n "¿Sabes mi nombre?"

# game/script.rpy:914
translate spanish con2_f9c79254:

    # "Nick didn't look upset or angry."
    "Nick no parecía molesto ni enfadado."

# game/script.rpy:915
translate spanish con2_af1ddf20:

    # yn "Ugh... You know, I'm sorry about this morning..."
    yn "Ugh... Oye, perdón por lo de esta mañana..."

# game/script.rpy:916
translate spanish con2_37210891:

    # "Even so, the guilt never left you, especially after looking at his bloody shirt."
    "Aun así, la culpa nunca te abandonó, sobre todo al mirar su camisa ensangrentada."

# game/script.rpy:917
translate spanish con2_67b81ab1:

    # n "Is it morning? What was this morning?"
    n "¿Esta mañana? ¿Qué pasó esta mañana?"

# game/script.rpy:918
translate spanish con2_220d72df:

    # yn "Um... You actually got fucked up by two guys. The blood's not even dry yet. How could you forget?"
    yn "Eh... A ti te dejaron hecho mierda dos tipos. La sangre ni siquiera está seca todavía. ¿Cómo pudiste olvidarlo?"

# game/script.rpy:921
translate spanish con2_5a6a10c5:

    # n "Ha! {sc}Hahahaha!{/sc}"
    n "¡Ja! {sc}¡Jajajaja!{/sc}"

# game/script.rpy:924
translate spanish con2_df3389ad:

    # n "Sorry, I know it looks creepy. It's just that this morning's beatings have become so... usual."
    n "Perdón, sé que parece espeluznante. Es solo que las palizas de esta mañana se han vuelto tan... habituales."

# game/script.rpy:925
translate spanish con2_18fa4aeb:

    # "It was really creepy. But you won't say it out loud."
    "Era realmente espeluznante. Pero no lo dirás en voz alta."

# game/script.rpy:926
translate spanish con2_289bd1a0:

    # yn "It's a pity you can't fight back. They shouldn't have to suffer that kind of bullshit. This morons, they piss me off! Sorry again."
    yn "Es una lástima que no puedas defenderte. No deberías tener que aguantar esas estupideces. ¡Esos idiotas me sacan de quicio! Perdón otra vez."

# game/script.rpy:929
translate spanish con2_9355261a:

    # n "Were you one of the ones who beat me, too?"
    n "¿Tú también fuiste de los que me golpearon?"

# game/script.rpy:930
translate spanish con2_82d36671:

    # yn "Um, no..."
    yn "Eh, no..."

# game/script.rpy:934
translate spanish con2_fe97fcd4:

    # n "Then you have nothing to apologize for."
    n "Entonces no tienes nada de lo que disculparte."

# game/script.rpy:937
translate spanish con2_98471f5c:

    # n "Moreover, it seems to me that this morning ritual has become something like a lovers' kiss when they meet."
    n "Además, me parece que este ritual matutino se ha vuelto algo así como el beso de unos enamorados al encontrarse."

# game/script.rpy:938
translate spanish con2_669b7520:

    # n "They seem to like me. Why else would they be so attached to me? Maybe someday they will turn from anger to love. Who knows?"
    n "Parece que les caigo bien. ¿Por qué otra razón estarían tan apegados a mí? Quizá algún día pasen de la ira al amor. ¿Quién sabe?"

# game/script.rpy:939
translate spanish con2_8dee6cf9:

    # "You had nothing to say."
    "No tenías nada que decir."

# game/script.rpy:940
translate spanish con2_d334318b:

    # "A few unintelligible sounds came out of your mouth, like a mixture of wheezing, giggle, and sobbing."
    "De tu boca salieron unos cuantos sonidos ininteligibles, mezcla de resuello, risita y sollozo."

# game/script.rpy:943
translate spanish con2_bbd35cc0:

    # n "I think I overreacted... I have a strange humor, I rarely talk to people, so I say whatever comes into my head..."
    n "Creo que reaccioné de forma exagerada... Tengo un humor extraño, rara vez hablo con la gente, así que digo lo primero que se me viene a la cabeza..."

# game/script.rpy:944
translate spanish con2_3822c85a:

    # yn "Don't worry about it. I think it's kind of cute."
    yn "No te preocupes. Me parece hasta lindo."

# game/script.rpy:947
translate spanish con2_d2d806b4:

    # n "Really? Oh... Thank you. It's very comfortable and pleasant to be around you."
    n "¿En serio? Oh... Gracias. Es muy cómodo y agradable estar contigo."

# game/script.rpy:948
translate spanish con2_0c556460:

    # yn "Heh, thanks, I guess. You turned out to be a really good guy."
    yn "Je, gracias, supongo. Resultaste ser una buena persona."

# game/script.rpy:949
translate spanish con2_3e7aca6f:

    # "You chuckled and then felt a little dizzy. There's still blood coming out of your nose."
    "Te reíste entre dientes y luego sentiste un poco de mareo. Todavía te sale sangre de la nariz."

# game/script.rpy:950
translate spanish con2_c25e8698:

    # yn "Damn! I have to get out of here. Sorry to be rude, but why didn't you remind me that I'm bleeding like a freaking bucket?!"
    yn "¡Maldición! Tengo que salir de aquí. Perdón por la grosería, pero ¿por qué no me recordaste que estoy sangrando como un maldito balde?"

# game/script.rpy:951
translate spanish con2_670df9ea:

    # n "Oh... I'm sorry. I think I was drugged. "
    n "Oh... Perdón. Creo que me drogaron. "

# game/script.rpy:952
translate spanish con2_460cfa56:

    # yn "With what?"
    yn "¿Con qué?"

# game/script.rpy:954
translate spanish con2_b06c9076:

    # n "That smell."
    n "Ese olor."

# game/script.rpy:957
translate spanish con2_ea2c74db:

    # n "Ahhh... Your blood type is AB-negative!"
    n "Ahhh... ¡Tu tipo de sangre es AB negativo!"

# game/script.rpy:958
translate spanish con2_e6262ed8:

    # n "{sc}Am I right? Am I right?{/sc}"
    n "{sc}¿Tengo razón? ¿Tengo razón?{/sc}"

# game/script.rpy:959
translate spanish con2_b0c3943f:

    # "You see this guy start literally shaking. Are those drops of sweat on his face? What is going on..."
    "Ves cómo este chico empieza a temblar literalmente. ¿Son gotas de sudor en su cara? Qué está pasando..."

# game/script.rpy:960
translate spanish con2_c763d727:

    # yn "Uh, I'm gonna go. See ya."
    yn "Eh, ya me voy. Nos vemos."

# game/script.rpy:964
translate spanish con2_cf887c43:

    # "This strange change of mood has put you in a stupor. What the hell?"
    "Este extraño cambio de humor te ha dejado en estado de shock. ¿Qué demonios?"

# game/script.rpy:965
translate spanish con2_bd886fea:

    # "Has he been talking to you all this time just to smell blood? You can't get your head around it..."
    "¿Ha estado hablando contigo todo este tiempo solo para oler sangre? No logras entenderlo..."

# game/script.rpy:969
translate spanish con2_168ead17:

    # "You walked quickly to the nurse's office. Behind your back there was giggling and whispering. And it scared out of you."
    "Caminaste rápido hacia la enfermería. A tus espaldas había risitas y susurros. Y te dio un susto de muerte."

# game/script.rpy:970
translate spanish con2_8534ca42_2:

    # ". . ."
    ". . ."

# game/script.rpy:974
translate spanish con2_59ce19f3:

    # "Thank God you didn't cross paths with Nick the rest of the day. The man never left your mind for a minute. Maybe it was his fetish. Whatever..."
    "Gracias a Dios no te cruzaste con Nick el resto del día. Ese chico no se te fue de la cabeza ni un minuto. Quizá era su fetiche. Qué más da..."

# game/script.rpy:975
translate spanish con2_4bbb41fc:

    # "But how the hell did he know your blood type?"
    "Pero ¿cómo demonios sabía tu tipo de sangre?"

# game/script.rpy:976
translate spanish con2_1050b65c:

    # yn "Each guess was worse than the last... But he couldn't tell it by the SMELL, could he?"
    yn "Cada suposición era peor que la anterior... Pero no pudo saberlo por el OLOR, ¿o sí?"

# game/script.rpy:977
translate spanish con2_c4d5a85c:

    # "You spent the whole way thinking about it."
    "Pasaste todo el camino pensando en ello."

# game/script.rpy:980
translate spanish con2_726a0347:

    # "This time you didn't even have time for the daily scare of the road lying between the university and your home."
    "Esta vez ni siquiera tuviste tiempo para el susto diario del camino que hay entre la universidad y tu casa."

# game/script.rpy:981
translate spanish con2_d3061bb8:

    # yn "I'm finally here. Phew..."
    yn "Por fin llegué. Uf..."

# game/script.rpy:982
translate spanish con2_57507e8e:

    # yn "Why am I so worried? There are a lot of fuck-ups in this world, and he looks harmless than most."
    yn "¿Por qué me preocupo tanto? Hay muchos desquiciados en este mundo, y él parece más inofensivo que la mayoría."

# game/script.rpy:983
translate spanish con2_a93ca4b0:

    # yn "And we study in different buildings, so I don't think we'll be seeing each other again anytime soon."
    yn "Y estudiamos en edificios distintos, así que no creo que volvamos a vernos pronto."

# game/script.rpy:988
translate spanish con2_b041431b:

    # yn "MY ROOM! I'm finally here!"
    yn "¡MI HABITACIÓN! ¡Por fin llegué!"

# game/script.rpy:990
translate spanish con2_2e8cd8a7:

    # "Time flew by unnoticed in this place. Ah, a warm blanket, a soft pillow, a pile of plush toys..."
    "El tiempo voló sin darte cuenta en este lugar. Ah, una manta calentita, una almohada suave, una montaña de peluches..."

# game/script.rpy:991
translate spanish con2_e146eee3:

    # "You always wanted to live separately from your parents, but despite your confidence in your abilities you had no idea that there were SO MANY difficulties waiting for you. "
    "Siempre quisiste vivir lejos de tus padres, pero a pesar de tu confianza en tus capacidades no tenías idea de que te esperaban TANTAS dificultades. "

# game/script.rpy:992
translate spanish con2_b3d801c3:

    # "Study, work, take care of yourself. It doesn't sound very hard, but in practice you have to make some sacrifices."
    "Estudiar, trabajar, cuidar de ti. No suena muy difícil, pero en la práctica hay que hacer algunos sacrificios."

# game/script.rpy:993
translate spanish con2_a409b274:

    # yn "If I can't find the money, I'll soon lose my roof over my head. Fred can't lend me money forever... "
    yn "Si no consigo el dinero, pronto perderé el techo sobre mi cabeza. Fred no puede prestarme dinero para siempre... "

# game/script.rpy:994
translate spanish con2_480ab3c0:

    # "Sometimes you think about the fact that it was better to take care of your safety in the first place than the price of these cheap apartments."
    "A veces piensas que habría sido mejor ocuparte primero de tu seguridad antes que del precio de estos baratos apartamentos."

# game/script.rpy:995
translate spanish con2_e043811a:

    # "How many crimes have occurred in this area in the last month? About fifteen?"
    "¿Cuántos delitos ha habido en esta zona el último mes? ¿Unos quince?"

# game/script.rpy:996
translate spanish con2_1b0b47f6:

    # "But that really paled in comparison to the freedom you were given. Life is not sugar, you often repeat that to yourself. "
    "Pero eso palidecía en comparación con la libertad que te dieron. La vida no es de color de rosa, a menudo te lo repites. "

# game/script.rpy:997
translate spanish con2_b7824bd9:

    # yn "Ugh, I wish one of my friends were here..."
    yn "Ugh, ojalá estuviera aquí alguno de mis amigos..."

# game/script.rpy:999
translate spanish con2_0f419bb8:

    # "You twist the bloody pendant on the necklace between your fingers."
    "Giras entre los dedos el colgante ensangrentado del collar."

# game/script.rpy:1000
translate spanish con2_995fa77a:

    # yn "Um... I may be a little doubtful about my wish now."
    yn "Eh... Quizá ahora dudo un poco de mi deseo."

# game/script.rpy:1001
translate spanish con2_b0b2be01:

    # "You slowly got out of bed and went into the hallway. Who could it be? You don't get visitors very often. "
    "Te levantaste lentamente de la cama y saliste al pasillo. ¿Quién podría ser? No recibes visitas muy a menudo. "

# game/script.rpy:1005
translate spanish con2_c8651006:

    # "You open the flimsy door and a cold sweat breaks out."
    "Abres la endeble puerta y te brota un sudor frío."

# game/script.rpy:1009
translate spanish con2_3a7e65db:

    # "You try to slam it back down with a crumpled whisper: «Uh, I'm already going to bed» but suddenly Nick pulls the door toward you, stepping inside."
    "Intentas cerrarla de golpe con un susurro arrugado: «Eh, ya me iba a la cama», pero de repente Nick tira de la puerta hacia sí y entra."

# game/script.rpy:1013
translate spanish con2_1af034dd:

    # "Your feet are shaking. Where did he get so much strength from?"
    "Te tiemblan los pies. ¿De dónde sacó tanta fuerza?"

# game/script.rpy:1016
translate spanish con2_786fd161:

    # n "Hi there... I came to visit!"
    n "Hola... ¡Vine de visita!"

# game/script.rpy:1017
translate spanish con2_94929b7c:

    # "Nick smiled sweetly, but his pretty face didn't reassure you at all."
    "Nick sonrió con dulzura, pero su bonito rostro no te tranquilizó en absoluto."

# game/script.rpy:1018
translate spanish con2_a0a2b64a:

    # yn "O-okay? Yeah... It's actually pretty late, don't you think?"
    yn "¿V-vale? Sí... En realidad es bastante tarde, ¿no crees?"

# game/script.rpy:1019
translate spanish con2_840034ca:

    # yn "{size=-5}And I don't remember inviting you over...{/size=-5}"
    yn "{size=-5}Y no recuerdo haberte invitado...{/size=-5}"

# game/script.rpy:1020
translate spanish con2_befd772d:

    # "That phrase you said in a whisper."
    "Esa frase que dijiste en un susurro."

# game/script.rpy:1021
translate spanish con2_1ad0215b:

    # n "Invited."
    n "Invitado."

# game/script.rpy:1022
translate spanish con2_eaf9d10a:

    # yn "What?"
    yn "¿Qué?"

# game/script.rpy:1023
translate spanish con2_ecd7de5b:

    # n "{sc}I. Was. Invited. By. You.{/sc} Isn't that why you chatted so nicely with me this morning?"
    n "{sc}Fui. Invitado. Por. Ti.{/sc} ¿No es por eso que charlaste tan amablemente conmigo esta mañana?"

# game/script.rpy:1026
translate spanish con2_fd5e7cb6:

    # n "Are we friends? Do you like me? Oh, you're crazy about me, I can see that!"
    n "¿Somos amigos? ¿Te gusto? Oh, ¡me adoras, lo veo!"

# game/script.rpy:1028
translate spanish con2_938e8d9e:

    # n "{cps=15}{sc} I can smell that...{/sc}"
    n "{cps=15}{sc} Lo huelo...{/sc}"

# game/script.rpy:1029
translate spanish con2_82ac8e3b:

    # "You slowly retreat back to your room. The phone is there, you need to get the damn phone right away."
    "Retrocedes lentamente hacia tu habitación. El teléfono está ahí, necesitas agarrar el maldito teléfono ya."

# game/script.rpy:1032
translate spanish con2_6f042e9d:

    # n "Where are you trying to run to?"
    n "¿A dónde intentas huir?"

# game/script.rpy:1035
translate spanish con2_bca5983e:

    # n "{sc}WHERE THE FUCK ARE YOU TRYING TO RUN TO?!{/sc}"
    n "{sc}¡¿A DÓNDE CARAJO INTENTAS HUIR?!{/sc}"

# game/script.rpy:1038
translate spanish con2_1cca7087:

    # "Screw everything. You jump up and run to your room, slamming the door behind you."
    "A la mierda todo. Saltas y corres a tu habitación, cerrando la puerta de un portazo."

# game/script.rpy:1039
translate spanish con2_df48db8d:

    # "You frantically look for your phone."
    "Buscas tu teléfono frenéticamente."

# game/script.rpy:1040
translate spanish con2_0771ba0d:

    # n "I'm sorry, I'm sorry! I shouldn't have yelled at you... It's just that you drive me crazy, really..."
    n "¡Perdón, perdón! No debí gritarte... Es que me vuelves loco, de verdad..."

# game/script.rpy:1041
translate spanish con2_4e73e9f7:

    # "You heard pitying moans on the other side of the door. His voice sounded so different that you knew it was still him."
    "Oíste lamentos lastimeros al otro lado de la puerta. Su voz sonaba tan distinta que supiste que seguía siendo él."

# game/script.rpy:1042
translate spanish con2_803f0270:

    # n "{sc} Do you really think this thin shit is going to hold me back?{/sc}"
    n "{sc} ¿De verdad crees que esta basura tan fina va a detenerme?{/sc}"

# game/script.rpy:1043
translate spanish con2_5b8f07c4:

    # n "{sc}I'll give you five seconds, and then I'll knock it out.{/sc}"
    n "{sc}Te doy cinco segundos, y luego la echo abajo.{/sc}"

# game/script.rpy:1044
translate spanish con2_8abf8607:

    # n "{cps=10}And we'll be together... forever."
    n "{cps=10}Y estaremos juntos... para siempre."

# game/script.rpy:1045
translate spanish con2_6265054b:

    # "You felt vomit coming to your throat. The damn phone was gone."
    "Sentiste que el vómito te subía a la garganta. El maldito teléfono había desaparecido."

# game/script.rpy:1046
translate spanish con2_955bef60:

    # n "Five."
    n "Cinco."

# game/script.rpy:1047
translate spanish con2_21f88831:

    # "You ran to the window, but you remembered too late that there were bars."
    "Corriste a la ventana, pero recordaste demasiado tarde que tenía rejas."

# game/script.rpy:1048
translate spanish con2_a4d4ca48:

    # yn "CRAP!"
    yn "¡MIERDA!"

# game/script.rpy:1049
translate spanish con2_b68daf38:

    # n "Four."
    n "Cuatro."

# game/script.rpy:1050
translate spanish con2_62637701:

    # "The only weapon in your room was a small office knife, which you grabbed and held to your chest with your trembling hands."
    "La única arma de tu habitación era una pequeña navaja de oficina, que agarraste y sostuviste contra el pecho con las manos temblorosas."

# game/script.rpy:1051
translate spanish con2_4484b796:

    # n "Three."
    n "Tres."

# game/script.rpy:1052
translate spanish con2_b1652bcb:

    # "You hid so that you could jump out at Nick as soon as he walked into your room."
    "Te escondiste para poder saltarle encima a Nick en cuanto entrara a tu habitación."

# game/script.rpy:1053
translate spanish con2_f080e345:

    # n "Two."
    n "Dos."

# game/script.rpy:1054
translate spanish con2_b40a45b8:

    # "At the last second, you ripped off your necklace and threw it into another corner of the room."
    "En el último segundo, te arrancaste el collar y lo lanzaste a otro rincón de la habitación."

# game/script.rpy:1056
translate spanish con2_1910ef44:

    # n "{cps=9}One. I'm coming, my love."
    n "{cps=9}Uno. Ya voy, mi amor."

# game/script.rpy:1058
translate spanish con2_8988f04d:

    # "As soon as the door was broken down you jumped out of cover and hit where Nick's stomach was supposed to be, but..."
    "En cuanto derribaron la puerta saliste de tu escondite y golpeaste donde se suponía que estaba el estómago de Nick, pero..."

# game/script.rpy:1059
translate spanish con2_e7cd8ad9:

    # "{cps=11}There was no one in front of you."
    "{cps=11}No había nadie frente a ti."

# game/script.rpy:1064
translate spanish con2_766ead15:

    # "He looked out of the aisle at you."
    "Se asomó desde el pasillo y te miró."

# game/script.rpy:1065
translate spanish con2_0dcd2968:

    # "With a jerk, Nick came into the room and grabbed you by the neck, lifting you up off the floor. "
    "De un tirón, Nick entró en la habitación y te agarró por el cuello, levantándote del suelo. "

# game/script.rpy:1066
translate spanish con2_40a097b5:

    # "He laughed, but you couldn't hear it."
    "Se rio, pero no pudiste oírlo."

# game/script.rpy:1067
translate spanish con2_d6ecbb4e:

    # n "Were you seriously thinking of killing me with THIS? Such idiocy, but your lust for life is unbelievably cute."
    n "¿De verdad pensabas matarme con ESTO? Qué estupidez, pero tus ganas de vivir son increíblemente tiernas."

# game/script.rpy:1068
translate spanish con2_a334d263:

    # "Nick threw you on the bed and immediately sat on top of you, not letting you move, he grabbed the knife, and with his other hand he kept giving it to your neck."
    "Nick te arrojó sobre la cama y se sentó de inmediato encima de ti, sin dejarte moverte; tomó el cuchillo y con la otra mano te sujetaba el cuello."

# game/script.rpy:1069
translate spanish con2_3c29efa0:

    # n "The closeness of your blood excites me... Ah, how long I've wanted to do this."
    n "La cercanía de tu sangre me excita... Ah, cuánto tiempo llevo queriendo hacer esto."

# game/script.rpy:1071
translate spanish con2_f24d6d6c:

    # "Tears spurted from your eyes and a muffled croak came from your throat. That bastard cut into your stomach."
    "Brotaron lágrimas de tus ojos y un graznido ahogado salió de tu garganta. Ese bastardo te abrió el estómago."

# game/script.rpy:1072
translate spanish con2_ea959fef:

    # "You could feel your tissues tearing and wet, warm organs coming out."
    "Sentías cómo se desgarraban tus tejidos y salían órganos húmedos y tibios."

# game/script.rpy:1073
translate spanish con2_43bffb0e:

    # "You were almost suffocating with pain, it felt like you were in pain with every cell of your body being torn by a blunt blade. "
    "Casi te asfixiabas de dolor, sentías dolor en cada célula del cuerpo, desgarrado por una hoja sin filo. "

# game/script.rpy:1074
translate spanish con2_7d1c62ae:

    # "Nick smiled and let go of your neck. You're going to die anyway, so why keep trying to hold you?"
    "Nick sonrió y te soltó el cuello. De todos modos vas a morir, ¿para qué seguir sujetándote?"

# game/script.rpy:1076
translate spanish con2_376bb387:

    # "He ran his hand inside your organs, stroking them, pulling them outward, and then leaned over and licked them."
    "Metió la mano entre tus órganos, acariciándolos, sacándolos hacia afuera, y luego se inclinó y los lamió."

# game/script.rpy:1077
translate spanish con2_75565c10:

    # "You saw him leaning over your gutted belly and throwing up. Tears rolled down your cheeks one last time, and then only darkness followed."
    "Lo viste inclinado sobre tu vientre abierto, vomitando. Las lágrimas rodaron por tus mejillas por última vez, y después solo hubo oscuridad."

# game/script.rpy:1078
translate spanish con2_3c916c8d:

    # "Nick didn't need you alive. He whispered declarations of love to your body, your organs, your blood."
    "Nick no te necesitaba con vida. Le susurraba declaraciones de amor a tu cuerpo, a tus órganos, a tu sangre."

# game/script.rpy:1079
translate spanish con2_6d6bf600:

    # "Nick gently kissed your still warm neck, gently touched each finger on your hand with his lips and licked the blood."
    "Nick besó con ternura tu cuello aún tibio, tocó con los labios, uno por uno, cada dedo de tu mano y lamió la sangre."

# game/script.rpy:1080
translate spanish con2_46ee7ad4:

    # "He slid his fingers over your wet, sticky body and whispered how beautiful you were."
    "Deslizó los dedos por tu cuerpo húmedo y pegajoso y susurró que eras una auténtica belleza."

# game/script.rpy:1081
translate spanish con2_25ab9563:

    # n "Oh my God, you're so warm... Do you love me that much? Yes, I know that you love me. Please give me the wonderful sweet taste of your insides."
    n "Oh, Dios mío, qué calidez tienes... ¿Me amas tanto? Sí, sé que me amas. Por favor, dame el maravilloso y dulce sabor de tu interior."

# game/script.rpy:1085
translate spanish con2_5f220dbe:

    # n "{cps=15}{sc}You're all fucking mine.{/sc}"
    n "{cps=15}{sc}Me perteneces por completo, maldita sea.{/sc}"

# game/script.rpy:1099
translate spanish con2_ac9650be:

    # "You hastily say something like «hellohowareyouyeahhaveagoodday», which merges into one word, and then you leave."
    "Dices apresuradamente algo como «holacómoestássíquetengasbuendía», que se funde en una sola palabra, y te vas."

# game/script.rpy:1100
translate spanish con2_4a2e9e74:

    # "Seems like Nick tried to stop you and say something, but you can't hear him anymore."
    "Parece que Nick intentó detenerte y decirte algo, pero ya no lo oyes."

# game/script.rpy:1104
translate spanish con2_13e74f5c:

    # "Oh, silence at last. The only pleasant sound was the quiet noise of the street, which you hear from the ajar window."
    "Ah, por fin silencio. El único sonido agradable era el tenue ruido de la calle, que oyes desde la ventana entreabierta."

# game/script.rpy:1105
translate spanish con2_358bc7cd:

    # "The nurse is absent as usual, it seems she spends all her working time at lunch or on a smoke break."
    "La enfermera está ausente como siempre, parece que pasa todo su horario de trabajo almorzando o fumando."

# game/script.rpy:1106
translate spanish con2_084ebafe:

    # "But you don't need her presence, you know very well where everything you need is. "
    "Pero no necesitas su presencia, sabes muy bien dónde está todo lo que necesitas. "

# game/script.rpy:1107
translate spanish con2_5e8ff2cf:

    # "You tear off a small piece of absorbent cotton and shove it up your nose. It bleeds a lot, so it soaks up the blood very quickly. "
    "Arrancas un trocito de algodón absorbente y te lo metes en la nariz. Sangra mucho, así que absorbe la sangre muy rápido. "

# game/script.rpy:1109
translate spanish con2_70f593f8:

    # "Your head is a little dizzy, you sit down on the couch."
    "Te da un poco de vueltas la cabeza, te sientas en el sofá."

# game/script.rpy:1110
translate spanish con2_4d970dc3:

    # "You're definitely not up for a lecture today. "
    "Definitivamente hoy no tienes ánimo para ninguna clase. "

# game/script.rpy:1111
translate spanish con2_4a3736a6:

    # yn "How about lying here for a while? Like until the nurse comes. I mean, it's definitely until the evening, maybe not the evening of this day."
    yn "¿Y si me tumbo aquí un rato? Digamos hasta que llegue la enfermera. O sea, seguro que es hasta la noche, tal vez no la noche de hoy."

# game/script.rpy:1113
translate spanish con2_e12215c7:

    # "The surface of the couch is cold, but just a couple of minutes later it is already warm from your body."
    "La superficie del sofá está fría, pero apenas un par de minutos después ya está tibia por tu cuerpo."

# game/script.rpy:1114
translate spanish con2_dd14aa3a:

    # "Quiet, nice smelling, peaceful place."
    "Un lugar tranquilo, de buen olor, apacible."

# game/script.rpy:1115
translate spanish con2_85a6cd19:

    # "You slowly fall asleep."
    "Te vas durmiendo poco a poco."

# game/script.rpy:1118
translate spanish con2_aaee4119:

    # "You sleep quite lightly, so you hear the door creaking. Someone came into the office, probably to get a Band-Aid or something."
    "Duermes con bastante ligereza, así que oyes crujir la puerta. Alguien entró en la enfermería, probablemente a por una tirita o algo así."

# game/script.rpy:1119
translate spanish con2_257703af:

    # "You lie here quite often, so you know from experience that if you disturb someone, they'll just wake you up."
    "Te tumbas aquí con bastante frecuencia, así que sabes por experiencia que si estorbas a alguien, simplemente te despertarán."

# game/script.rpy:1120
translate spanish con2_7bc5ffbf:

    # "There is absolute silence in the office. You seem to be the only one here again."
    "Hay un silencio absoluto en la enfermería. Parece que otra vez no hay nadie más que tú."

# game/script.rpy:1121
translate spanish con2_f6521eb6:

    # "{cps=15}But you feel there's something wrong here."
    "{cps=15}Pero sientes que algo no va bien aquí."

# game/script.rpy:1122
translate spanish con2_495528f4:

    # "It's like someone's silhouette is in front of you."
    "Es como si la silueta de alguien estuviera frente a ti."

# game/script.rpy:1123
translate spanish con2_d2ae4cbe:

    # yn "«If I open my eyes for a second, nothing will happen. I'll calm myself down, and then I'll just go back to sleep»"
    yn "«Si abro los ojos un segundo, no pasará nada. Me tranquilizaré y luego volveré a dormirme»"

# game/script.rpy:1124
translate spanish con2_0982ccbd:

    # "You hesitate for a while and wonder if it's worth it, something seems to stop you. "
    "Dudas un rato y te preguntas si vale la pena; algo parece detenerte. "

# game/script.rpy:1125
translate spanish con2_150f43d2:

    # "{cps=10}Come on."
    "{cps=10}Vamos."

# game/script.rpy:1128
translate spanish con2_08f3f1fc:

    # "{cps=90}It's still a bit of a blur in front of your eyes.{w=0.2}{nw}"
    "{cps=90}Todavía ves un poco borroso.{w=0.2}{nw}"

# game/script.rpy:1129
translate spanish con2_c7104103:

    # "{sc}WHAT THE FUCK IS THAT.{/sc}"
    "{sc}QUÉ CARAJO ES ESO.{/sc}"

# game/script.rpy:1131
translate spanish con2_fa259d1f:

    # "Sleep instantly leaves your body and a cold sweat breaks out."
    "El sueño abandona al instante tu cuerpo y te brota un sudor frío."

# game/script.rpy:1132
translate spanish con2_2b437507:

    # "You couldn't move from fright."
    "No podías moverte del susto."

# game/script.rpy:1133
translate spanish con2_d02ea59a:

    # yn "Nick? W-what are you doing here?"
    yn "¿Nick? ¿Q-qué haces aquí?"

# game/script.rpy:1134
translate spanish con2_dc13e9af:

    # "You didn't just get the impression that the guy was sitting in front of you, he was literally devouring you with his gaze. "
    "No solo tuviste la impresión de que el chico estaba sentado frente a ti, sino que literalmente te devoraba con la mirada. "

# game/script.rpy:1135
translate spanish con2_91d0f133:

    # "You wouldn't have cared about such a prank, but there was something bloody in that look. This man certainly wasn't going to let you go just like that."
    "Una broma así te habría dado igual, pero había algo sanguinario en esa mirada. Este chico desde luego no pensaba dejarte ir así como así."

# game/script.rpy:1138
translate spanish con2_638f47a8:

    # "When Nick grinned, you jumped up sharply from your bunk and tried to rush to the door."
    "Cuando Nick sonrió con malicia, te levantaste de un salto de tu camastro e intentaste correr hacia la puerta."

# game/script.rpy:1140
translate spanish con2_0d98726a:

    # "But you were rudely intercepted, dropping to the floor."
    "Pero te interceptaron con rudeza y caíste al suelo."

# game/script.rpy:1144
translate spanish con2_a88a76f9:

    # "You felt blood starting to flow from your forehead. You were roughly pressed against the icy tiles of the floor. "
    "Sentiste que la sangre empezaba a brotarte de la frente. Te presionaron con fuerza contra las baldosas heladas del suelo. "

# game/script.rpy:1145
translate spanish con2_42d0f60d:

    # "Nick had his hand over your mouth, his grip was so strong that you couldn't even turn your head sideways."
    "Nick te tapaba la boca con la mano, su agarre era tan fuerte que ni siquiera podías girar la cabeza hacia un lado."

# game/script.rpy:1146
translate spanish con2_dcfadd78:

    # "You began to shake and tears came to your eyes. You were so fucking scared to even think about what he was going to do next. "
    "Empezaste a temblar y las lágrimas te asomaron a los ojos. Tenías demasiado miedo, joder, hasta para pensar en lo que haría después. "

# game/script.rpy:1147
translate spanish con2_c2aa1f67:

    # "You felt your hands tighten with a belt. The guy sat down gently on your lower back, and you realized that he wasn't trying to crush you with his weight. "
    "Sentiste que te apretaban las manos con un cinturón. El chico se sentó con suavidad sobre tu zona lumbar, y comprendiste que no intentaba aplastarte con su peso. "

# game/script.rpy:1148
translate spanish con2_d6ed920c:

    # "You close your eyes, before which there was already darkness. His hand runs gently through your hair, over your face, and down your neck. "
    "Cierras los ojos, ante los cuales ya había oscuridad. Su mano recorre con suavidad tu pelo, tu rostro y baja por tu cuello."

# game/script.rpy:1149
translate spanish con2_c79e0f71:

    # "And it was insanely weird, considering he had just cracked your forehead on the floor."
    "Y era una locura de raro, teniendo en cuenta que acababa de estrellarte la frente contra el suelo."

# game/script.rpy:1150
translate spanish con2_4dcb0e32:

    # n "Does it hurt? Sorry, I just didn't want you to run away, darling."
    n "¿Te duele? Perdón, solo no quería que huyeras, cariño."

# game/script.rpy:1151
translate spanish con2_00397953:

    # "You started to feel nauseous. What the hell is he talking about?"
    "Empezaste a sentir náuseas. ¿De qué demonios habla?"

# game/script.rpy:1152
translate spanish con2_624e2fd9:

    # "The guy leaned over you and you felt his warm tongue coming against your cheek. Only after a few disgusted licks did you realize that he wasn't playing with you this way..."
    "El chico se inclinó sobre ti y sentiste su lengua tibia contra tu mejilla. Solo después de varios lametones asquerosos comprendiste que no estaba jugando contigo..."

# game/script.rpy:1153
translate spanish con2_32e84e55:

    # "...he was licking your blood. "
    "...lamía tu sangre. "

# game/script.rpy:1154
translate spanish con2_dd50e921:

    # "Nick's hand continued to gently touch your body, stroking your back, your arms, your legs, but he went no further. "
    "La mano de Nick seguía tocando con suavidad tu cuerpo, acariciándote la espalda, los brazos, las piernas, pero no iba más allá. "

# game/script.rpy:1155
translate spanish con2_7496c43d:

    # "His long hair tickled your face, but you weren't laughing at all. Nick picked up the blood dripping on the floor with his tongue one last time, and then gently kissed you on the cheek. "
    "Su largo cabello te hacía cosquillas en la cara, pero no te reías en absoluto. Nick recogió con la lengua, por última vez, la sangre que goteaba en el suelo, y luego te besó con ternura en la mejilla. "

# game/script.rpy:1156
translate spanish con2_e335e76c:

    # "After that, he suddenly pulled away from you."
    "Después de eso, se apartó de ti de repente."

# game/script.rpy:1159
translate spanish con2_f14cd917:

    # "You started praying to heaven that he would just go away, but then there was a metallic clang behind you."
    "Empezaste a rezar al cielo para que simplemente se fuera, pero entonces se oyó un golpe metálico a tus espaldas."

# game/script.rpy:1160
translate spanish con2_213289a3:

    # n "Sorry, this is going to hurt. But I'll kiss the place where it hurts. Okay? Please be patient, sweetheart. "
    n "Perdón, esto va a doler. Pero besaré el lugar que duela. ¿Vale? Por favor, ten paciencia, mi vida. "

# game/script.rpy:1161
translate spanish con2_38c048aa:

    # n "{cps=15}You won't feel {i}anything{/i} soon."
    n "{cps=15}Pronto no sentirás {i}nada{/i}."

# game/script.rpy:1162
translate spanish con2_725f5e15:

    # "It feels like your voice is gone. You don't understand what's going on. Could this be a joke? No, no, he can't just kill you... "
    "Sientes como si se te hubiera ido la voz. No entiendes qué pasa. ¿Será una broma? No, no, no puede matarte sin más... "

# game/script.rpy:1164
translate spanish con2_46bb33af:

    # "There are footsteps near you. He seems to have sat on his knees next to you."
    "Hay pasos cerca de ti. Parece que se arrodilló a tu lado."

# game/script.rpy:1166
translate spanish con2_964d5045:

    # "Nick strokes your face and you feel his hot breath very close to your lips. "
    "Nick te acaricia el rostro y sientes su aliento caliente muy cerca de tus labios. "

# game/script.rpy:1169
translate spanish con2_458da8c9:

    # "You hear the scalpel pierce your body and at that moment the guy covers your mouth with his hand. Instead of screams, a mooing comes out of your throat. But not for long."
    "Oyes el bisturí atravesar tu cuerpo y en ese momento el chico te tapa la boca con la mano. En lugar de gritos, de tu garganta sale un mugido. Pero no por mucho tiempo."

# game/script.rpy:1173
translate spanish con2_0a2aa844:

    # "The blade runs roughly down your throat, the unbearable hot pain and the approaching death making you no longer feel that Nick has kept his promise, kissing your slit neck. "
    "La hoja recorre con brutalidad tu garganta; el insoportable dolor ardiente y la muerte que se acerca hacen que ya no sientas que Nick cumplió su promesa, besando tu cuello abierto. "

# game/script.rpy:1174
translate spanish con2_2b90befd:

    # "The guy takes your breathless body and embraces it for a while, enjoying its last warmth and streams of flowing blood. "
    "El chico toma tu cuerpo sin aliento y lo abraza un rato, disfrutando de su último calor y de los chorros de sangre que fluyen. "

# game/script.rpy:1175
translate spanish con2_ad57d0b7:

    # "Nick licks the blood that hasn't clotted yet, bites your skin, and even tears off a piece of your neck. As he does so, he gently strokes your back, as if to soothe you."
    "Nick lame la sangre que aún no se ha coagulado, te muerde la piel e incluso te arranca un trozo del cuello. Mientras lo hace, te acaricia suavemente la espalda, como para tranquilizarte."

# game/script.rpy:1177
translate spanish con2_8fd826af:

    # "After a while, Nick gently set your frozen body aside."
    "Pasado un rato, Nick apartó con delicadeza tu cuerpo helado."

# game/script.rpy:1180
translate spanish con2_808c3f4a:

    # "The guy took a cigarette out of his shorts pocket. He left bloody fingerprints on the pack and the lighter. "
    "El chico sacó un cigarrillo del bolsillo de sus pantalones cortos. Dejó huellas ensangrentadas en la cajetilla y en el encendedor. "

# game/script.rpy:1181
translate spanish con2_ada808ca:

    # "Nick took a slow drag. It was quiet outside the door. No one guessed that someone had just committed murder in the name of his sincere love. "
    "Nick dio una calada lenta. Afuera de la puerta había silencio. Nadie adivinó que alguien acababa de cometer un asesinato en nombre de su sincero amor. "

# game/script.rpy:1182
translate spanish con2_d268654f:

    # n "{cps=15}Ugh."
    n "{cps=15}Ugh."

# game/script.rpy:1183
translate spanish con2_c163e774:

    # n "{cps=15}It's getting colder in here, don't you feel it too, dear?"
    n "{cps=15}Aquí dentro se está poniendo más frío, ¿tú no lo sientes también, mi cielo?"

# game/script.rpy:1194
translate spanish con2_4f872602:

    # yn "I'm really old enough for such trinkets. I hope something interesting happens today."
    yn "Ya estoy muy grande para estas baratijas. Espero que hoy pase algo interesante. "

# game/script.rpy:1195
translate spanish con2_194a7bc6:

    # "You put the necklace back on the table, take one last look around the room and leave."
    "Dejas el collar sobre la mesa, echas un último vistazo a la habitación y sales."

# game/script.rpy:1197
translate spanish con2_1d3997ee:

    # "A cup of bitter coffee has already cooled down when you fully packed up and came to drink it. This cheap-ass coffee is really invigorating, but how disgusting it is."
    "La taza de café amargo ya se había enfriado cuando terminaste de arreglarte y fuiste a tomártela. Este café barato despierta de verdad, pero qué asco."

# game/script.rpy:1198
translate spanish con2_03547703:

    # yn "When I get a job, I'll buy myself a can of normal coffee. No, two cans. I have to spoil myself."
    yn "Cuando consiga trabajo, me compraré una lata de café normal. No, dos latas. Tengo que consentirme."

# game/script.rpy:1200
translate spanish con2_fdafc74f:

    # "The road to the university in the morning wasn't so terrible, but in the evening you had to look around. And keep a knife in your pocket. This district is really shitty."
    "El camino a la universidad por la mañana no era tan terrible, pero por la noche había que andar con cuidado. Y llevar un cuchillo en el bolsillo. Este barrio es una mierda."

# game/script.rpy:1203
translate spanish con2_ffa2dc58:

    # "And now, finally, you have come to your institute. The place where you became convinced that some people are rare scum."
    "Y ahora, por fin, llegaste a tu facultad. El lugar donde te convenciste de que algunas personas son escoria de la peor."

# game/script.rpy:1204
translate spanish con2_ca466594:

    # "Back in high school, you realized that life isn't sugar and it's not a teen show at all."
    "Ya en el instituto te diste cuenta de que la vida no es de color de rosa y de que esto no es una serie juvenil."

# game/script.rpy:1205
translate spanish con2_497671d8:

    # "That's why there's no group of cool kids or school queen surrounded by her personal maids."
    "Por eso aquí no hay un grupito de populares ni una reina de la escuela rodeada de sus doncellas personales."

# game/script.rpy:1206
translate spanish con2_27c0ab49:

    # "Everyone here is the same. Tired guys who want to get a college education. Well, it's probably not like that everywhere, you're just l u c k y."
    "Aquí todos son iguales. Gente agotada que solo quiere sacarse un título universitario. Bueno, seguramente no es así en todas partes, simplemente tienes s u e r t e."

# game/script.rpy:1207
translate spanish con2_040809c8:

    # yn "Don't start the morning so damn pessimistic!"
    yn "¡No empieces la mañana siendo tan condenadamente pesimista!"

# game/script.rpy:1208
translate spanish con2_9253ff0d:

    # "Still, some are different, though. But they really can't be envied, poor souls become punching bags from day one. "
    "Aun así, algunos son diferentes. Pero no hay por qué envidiarlos: los pobres se vuelven sacos de boxeo desde el primer día. "

# game/script.rpy:1209
translate spanish con2_30dce424:

    # "Why? Because so. Because the strong can do it to them. «Don't ask unnecessary questions and don't stand out» that's what life has taught you so far. "
    "¿Por qué? Porque sí. Porque los fuertes pueden hacérselo. «No hagas preguntas innecesarias y no destaques»: eso es lo que la vida te ha enseñado hasta ahora. "

# game/script.rpy:1211
translate spanish con2_6d4746b0:

    # yn "Huh? What happend?"
    yn "¿Eh? ¿Qué pasó?"

# game/script.rpy:1212
translate spanish con2_7f75edd2:

    # "You were trying to squeeze through the crowd. Is someone being beaten again? This is such a frequent occurrence that everyone had to forget about it and pass by, but..."
    "Intentabas abrirte paso entre la multitud. ¿Otra vez le están pegando a alguien? Es algo tan frecuente que todos tuvieron que acostumbrarse a olvidarlo y pasar de largo, pero..."

# game/script.rpy:1213
translate spanish con2_6a6c5cfe:

    # "They keep looking. Every time. You know how much the students of this university love the sight and smell of blood."
    "Siguen mirando. Siempre. Sabes cuánto les gusta a los estudiantes de esta universidad el espectáculo y el olor de la sangre."

# game/script.rpy:1215
translate spanish con2_1196e0f1:

    # "You come closer to see what is happening and swear that you have not joined this indifferent herd, no, you will definitely help. But you'll see first."
    "Te acercas para ver qué pasa y juras que no te has unido a este rebaño indiferente, no, claro que vas a ayudar. Pero primero mirarás."

# game/script.rpy:1216
translate spanish con2_15b9468f:

    # yn "Oh, I should've known. Hi, Nick."
    yn "Ah, debí imaginarlo. Hola, Nick."

# game/script.rpy:1218
translate spanish con2_8628a6bf:

    # "You didn't greet him seriously, most likely he hardly heard you at all."
    "No lo saludaste en serio; lo más probable es que apenas te haya oído."

# game/script.rpy:1219
translate spanish con2_7bc5a127:

    # "Nick is the main victim of this sinister place. His leg was broken on the first day. In the second, the contents of a trash can were poured on his head."
    "Nick es la principal víctima de este siniestro lugar. El primer día le rompieron una pierna. El segundo le vaciaron un bote de basura en la cabeza."

# game/script.rpy:1220
translate spanish con2_7ffaecda:

    # "And then you didn't remember much else. Just think of any stereotypical bullying in high school and multiply that by two. That's what this guy experienced. "
    "Y después ya no recordabas gran cosa. Piensa en cualquier acoso típico de instituto y multiplícalo por dos. Eso es lo que vivió este chico. "

# game/script.rpy:1221
translate spanish con2_52f1f3d8:

    # "Why are they bullying him? No one knows. And no one dares to try to find out. Everyone ignores and avoids him, fearing to fall under the hot hand of the main scumbags of the university."
    "¿Por qué lo acosan? Nadie lo sabe. Y nadie se atreve a intentar averiguarlo. Todos lo ignoran y lo evitan, temiendo caer bajo la mano dura de los peores canallas de la universidad."

# game/script.rpy:1222
translate spanish con2_a93e8554:

    # "And you're one of those people. Weak. Pathetic. Insignificant. But you can't even help yourself, let alone him."
    "Y eres una de esas personas. Débil. Lamentable. Insignificante. Pero ni siquiera puedes ayudarte a ti, mucho menos a él."

# game/script.rpy:1224
translate spanish con2_27ee1063_1:

    # yn "I'm sorry, little one, but I still value my life. I have three more years to study here..."
    yn "Lo siento, pequeño, pero aun así valoro mi vida. Me quedan tres años más estudiando aquí..."

# game/script.rpy:1225
translate spanish con2_80fc0724_1:

    # yn "...And I don't want to turn them into my personal hell."
    yn "...Y no quiero convertirlos en mi infierno personal."

# game/script.rpy:1226
translate spanish con2_6f6c828d_1:

    # "You felt a prick of conscience, but only for a second. After all, you'd ignored bullying this guy for years, so what now?"
    "Sentiste una punzada de remordimiento, pero solo por un segundo. Después de todo, llevabas años ignorando el acoso a este chico, ¿y ahora qué?"

# game/script.rpy:1227
translate spanish con2_0d48ebf3_1:

    # "Will you become a hero? Will you become the protector of the weak? You're not going to lie to yourself. It's stupid and pointless. "
    "¿Te convertirás en héroe? ¿En protector de los débiles? No vas a mentirte. Es estúpido y no sirve de nada. "

# game/script.rpy:1230
translate spanish con2_b19b2414:

    # "None of your friends are here today. These morons are sick, or rather drunk and hangover. "
    "Hoy no está ninguno de tus amigos. Esos imbéciles están enfermos, o más bien borrachos y con resaca. "

# game/script.rpy:1231
translate spanish con2_c19ceff1_1:

    # "You don't really like alcohol, even though your whole life is leading you down the path of alcohol or addiction."
    "No te gusta mucho el alcohol, aunque toda tu vida te conduce por el camino del alcohol o de las adicciones."

# game/script.rpy:1232
translate spanish con2_3ad6e80b_1:

    # "But by happy coincidence, you became neither."
    "Pero, por una feliz coincidencia, no te convertiste en ninguna de las dos cosas."

# game/script.rpy:1233
translate spanish con2_98cd9cbf_1:

    # "Even though everyone who's ever been to your house, the first thing they ask you is, «Are you getting high?»"
    "Aunque todo el que ha estado en tu casa, lo primero que te pregunta es «¿Te drogas?»"

# game/script.rpy:1234
translate spanish con2_e85b5256:

    # "You just smiled crookedly at that."
    "Tú solo sonreíste de medio lado."

# game/script.rpy:1236
translate spanish con2_e8da3e91:

    # "The faces of already tired and sleep-deprived students flitted around, making your head spin, and you leaned against the wall, where you watched their endlessly bleak faces from under your covered eyes."
    "Rostros de estudiantes ya cansados y faltos de sueño pasaban revoloteando, mareándote, y te apoyaste contra la pared, desde donde observabas sus caras interminablemente sombrías con los ojos medio ocultos."

# game/script.rpy:1238
translate spanish con2_3687ee35:

    # "Not that university is a place for fun, but it doesn't have to be that dreary, does it?"
    "No es que la universidad sea un lugar para divertirse, pero tampoco tiene por qué ser tan deprimente, ¿no?"

# game/script.rpy:1239
translate spanish con2_880f3c10:

    # "Truth be told, you didn't really like the company of people, but you couldn't run away from them. That's probably why you didn't have many friends, but it didn't bother you at all."
    "A decir verdad, no te gustaba mucho la compañía de la gente, pero tampoco podías huir de ella. Quizá por eso no tenías muchos amigos, pero eso no te molestaba en absoluto."

# game/script.rpy:1240
translate spanish con2_1e3f73a7:

    # "Still, you had a hard time going to university without those goofballs. Maybe you should try encouraging yourself with something sweet."
    "Aun así, te costaba ir a la universidad sin esos locos. Quizá deberías intentar animarte con algo dulce."

# game/script.rpy:1241
translate spanish con2_14aaf365:

    # "You don't consider yourself a sweet tooth, but it's better to indulge in high blood sugar than... something else."
    "No tienes especial debilidad por los dulces, pero es mejor permitirte un subidón de azúcar que... otra cosa."

# game/script.rpy:1242
translate spanish con2_d87a3e91:

    # "You really giggled idiotically to yourself about that dirty joke. It's all the influence of your stupid friends. Obviously."
    "Te reíste a solas de forma absurda por ese chiste verde. Todo es culpa de la influencia de tus estúpidos amigos. Obviamente."

# game/script.rpy:1247
translate spanish con2_b6ca3d98:

    # "You walk into the cafeteria and that's when the school bell rings. But you're not in the mood for lectures today. Even if you just sleep through them."
    "Entras en la cafetería y justo entonces suena el timbre. Pero hoy no tienes ganas de clases. Aunque solo las pases durmiendo."

# game/script.rpy:1249
translate spanish con2_36b42164:

    # "While you were looking at your feet, someone quickly approached, you didn't even have time to raise your head, as you felt a huge weight on you and heard a hideously squeaky voice that could belong to only one person."
    "Mientras mirabas tus pies, alguien se acercó rápidamente; ni siquiera tuviste tiempo de levantar la cabeza, pues sentiste un enorme peso encima y oíste una voz horriblemente chillona que solo podía ser de una persona."

# game/script.rpy:1250
translate spanish con2_0c102423:

    # "You bend under the weight of someone else's body and shout something unintelligible, but clearly not in a positive way."
    "Te doblas bajo el peso del cuerpo de otro y gritas algo ininteligible, pero claramente no en sentido positivo."

# game/script.rpy:1251
translate spanish con2_e968d4ee:

    # yn "UGH FRED!!! GET OFF ME!!!"
    yn "¡¡¡UGH FRED!!! ¡¡¡QUÍTATE DE ENCIMA!!!"

# game/script.rpy:1253
translate spanish con2_a57007e1:

    # "The guy immediately peels away from you with a nasty laugh. You can't help but admit you're glad to see him."
    "El chico se despega de ti enseguida con una risa desagradable. No puedes evitar admitir que te alegras de verlo."

# game/script.rpy:1254
translate spanish con2_65895432:

    # f "{cps=70}Heh heh heh heh heh heh heh heh heh heh!{/cps=70} Sorry!"
    f "{cps=70}Je je je je je je je je je je!{/cps=70} ¡Perdón!"

# game/script.rpy:1255
translate spanish con2_6f48e0a2:

    # yn "What are you doing here? Didn't you go down with a hangover yesterday?"
    yn "¿Qué haces aquí? ¿No estabas ayer tumbado por la resaca?"

# game/script.rpy:1256
translate spanish con2_af45128e:

    # f "WHAT?! BULLSHIT! I'm completely sober, don't you see?"
    f "¡¿QUÉ?! ¡MENTIRAS! Estoy completamente sobrio, ¿no lo ves?"

# game/script.rpy:1257
translate spanish con2_9db0f861:

    # "You looked at him like a delinquent preschooler caught in a lie."
    "Lo miraste como a un preescolar delincuente al que han pillado mintiendo."

# game/script.rpy:1258
translate spanish con2_b0ae1e74:

    # yn "Your thick glasses don't help, I can see the whites of your eyes red, you dummy. Besides, weren't you puking so hard yesterday you dropped your phone down the toilet while you were talking to me?"
    yn "Tus gafas gruesas no ayudan, veo el blanco de tus ojos rojo, tonto. Además, ¿no estabas vomitando tan fuerte ayer que se te cayó el teléfono al inodoro mientras hablabas conmigo?"

# game/script.rpy:1261
translate spanish con2_12fa2a88:

    # "Fred's face took on a blank expression. It used to scare you, but now you know he's just... that's just who he is."
    "El rostro de Fred adoptó una expresión vacía. Antes eso te asustaba, pero ahora sabes que él simplemente... es así."

# game/script.rpy:1262
translate spanish con2_704133f9:

    # "This guy is your neighbor. Sometimes it surprises you because you don't see him ninety-nine percent of the time. He usually hangs out in your friends' houses, on the street and even in junkyard. But not at home."
    "Este chico es tu vecino. A veces te sorprende porque no lo ves el noventa y nueve por ciento del tiempo. Suele andar por las casas de tus amigos, por la calle e incluso en el basurero. Pero no en casa."

# game/script.rpy:1263
translate spanish con2_410119e3:

    # "And he smells like that, too. Sometimes you wonder if he even washes. "
    "Y además huele así. A veces te preguntas si siquiera se lava. "

# game/script.rpy:1264
translate spanish con2_b1563883:

    # yn "Fred, when was the last freaking time you took a bath? "
    yn "Fred, ¿cuándo fue la última maldita vez que te bañaste? "

# game/script.rpy:1267
translate spanish con2_7fbb03d8:

    # "He didn't say anything and... He confessed?!"
    "No dijo nada y... ¡¿Confesó?!"

# game/script.rpy:1268
translate spanish con2_de8ba4b6:

    # yn "IT'S NOT A QUESTION NORMAL PEOPLE WOULD HAVE A PROBLEM WITH."
    yn "NO ES UNA PREGUNTA QUE A LA GENTE NORMAL LE CAUSARÍA PROBLEMAS."

# game/script.rpy:1269
translate spanish con2_fafbc570:

    # "You laugh softly. It was a good decision to come here. You don't feel like eating anymore, so you decide to spend your time talking to Fred."
    "Ríes suavemente. Fue buena decisión venir aquí. Ya no tienes ganas de comer, así que decides pasar el tiempo charlando con Fred."

# game/script.rpy:1270
translate spanish con2_930fe3ee:

    # yn "Shall we go for a walk in the halls? There's nothing to do anyway."
    yn "¿Damos una vuelta por los pasillos? De todos modos no hay nada que hacer."

# game/script.rpy:1273
translate spanish con2_51f36ec6:

    # f "I'm always for it! But don't you have to go to a lecture?"
    f "¡Siempre estoy a favor! Pero ¿no tienes que ir a clase?"

# game/script.rpy:1274
translate spanish con2_f9b72624:

    # "You cast a look at Fred that he understands without words. The guy smiled and you leave the cafeteria."
    "Le diriges a Fred una mirada que él entiende sin palabras. El chico sonrió y salen de la cafetería."

# game/script.rpy:1276
translate spanish con2_11cd72e0:

    # "A moment later you and Fred are already in the hallway, and oh, what a shame! You can't look at your beautiful face because some girl is walking right in front of you. Bad luck."
    "Un momento después tú y Fred ya están en el pasillo, y ¡qué lástima! No puedes contemplar tu hermoso rostro porque una chica camina justo delante de ti. Mala suerte."

# game/script.rpy:1277
translate spanish con2_1930eac4:

    # "But that doesn't stop you from enjoying a conversation with an old friend who decided to put his hand on your head. Freak. He was always so tall and always took advantage of it."
    "Pero eso no te impide disfrutar de la charla con un viejo amigo que decidió ponerte la mano en la cabeza. Bicho raro. Siempre fue tan alto y siempre se aprovechó de ello."

# game/script.rpy:1278
translate spanish con2_a73982dc:

    # "Despite his slender figure, he was really heavy."
    "A pesar de su figura esbelta, pesaba muchísimo."

# game/script.rpy:1279
translate spanish con2_65641692:

    # "You wandered the halls and talked about whatever came to mind. He always had something to talk about."
    "Vagaron por los pasillos y hablaron de lo primero que se les ocurría. Él siempre tenía algo de qué hablar."

# game/script.rpy:1280
translate spanish con2_d18e861a:

    # "You can't help but admit that you felt much better when you were around your friends."
    "No puedes evitar admitir que te sentías mucho mejor estando con tus amigos."

# game/script.rpy:1281
translate spanish con2_92f41e45:

    # "Fred went from one intonation to another, jumping from cute and glorious stories to descriptions of cases when he found all sorts of crap in a variety of conditions."
    "Fred pasaba de un tono a otro, saltando de historias tiernas y gloriosas a descripciones de casos en los que encontró todo tipo de porquerías en los más variados estados."

# game/script.rpy:1282
translate spanish con2_1138953d:

    # "You didn't like constancy, and he was the very embodiment of disorder and changeability. "
    "No te gustaba la constancia, y él era la encarnación misma del desorden y el cambio. "

# game/script.rpy:1283
translate spanish con2_d2459d0c:

    # "Sometimes you didn't really listen to what he was saying. You just liked his company."
    "A veces no escuchabas realmente lo que decía. Simplemente te gustaba su compañía."

# game/script.rpy:1284
translate spanish con2_f4d0bf8d:

    # "You're lucky to know people who are even crazier than you."
    "Tienes suerte de conocer a gente aún más loca que tú."

# game/script.rpy:1285
translate spanish con2_67aaebff:

    # yn "We haven't chatted like this in a long time. I'm glad we had this opportunity today."
    yn "Hace mucho que no charlábamos así. Me alegra que hoy tuviéramos esta oportunidad."

# game/script.rpy:1287
translate spanish con2_ca0937de:

    # f "Hahaha! You're so sensitive today, go ahead and give me a kiss on top of that, mwah mwah!"
    f "¡Jajaja! ¡Hoy estás muy sensible, anda, dame un beso encima, muac muac!"

# game/script.rpy:1288
translate spanish con2_ff6ed19a:

    # "Fred grimaced and pursed his lips. Ew."
    "Fred hizo una mueca y frunció los labios. Puaj."

# game/script.rpy:1290
translate spanish con2_6c81f746:

    # "You push him away with a laugh."
    "Lo apartas entre risas."

# game/script.rpy:1291
translate spanish con2_3b9f3fe2:

    # yn "Screw you, I'm just a good friend. Besides, I don't really want to make out with a garbage can. "
    yn "Vete al diablo, solo estoy siendo buena onda. Además, no tengo muchas ganas de besarme con un bote de basura. "

# game/script.rpy:1292
translate spanish con2_7eab67b2:

    # f "{sc}I DON'T REALLY SMELL THAT BAD!{/sc}"
    f "{sc}¡NO HUELO TAN MAL!{/sc}"

# game/script.rpy:1296
translate spanish con2_94d957b4:

    # "Evening came faster than you thought it would. Not that you were keeping track of time, but it was really fast."
    "La tarde llegó más rápido de lo que pensabas. No es que llevaras la cuenta del tiempo, pero fue realmente rápido."

# game/script.rpy:1298
translate spanish con2_239fd2d2:

    # f "Yeah, I enjoyed skipping your classes."
    f "Sí, disfruté faltando a tus clases."

# game/script.rpy:1301
translate spanish con2_e129d0f6:

    # f "We'll have to do it again!"
    f "¡Tendremos que repetirlo!"

# game/script.rpy:1302
translate spanish con2_ce43c5c2:

    # yn "Right. By the way, what are you doing here? You were expelled during your freshman year."
    yn "Claro. Por cierto, ¿qué haces aquí? Te expulsaron en primer año."

# game/script.rpy:1305
translate spanish con2_99ba4e09:

    # "Fred chuckled and the absent look on his face reappeared. No wonder."
    "Fred se rio entre dientes y la expresión ausente volvió a su rostro. No es de extrañar."

# game/script.rpy:1306
translate spanish con2_304c0f73:

    # yn "Well, forget it."
    yn "Bueno, olvídalo."

# game/script.rpy:1307
translate spanish con2_ef703d5b:

    # "You stretch and breathe in the cool evening air."
    "Te estiras y respiras el fresco aire de la tarde."

# game/script.rpy:1308
translate spanish con2_ce735207:

    # yn "{cps=50} Well, I think it's time for us to say goodbye.{w=0.2}{nw}"
    yn "{cps=50} Bueno, creo que es hora de despedirnos.{w=0.2}{nw}"

# game/script.rpy:1309
translate spanish con2_186459d7:

    # no "Oh, wait a second! Please!"
    no "¡Oh, espera un segundo! ¡Por favor!"

# game/script.rpy:1312
translate spanish con2_44aedd6b:

    # "Is that Nick?"
    "¿Es Nick?"

# game/script.rpy:1313
translate spanish con2_792ec738:

    # yn "Hi? Can we help you?"
    yn "¿Hola? ¿Podemos ayudarte?"

# game/script.rpy:1314
translate spanish con2_12174608:

    # "The guy was silent. Had he forgotten how to talk?"
    "El chico guardó silencio. ¿Habría olvidado cómo hablar?"

# game/script.rpy:1315
translate spanish con2_fd7b8ebc:

    # "Fred stared at him for a while, and then, with a smile on his face, he perked up."
    "Fred lo miró fijamente un rato y luego, con una sonrisa en el rostro, se animó."

# game/script.rpy:1318
translate spanish con2_2ffa8a9d:

    # f "Oh, Nikki! It's you! You look shabby."
    f "¡Oh, Nikki! ¡Eres tú! Te ves hecho un desastre."

# game/script.rpy:1319
translate spanish con2_f2945867:

    # "Nick didn't even look in his direction. It was strange, but you realized that apparently it was you he was approaching."
    "Nick ni siquiera miró en su dirección. Era extraño, pero comprendiste que al parecer era a ti a quien se acercaba."

# game/script.rpy:1322
translate spanish con2_2dc52025:

    # f "It's not polite to ignore people like that, you know..."
    f "No es de buena educación ignorar así a la gente, ¿sabes?..."

# game/script.rpy:1323
translate spanish con2_cea07af4:

    # "Nick was still unresponsive; he seemed to be gathering his thoughts. Poor guy."
    "Nick seguía sin responder; parecía estar ordenando sus ideas. Pobre chico."

# game/script.rpy:1324
translate spanish con2_b6c85a64:

    # "Maybe he was uncomfortable speaking in front of Fred. Although it's kind of weird, you're okay with it in general. "
    "Quizá le incomodaba hablar delante de Fred. Aunque es un poco raro, a ti en general te parece bien. "

# game/script.rpy:1325
translate spanish con2_ee26396e:

    # "The guy whispered something under his breath, you looked at Fred. There was a request in your eyes for Fred to..."
    "El chico susurró algo entre dientes, miraste a Fred. En tus ojos había una petición para que Fred..."

# game/script.rpy:1328
translate spanish con2_52f50449:

    # "You knew each other well enough to understand intentions by a glance and a slight movement of the head."
    "Se conocían lo bastante bien como para entender intenciones con una mirada y un leve movimiento de cabeza."

# game/script.rpy:1329
translate spanish con2_3d9a7628:

    # "Fred nodded and looked at his hand as if checking the time on his wristwatch."
    "Fred asintió y se miró la mano como si comprobara la hora en el reloj de pulsera."

# game/script.rpy:1330
translate spanish con2_420ce3f6:

    # f "Wow, it's so late. I have to go to Amy's party, yeah. I'll go early. Bye, [name], Nick."
    f "Vaya, qué tarde es. Tengo que ir a la fiesta de Amy, sí. Iré temprano. Chao, [name], Nick."

# game/script.rpy:1333
translate spanish con2_ff4eef31:

    # "Nick didn't even try to look in his direction, so he didn't notice the sneer. The smile on his face twitched and grew even wider."
    "Nick ni siquiera intentó mirar en su dirección, así que no notó la mueca burlona. La sonrisa de su rostro se crispó y se ensanchó aún más."

# game/script.rpy:1336
translate spanish con2_be6454cf:

    # "You nodded your thanks to Fred with a smile, the guy waved goodbye, and quickly walked away into the darkness of the courtyards."
    "Le agradeciste a Fred con un asentimiento y una sonrisa, el chico se despidió con la mano y se alejó rápidamente hacia la oscuridad de los patios."

# game/script.rpy:1338
translate spanish con2_ca818c6b:

    # yn "Hey, poor thing, how are you? Aren't you afraid to talk to me anymore? "
    yn "Oye, pobrecito, ¿cómo estás? ¿Ya no tienes miedo de hablar conmigo? "

# game/script.rpy:1341
translate spanish con2_545b222c:

    # "Nick jumped up on the spot."
    "Nick dio un respingo en el sitio."

# game/script.rpy:1342
translate spanish con2_d1c57e82:

    # yn "Don't worry, you're trembling so much, even though I'm not threatening you. "
    yn "No te preocupes, estás temblando tanto, aunque no te estoy amenazando. "

# game/script.rpy:1343
translate spanish con2_02160c6a:

    # yn "It's okay. What did you want? "
    yn "Tranquilo. ¿Qué querías? "

# game/script.rpy:1346
translate spanish con2_bf4a7e16:

    # "Nick adjusted his glasses and seemed to look away."
    "Nick se acomodó las gafas y pareció desviar la mirada."

# game/script.rpy:1347
translate spanish con2_f7fd5874:

    # n "Sorry! I get so awkward when I talk to more than one person."
    n "¡Perdón! Me pongo muy torpe cuando hablo con más de una persona."

# game/script.rpy:1348
translate spanish con2_d54f83f0:

    # yn "Yeah, I noticed that."
    yn "Sí, ya lo noté."

# game/script.rpy:1349
translate spanish con2_5115af14:

    # n "I just... really got my mind so confused as I walked over here. "
    n "Es que... se me confundió tanto la cabeza mientras caminaba hasta aquí. "

# game/script.rpy:1351
translate spanish con2_45600144:

    # n "In general... Do you mind if I walk you home?"
    n "En general... ¿Te importa si te acompaño a casa?"

# game/script.rpy:1352
translate spanish con2_6daa9041:

    # "You began to think what he wanted to achieve by this walk. Talk about something? Get to know you better?"
    "Empezaste a pensar qué quería conseguir con este paseo. ¿Hablar de algo? ¿Conocerte mejor?"

# game/script.rpy:1353
translate spanish con2_8596b524:

    # "On the whole, you didn't even mind. Nick seems nice, and you always wanted to chat with him, but not enough to make the first move. "
    "En general, ni siquiera te importaba. Nick parece agradable, y siempre habías querido charlar con él, pero no lo suficiente como para dar el primer paso. "

# game/script.rpy:1354
translate spanish con2_8ff1a62a:

    # n "Your neighborhood is not very prosperous... If something happens..."
    n "Tu barrio no es muy próspero... Si pasa algo..."

# game/script.rpy:1355
translate spanish con2_1d3ae656:

    # "You examine Nick again. It's a little hard for you to realize that this not-so-big-guy seems to want to protect you."
    "Examinas de nuevo a Nick. Te cuesta un poco asimilar que este chico no tan grande parezca querer protegerte."

# game/script.rpy:1358
translate spanish con2_2779a838:

    # n "...at least the two of us will get beaten up. "
    n "...al menos nos golpearán a los dos. "

# game/script.rpy:1359
translate spanish con2_a5d79bb6:

    # "You're sputtering with quiet laughter. It's more like the truth already. You walk here every night anyway, so... maybe it's a sensible idea to go with someone else, just to be more relaxed."
    "Resoplas con una risa queda. Eso ya se parece más a la verdad. De todos modos caminas por aquí todas las noches, así que... quizá sea una idea sensata ir con alguien más, solo para tener más tranquilidad."

# game/script.rpy:1362
translate spanish con2_9cbe30c7:

    # "Nick walked beside you, sometimes nervously touching his glasses and hair. You noticed that he was very tall, even taller than Fred, but because he was hunched over, it wasn't that noticeable. "
    "Nick caminaba a tu lado, tocándose a veces con nerviosismo las gafas y el pelo. Notaste que era muy alto, incluso más que Fred, pero como iba encorvado, no se notaba tanto. "

# game/script.rpy:1363
translate spanish con2_f5d1a344:

    # "Sometimes in the light of lanterns and in a particularly strong gust of wind you noticed the gleam of his brown eyes."
    "A veces, a la luz de los faroles y en alguna ráfaga de viento especialmente fuerte, notabas el brillo de sus ojos marrones."

# game/script.rpy:1364
translate spanish con2_e4ec4dc1:

    # "You even got the impression that there was some kind of red glow in them."
    "Incluso te dio la impresión de que había en ellos algún tipo de resplandor rojo."

# game/script.rpy:1365
translate spanish con2_a6db878b:

    # "You asked Nick all sorts of things, told him life stories, and he in turn answered quietly and smiled as he listened to you. "
    "Le preguntaste a Nick todo tipo de cosas, le contaste historias de tu vida, y él a su vez respondía en voz baja y sonreía mientras te escuchaba. "

# game/script.rpy:1366
translate spanish con2_1442b7c7:

    # yn "Hey, why do you have scars on your face?{w=0.2}{nw}"
    yn "Oye, ¿por qué tienes cicatrices en la cara?{w=0.2}{nw}"

# game/script.rpy:1368
translate spanish con2_796bb786:

    # yn "{cps=50}It's about...{cps=50} Oh, no, I'm sorry. I don't want to remind you of that."
    yn "{cps=50}Se trata de...{cps=50} Oh, no, perdón. No quiero recordártelo."

# game/script.rpy:1369
translate spanish con2_58073920:

    # n "Oh, it's okay, really. It's not something you need to worry about. Yeah, they showed up after all that abuse. But I don't really care, I have a lot of scars. "
    n "Oh, no pasa nada, de verdad. No es algo por lo que tengas que preocuparte. Sí, aparecieron después de todo ese maltrato. Pero no me importa mucho, tengo muchas cicatrices. "

# game/script.rpy:1370
translate spanish con2_fdfc7195:

    # n "The most unpleasant thing they did was almost blind me. Because of them, I have anisocoria. Now I can see with both eyes almost the same, although blurry. "
    n "Lo más desagradable que hicieron fue casi dejarme ciego. Por culpa de eso, tengo anisocoria. Ahora veo casi igual con ambos ojos, aunque borroso. "

# game/script.rpy:1371
translate spanish con2_90fb9768:

    # yn "{sc}What?!{/sc} I didn't know those bastards were capable of such a thing. Oh, my God..."
    yn "{sc}¡¿Qué?!{/sc} No sabía que esos bastardos fueran capaces de algo así. Ay, Dios mío..."

# game/script.rpy:1373
translate spanish con2_43e6b986:

    # n "Don't worry, I'll take care of it. "
    n "No te preocupes, yo me encargaré. "

# game/script.rpy:1374
translate spanish con2_07f3ec4d:

    # n "Thank you for concern."
    n "Gracias por preocuparte."

# game/script.rpy:1375
translate spanish con2_1f1bb3bb:

    # n "I really... like you a lot. "
    n "De verdad... me gustas mucho. "

# game/script.rpy:1376
translate spanish con2_c84855b9:

    # "You flinched. Oh, that was pretty... unexpected? Wierd? Is that what he wanted to tell you? Your heart raced."
    "Te sobresaltaste. Vaya, eso fue bastante... ¿inesperado? ¿Raro? ¿Era eso lo que quería decirte? Tu corazón se aceleró."

# game/script.rpy:1377
translate spanish con2_7179cf7c:

    # yn "Thanks? Oh, God. I think it's just affection... Haha! You couldn't really fall in love with me at first sight. "
    yn "¿Gracias? Ay, Dios. Creo que es solo cariño... ¡Jaja! No podrías enamorarte de mí a primera vista, en serio. "

# game/script.rpy:1378
translate spanish con2_803efb4f:

    # "Nick flushed."
    "Nick se sonrojó."

# game/script.rpy:1379
translate spanish con2_fef55af4:

    # n "I'm sorry to make you feel uncomfortable, it's just that I'm sure of it... I know for a fact that I love you. So much."
    n "Perdón por incomodarte, es que estoy seguro de ello... Sé con certeza que te amo. Muchísimo."

# game/script.rpy:1380
translate spanish con2_5a40f30b:

    # "Your breath caught. It was so childish to confess to someone you'd never spoken to. But you really found it fascinating. "
    "Se te cortó la respiración. Era muy infantil confesarse a alguien con quien nunca habías hablado. Pero de verdad te resultó fascinante. "

# game/script.rpy:1381
translate spanish con2_00c2aa23:

    # yn "I'm really flattered... But I can't answer you in the same way, I'm not sure I can so quickly. "
    yn "Me halaga mucho... Pero no puedo responderte de la misma manera, no sé si podré hacerlo tan rápido. "

# game/script.rpy:1382
translate spanish con2_24c67459:

    # n "Don't worry, I don't expect reciprocal feelings from you, I just feel so much better when I tell you about it. "
    n "No te preocupes, no espero que correspondas, solo me siento mucho mejor cuando te lo digo. "

# game/script.rpy:1383
translate spanish con2_33c8c04d:

    # "That was sweet. Nick wasn't repulsive and even despite his unexpected confession you really didn't feel awkward."
    "Fue dulce. Nick no resultaba repulsivo y, a pesar de su inesperada confesión, de verdad no sentiste incomodidad."

# game/script.rpy:1384
translate spanish con2_51e16adf:

    # "Sure you felt weird, but it was an unusually warm feeling."
    "Claro que te sentiste raro, pero era una sensación inusualmente cálida."

# game/script.rpy:1387
translate spanish con2_e639253a:

    # "While you were talking, you didn't notice how you got to your house. You didn't really want to stop chatting with Nick, because you two obviously hit it off. And you were very happy about that. "
    "Mientras hablaban, no notaste cómo llegaron a tu casa. No querías dejar de charlar con Nick, porque era evidente que habían conectado. Y eso te alegraba mucho. "

# game/script.rpy:1388
translate spanish con2_b4614460:

    # n "Thanks for the conversation and the walk. I look forward to meeting you tomorrow! If you don't mind. "
    n "Gracias por la charla y el paseo. ¡Espero verte mañana! Si no te importa. "

# game/script.rpy:1389
translate spanish con2_a51b5560:

    # yn "I don't mind at all, thank you for seeing me off! Oh, and I thought you were studying in a different building."
    yn "¡No me importa en absoluto, gracias por acompañarme! Ah, y yo pensaba que estudiabas en otro edificio."

# game/script.rpy:1392
translate spanish con2_e003bee1:

    # n "Oh, I just recently transferred! Today was the first day I attended the lectures here. As you can see... these guys get me everywhere. "
    n "¡Ah, me transferí hace poco! Hoy fue el primer día que asistí a las clases aquí. Como ves... estos tipos me persiguen a todas partes. "

# game/script.rpy:1395
translate spanish con2_be0d0ca4:

    # "Nick yanked on the collar of his bloody shirt and grinned. That's optimism and a thirst for knowledge. "
    "Nick se tiró del cuello de su camisa ensangrentada y sonrió de oreja a oreja. Eso es optimismo y sed de conocimiento. "

# game/script.rpy:1396
translate spanish con2_f8dc3c12:

    # n "Oh, I could tell a few more stories, but it's cold outside. So... I'm going to go home. No one's waiting for me there, so don't worry about the late hour."
    n "Ah, podría contarte alguna historia más, pero afuera hace frío. Así que... me voy a casa. No me espera nadie allí, así que no te preocupes por la hora tardía."

# game/script.rpy:1397
translate spanish con2_417bab9e:

    # "Nick rubbed his neck and smiled. He looks so innocent, it's even startling. "
    "Nick se frotó el cuello y sonrió. Parece tan inocente que hasta sorprende. "

# game/script.rpy:1398
translate spanish con2_f74ae762:

    # yn "Hey, if you don't have to go anywhere, you can come over to my place. I'm not expecting anyone to visit and I have no business. Fred's room is empty, and I don't think he'd mind if you slept over. "
    yn "Oye, si no tienes que ir a ningún lado, puedes venir a mi casa. No espero ninguna visita y no tengo nada que hacer. El cuarto de Fred está vacío, y no creo que le moleste que te quedes a dormir. "

# game/script.rpy:1401
translate spanish con2_710ef42d:

    # n "Ah, I think you're going to be embarrassed! I'll stay with you for a while, and then I'll call a cab and go home so you can sleep in peace. "
    n "¡Ah, creo que te dará vergüenza! Me quedaré un rato contigo, y luego pediré un taxi y me iré a casa para que duermas en paz. "

# game/script.rpy:1402
translate spanish con2_f57750ed:

    # "Is that... wings growing behind his back? Oh, God... "
    "¿Eso son... alas creciéndole en la espalda? Oh, Dios... "

# game/script.rpy:1403
translate spanish con2_2998f41b:

    # yn "After a bunch of sleepovers with total strangers I'm really used to it, but thank you very much. You're very caring, really... I'm even embarrassed, we're quite different. "
    yn "Después de un montón de pijamadas con completos desconocidos, ya no me extraña nada, pero muchas gracias. Eres muy atento, de verdad... Hasta me da vergüenza, somos bastante diferentes. "

# game/script.rpy:1404
translate spanish con2_4eafb771:

    # yn "Shoot, I'm sorry! Let's go inside already. "
    yn "¡Rayos, perdón! Entremos ya. "

# game/script.rpy:1409
translate spanish con2_52424e75:

    # "You and Nick went home. The guy looked around carefully and closed the door behind him. "
    "Tú y Nick fueron a tu casa. El chico miró alrededor con cuidado y cerró la puerta tras de sí. "

# game/script.rpy:1411
translate spanish con2_1bb6b796:

    # yn "I'm sorry, I don't think I can get you anything. I don't have much food at home. "
    yn "Lo siento, creo que no puedo ofrecerte nada. No tengo mucha comida en casa. "

# game/script.rpy:1412
translate spanish con2_1e4e7f58:

    # n "It's okay! I have a special diet anyway. "
    n "¡No pasa nada! De todos modos sigo una dieta especial. "

# game/script.rpy:1413
translate spanish con2_8ec5d74f:

    # yn "Do you also have stomach problems? Or are you just keeping yourself in shape?"
    yn "¿Tú también tienes problemas de estómago? ¿O solo te mantienes en forma?"

# game/script.rpy:1414
translate spanish con2_814a0473:

    # n "Hahaha! Neither. I guess it could be described as..."
    n "¡Jajaja! Ninguna de las dos. Supongo que podría describirse como..."

# game/script.rpy:1415
translate spanish con2_8a574110:

    # n "Specific preferences."
    n "Preferencias específicas."

# game/script.rpy:1416
translate spanish con2_d0d63361:

    # n "I'll be sure to tell you about it and let you taste it! "
    n "¡Seguro que te lo cuento y te dejo probarlo! "

# game/script.rpy:1417
translate spanish con2_ab43b5c4:

    # yn "That would be great! Do you drink coffee? I'd make you a cup."
    yn "¡Eso sería genial! ¿Tomas café? Te prepararía una taza."

# game/script.rpy:1418
translate spanish con2_ff8abd9d:

    # n "I wouldn't mind. I'm going to wash my hands, okay?"
    n "No me vendría mal. Voy a lavarme las manos, ¿vale?"

# game/script.rpy:1420
translate spanish con2_f53ad2a9:

    # yn "Yes, of course, the bathroom is... "
    yn "Sí, claro, el baño está... "

# game/script.rpy:1421
translate spanish con2_cabf8900:

    # "Before you could finish talking, Nick was gone. You shrugged your shoulders. It's not hard to guess where the bathroom is in this little house."
    "Antes de que pudieras terminar de hablar, Nick ya no estaba. Te encoges de hombros. No es difícil adivinar dónde está el baño en esta casita."

# game/script.rpy:1425
translate spanish con2_10ddc8fe:

    # "The coffee was already ready and even cold. Did he drown in the toilet? Oh... "
    "El café ya estaba listo e incluso frío. ¿Se habrá ahogado en el inodoro? Oh... "

# game/script.rpy:1426
translate spanish con2_f1609151:

    # "You put your hands on the table, and then you lie down on them and close eyes. "
    "Pones las manos sobre la mesa, luego te recuestas sobre ellas y cierras los ojos. "

# game/script.rpy:1428
translate spanish con2_fbad712e:

    # "It's not very polite to leave a someone like that, but maybe he's trying to wash his shirt now? It's covered in blood, after all. Or he's treating wounds. "
    "No es muy educado dejar así a alguien, pero quizá ahora esté tratando de lavar su camisa. Está cubierta de sangre, después de todo. O se está curando las heridas. "

# game/script.rpy:1429
translate spanish con2_dd99600d:

    # "You have nowhere to go in a hurry, and you can just warm up the coffee. It's fine."
    "No tienes adónde ir con prisa, y puedes simplemente recalentar el café. Está bien."

# game/script.rpy:1431
translate spanish con2_56cd531a_1:

    # "{cps=3}. . ."
    "{cps=3}. . ."

# game/script.rpy:1433
translate spanish con2_a5ce9701:

    # yn "Really? As soon as I lay down someone came? "
    yn "¿En serio? Justo cuando me acosté, ¿viene alguien? "

# game/script.rpy:1434
translate spanish con2_6773457d:

    # yn "Okay, fine."
    yn "Bueno, vale."

# game/script.rpy:1436
translate spanish con2_11f83565:

    # "You opened your eyes and already stood up to approach and open to the uninvited guest, but... "
    "Abriste los ojos y ya te levantabas para acercarte y abrirle al invitado inesperado, pero... "

# game/script.rpy:1439
translate spanish con2_5297fdf6:

    # "Something stopped you."
    "Algo te detuvo."

# game/script.rpy:1441
translate spanish con2_0c796073:

    # "A man on the other side of the door would not let up and kept pounding with their hands."
    "Un hombre al otro lado de la puerta no cedía y seguía golpeando con las manos."

# game/script.rpy:1443
translate spanish con2_087ee790:

    # "But your whole body is stiff. You couldn't even breathe. "
    "Pero todo tu cuerpo está rígido. Ni siquiera podías respirar. "

# game/script.rpy:1446
translate spanish con2_ab903286:

    # "You tried to turn around, but to no avail. Your heart was pounding at an insane rate."
    "Intentaste darte la vuelta, pero fue en vano. Tu corazón latía a un ritmo demencial."

# game/script.rpy:1448
translate spanish con2_8e42b06d:

    # "{cps=10}{sc}You understood what that feeling was.{/sc}"
    "{cps=10}{sc}Entendiste qué era esa sensación.{/sc}"

# game/script.rpy:1450
translate spanish con2_9a914dfe:

    # "{cps=10}{sc}It was a moment before death.{/sc}"
    "{cps=10}{sc}Era el instante previo a la muerte.{/sc}"

# game/script.rpy:1482
translate spanish shit_efb0d37c:

    # yn "{cps=12}{sc}No... No... No...{/sc}"
    yn "{cps=12}{sc}No... No... No...{/sc}"

# game/script.rpy:1484
translate spanish shit_dcb11f64:

    # "{cps=20}There was nausea coming up to your throat. The fear didn't recede, it only ate you up more. "
    "{cps=20}Las náuseas te subían a la garganta. El miedo no retrocedía, solo te devoraba más. "

# game/script.rpy:1486
translate spanish shit_1ce39ea5:

    # "{cps=20}The fucking knocking on the door didn't stop. You felt as if that was the sound that would be the cause of your death."
    "{cps=20}Los malditos golpes en la puerta no cesaban. Sentías que ese era el sonido que causaría tu muerte."

# game/script.rpy:1488
translate spanish shit_b3b22cd4:

    # no "{cps=10}{sc}Don't open the door.{/sc}"
    no "{cps=10}{sc}No abras la puerta.{/sc}"

# game/script.rpy:1491
translate spanish shit_5de9a1aa:

    # yn "{sc}FUCK!{/sc}"
    yn "{sc}¡MIERDA!{/sc}"

# game/script.rpy:1492
translate spanish shit_849356ad:

    # "Nick looked at you dumbfounded. You were finally able to move."
    "Nick te miró atónito. Por fin pudiste moverte."

# game/script.rpy:1493
translate spanish shit_87cb9402:

    # n "Oh? Is someone here? "
    n "¿Oh? ¿Hay alguien? "

# game/script.rpy:1495
translate spanish shit_09a04a52:

    # "You flinched when you heard another knock on the door. "
    "Te sobresaltaste al oír otro golpe en la puerta. "

# game/script.rpy:1496
translate spanish shit_88575d90:

    # f "Hey! Let me go home, [name], please! I lost my keys again... "
    f "¡Eh! ¡Déjame entrar a casa, [name], por favor! Perdí las llaves otra vez... "

# game/script.rpy:1497
translate spanish shit_4e881151:

    # "Was it Fred? You didn't hear him call you before that... What just happened anyway? "
    "¿Era Fred? No lo habías oído llamarte antes... ¿Qué acababa de pasar? "

# game/script.rpy:1498
translate spanish shit_f8caa730:

    # "You looked at Nick again. He wasn't smiling anymore, to be honest, he looked so... upset?"
    "Volviste a mirar a Nick. Ya no sonreía; a decir verdad, parecía tan... ¿disgustado?"

# game/script.rpy:1499
translate spanish shit_5378887d:

    # n "What a shame... So we'll have to take our relationship to the next level sooner than I thought. "
    n "Qué lástima... Así que tendremos que llevar nuestra relación al siguiente nivel antes de lo que pensaba. "

# game/script.rpy:1500
translate spanish shit_ab485d01:

    # n "Too bad. I wanted to be with you... like this for as long as possible."
    n "Qué pena. Quería estar contigo... así durante el mayor tiempo posible."

# game/script.rpy:1501
translate spanish shit_0cb5d9ef:

    # yn "What do you mean?"
    yn "¿A qué te refieres?"

# game/script.rpy:1504
translate spanish shit_4c4128ff:

    # "Nick took a couple of steps closer to you and you felt a sharp pain. Your head felt like it was splitting apart. "
    "Nick dio un par de pasos hacia ti y sentiste un dolor agudo. Tenías la sensación de que la cabeza se te partía en dos. "

# game/script.rpy:1505
translate spanish shit_05a27176:

    # yn "{sc}Oh, shit...{/sc}"
    yn "{sc}Oh, mierda...{/sc}"

# game/script.rpy:1506
translate spanish shit_9b7148da:

    # "Before you fainted, you heard someone's high-pitched scream. "
    "Antes de desmayarte, oíste el grito agudo de alguien. "

# game/script.rpy:1510
translate spanish shit_8534ca42:

    # ". . ."
    ". . ."

# game/script.rpy:1511
translate spanish shit_93544f8e:

    # "You started to come around a little bit. You felt a terrible aching pain in the back of your head. "
    "Empezaste a volver en ti poco a poco. Sentías un terrible dolor punzante en la nuca. "

# game/script.rpy:1512
translate spanish shit_b7c43d40:

    # yn "I'm thirsty... What happened? Ugh... "
    yn "Tengo sed... ¿Qué pasó? Ugh... "

# game/script.rpy:1513
translate spanish shit_8ff6ef33:

    # n "Oh, you're awake?"
    n "¿Oh, ya despertaste?"

# game/script.rpy:1516
translate spanish shit_c2f78a50:

    # "The voice echoed in your mind. You lifted your head and, through the red haze in front of your eyes, you could see a figure in front of you. "
    "La voz resonó en tu mente. Levantaste la cabeza y, a través de la bruma roja ante tus ojos, viste una figura frente a ti. "

# game/script.rpy:1517
translate spanish shit_f9993907:

    # yn "Nick? Is that you? What happened?"
    yn "¿Nick? ¿Eres tú? ¿Qué pasó?"

# game/script.rpy:1518
translate spanish shit_0e01187c:

    # "You whispered all those words slowly, barely moving your tongue. "
    "Susurraste todas esas palabras despacio, apenas moviendo la lengua. "

# game/script.rpy:1519
translate spanish shit_bd14ec32:

    # n "Yes, it's me. It's just... a bad set of circumstances. But it's okay. "
    n "Sí, soy yo. Es solo que... fue un conjunto de circunstancias desafortunadas. Pero está bien. "

# game/script.rpy:1520
translate spanish shit_6b4d70d4:

    # n "Open your eyes, I did something for you! "
    n "¡Abre los ojos, hice algo para ti! "

# game/script.rpy:1523
translate spanish shit_f8d835dd:

    # "It really is Nick. You felt a little better, but your body was still heavy and your head was aching. "
    "De verdad era Nick. Te sentiste un poco mejor, pero tu cuerpo seguía pesado y la cabeza te dolía. "

# game/script.rpy:1524
translate spanish shit_f1112fdd:

    # n "How are you? Does it hurt a lot? "
    n "¿Cómo estás? ¿Te duele mucho? "

# game/script.rpy:1525
translate spanish shit_330ca019:

    # yn "Everything seems to be fine. What happened? I can't remember anything. Just those freaking knocks on the door. "
    yn "Parece que todo está bien. ¿Qué pasó? No recuerdo nada. Solo esos malditos golpes en la puerta. "

# game/script.rpy:1526
translate spanish shit_d94a920d:

    # yn "And that scream... Hey, didn't Fred come home?"
    yn "Y ese grito... Oye, ¿no llegó Fred a casa?"

# game/script.rpy:1528
translate spanish shit_d1d2e55b:

    # n "That's right, he came in, I opened the door for him because you fainted. But let's not talk about it, it's all because you're not eating well! "
    n "Así es, entró, le abrí la puerta porque te desmayaste. Pero no hablemos de eso, ¡todo es porque no comes bien! "

# game/script.rpy:1529
translate spanish shit_2d2ff242:

    # n "I prepared something. Wait, let me tidy up a bit. "
    n "Preparé algo. Espera, déjame arreglarme un poco. "

# game/script.rpy:1533
translate spanish shit_aef3aea1:

    # n "That's better. I feel insignificant with these glasses and my hair in a ponytail. "
    n "Así está mejor. Me siento insignificante con estas gafas y el pelo recogido en una coleta. "

# game/script.rpy:1534
translate spanish shit_6d72c5c1:

    # n "But you can't cook when your hair is loose. You don't want to get a mess of hair instead of a nice dinner, do you? "
    n "Pero no se puede cocinar con el pelo suelto. No querrás encontrar una maraña de pelos en vez de una buena cena, ¿verdad? "

# game/script.rpy:1535
translate spanish shit_ee55f24d:

    # "You blinked to realize what had just happened. "
    "Parpadeaste para asimilar lo que acababa de pasar. "

# game/script.rpy:1536
translate spanish shit_e591fee8:

    # yn "What? What are you talking about? Where's Fred? Why didn't you call an ambulance if I fainted?! "
    yn "¿Qué? ¿De qué hablas? ¿Dónde está Fred? ¡¿Por qué no llamaste a una ambulancia si me desmayé?! "

# game/script.rpy:1538
translate spanish shit_67822591:

    # n "What a lot of questions... "
    n "Cuántas preguntas... "

# game/script.rpy:1540
translate spanish shit_011fa7a3:

    # n "Let's eat first. I made such a wonderful steak! I'm an excellent cook, taste it! "
    n "Primero comamos. ¡Hice un filete maravilloso! Soy un excelente cocinero, ¡pruébalo! "

# game/script.rpy:1541
translate spanish shit_e22b8f76:

    # "You snorted rudely and tried to get out of your chair. "
    "Resoplaste con rudeza e intentaste levantarte de la silla. "

# game/script.rpy:1542
translate spanish shit_a1ea77b5:

    # "But at the same moment you realized what the heaviness in the body was. "
    "Pero en ese mismo instante comprendiste a qué se debía la pesadez del cuerpo. "

# game/script.rpy:1545
translate spanish shit_ee72ad66:

    # yn "{sc}What the... WHY AM I TIED UP?!{/sc}"
    yn "{sc}Qué... ¡¿POR QUÉ ME HAN ATADO?!{/sc}"

# game/script.rpy:1546
translate spanish shit_b07b0633:

    # "You tried to see a hint in Nick's face that he was just making a bad joke, but all you could see was irritation. "
    "Intentaste ver en el rostro de Nick algún indicio de que solo hacía una mala broma, pero todo lo que veías era irritación. "

# game/script.rpy:1547
translate spanish shit_53c3a152:

    # n "Please... be quiet. Okay? "
    n "Por favor... cállate. ¿Vale? "

# game/script.rpy:1548
translate spanish shit_1bcbc5f9:

    # n "I don't feel well because of the noise. "
    n "No me siento bien por el ruido. "

# game/script.rpy:1550
translate spanish shit_d1934152:

    # yn "{sc}AND YOU THINK I'M FEELING GOOD?!{/sc}"
    yn "{sc}¡¿Y TÚ CREES QUE YO ME SIENTO BIEN?!{/sc}"

# game/script.rpy:1551
translate spanish shit_3b42b09a:

    # "Nick covered his eyes and took a deep breath, as if trying not to snap. "
    "Nick se cubrió los ojos y respiró hondo, como intentando no estallar. "

# game/script.rpy:1552
translate spanish shit_2837a371:

    # n "Please. Be. Quiet. And eat with me. Okay? After that, I'll be sure to explain everything to you. "
    n "Por favor. Guarda. Silencio. Y come conmigo. ¿Vale? Después te lo explicaré todo sin falta. "

# game/script.rpy:1553
translate spanish shit_505df93f:

    # "You exhaled nervously, but said nothing back."
    "Exhalaste con nerviosismo, pero no respondiste nada."

# game/script.rpy:1555
translate spanish shit_090c8685:

    # n "That's good. Thank you, sunshine. "
    n "Eso es. Gracias, solecito. "

# game/script.rpy:1557
translate spanish shit_1878d17a:

    # n "Now say aaah."
    n "Ahora di aaah."

# game/script.rpy:1558
translate spanish shit_889836da:

    # "You could smell the pleasant smell coming from what Nick was holding out to you and even obediently opened your mouth to eat it, but... "
    "Percibías el agradable olor de lo que Nick te ofrecía e incluso abriste obedientemente la boca para comerlo, pero... "

# game/script.rpy:1560
translate spanish shit_44110ad4:

    # yn "...whose meat is it? "
    yn "...¿de quién es esta carne? "

# game/script.rpy:1562
translate spanish shit_cec0bec9:

    # "Nick froze, but didn't take his fork away from your face. He obviously wasn't going to answer that question. "
    "Nick se quedó helado, pero no apartó el tenedor de tu cara. Era evidente que no pensaba responder esa pregunta. "

# game/script.rpy:1564
translate spanish shit_b542361f:

    # n "You're not allergic to it, don't worry. It's delicious, really! Come on... just eat it? Can I say we're on a date? "
    n "No es nada que te cause alergia, no te preocupes. ¡Está deliciosa, de verdad! Vamos... ¿simplemente cómela? ¿Puedo decir que estamos en una cita? "

# game/script.rpy:1565
translate spanish shit_b726f25b:

    # n "You look so beautiful, but your face is a little pale. You need to eat. "
    n "Eres una belleza, pero tienes la cara algo pálida. Necesitas comer. "

# game/script.rpy:1568
translate spanish shit_faaed4e8:

    # yn "WHOSE FUCKING MEAT IS THIS?!"
    yn "¡¿DE QUIÉN CARAJO ES ESTA CARNE?!"

# game/script.rpy:1569
translate spanish shit_8971dc5b:

    # "You started twitching, trying to get out of the ropes, but they were tied awfully tight. "
    "Empezaste a sacudirte, intentando soltarte de las cuerdas, pero estaban atadas terriblemente fuerte. "

# game/script.rpy:1570
translate spanish shit_349fdc4e:

    # n "Don't you understand me? Or are you just mocking me? "
    n "¿No me entiendes? ¿O solo te burlas de mí? "

# game/script.rpy:1571
translate spanish shit_803a62c4:

    # n "Well, let me ask YOU then."
    n "Bueno, entonces déjame preguntarte a TI."

# game/script.rpy:1575
translate spanish shit_d60acf2a:

    # n "Oh, you're such a sweetheart."
    n "Oh, eres un amor."

# game/script.rpy:1580
translate spanish shit_1c9d878b:

    # yn "{sc}I'M NOT EATING THAT CRAP!{/sc}"
    yn "{sc}¡NO VOY A COMER ESA PORQUERÍA!{/sc}"

# game/script.rpy:1581
translate spanish shit_9d70c730:

    # n "You scum... "
    n "Escoria... "

# game/script.rpy:1582
translate spanish shit_75c46be4:

    # n "I just wanted to please you with great food, I wanted to be a GOOD guy, but no... "
    n "Solo quería complacerte con una buena comida, quería ser una persona BUENA, pero no... "

# game/script.rpy:1583
translate spanish shit_85a33bf4:

    # n "Was it that hard for you to eat a bite? You couldn't even do it after the way you treated me this morning? Yes, I'm saying this to YOU. "
    n "¿Tan difícil era comerte un bocado? ¿Ni siquiera después de cómo me trataste esta mañana? Sí, te lo digo a TI. "

# game/script.rpy:1585
translate spanish shit_f8506fc8:

    # n "But I'm not offended. Because I love you. "
    n "Pero no estoy ofendido. Porque te amo. "

# game/script.rpy:1586
translate spanish shit_2fbb69d6:

    # n "Don't test my patience. I want to be loving in your sense of it. I want to take care of you, to feed you. Isn't that romantic? "
    n "No pongas a prueba mi paciencia. Quiero ser cariñoso a tu manera. Quiero cuidarte, darte de comer. ¿No es romántico? "

# game/script.rpy:1587
translate spanish shit_3341da28:

    # n "Forget about our disagreements?"
    n "¿Olvidamos nuestras desavenencias?"

# game/script.rpy:1595
translate spanish qu_0451a4b1:

    # n "Okay. I'll just wait for you to get tired. "
    n "Vale. Esperaré a que te canses. "

# game/script.rpy:1599
translate spanish good_5f172032:

    # n "I hope you'll enjoy it! "
    n "¡Espero que lo disfrutes! "

# game/script.rpy:1600
translate spanish good_2e885e45:

    # "You opened your mouth and obediently ate a piece of meat of unknown origin, after which Nick immediately poked a new one."
    "Abriste la boca y te comiste obedientemente un trozo de carne de origen desconocido, tras lo cual Nick enseguida pinchó otro."

# game/script.rpy:1601
translate spanish good_18e628a5:

    # n "You're so cute when you listen to me. "
    n "Qué ternura das cuando me obedeces. "

# game/script.rpy:1602
translate spanish good_a43d9bb1:

    # n "It's times like this that I feel like we're getting closer! "
    n "¡En momentos así siento que nos estamos acercando! "

# game/script.rpy:1603
translate spanish good_a19e179d:

    # n "{sc}You have no idea how close we are going to be soon.{/sc} "
    n "{sc}No tienes idea de lo cerca que vamos a estar pronto.{/sc} "

# game/script.rpy:1604
translate spanish good_4e75a742:

    # "You felt tears coming to your eyes."
    "Sentiste que las lágrimas te asomaban a los ojos."

# game/script.rpy:1605
translate spanish good_705e28c9:

    # n "Is it good, love?"
    n "¿Está rico, amor?"

# game/script.rpy:1606
translate spanish good_e77af1c8:

    # yn "{cps=12}{sc}...It's delicious.{/sc}"
    yn "{cps=12}{sc}...Está delicioso.{/sc}"

# game/script.rpy:1617
translate spanish good_52f50449:

    # "You knew each other well enough to understand intentions by a glance and a slight movement of the head."
    "Se conocían lo bastante bien como para entender intenciones con una mirada y un leve movimiento de cabeza."

# game/script.rpy:1620
translate spanish good_96a40027:

    # f "Hey, [name], we have to hurry. Otherwise, we won't make it in time for Chloe's arrival. "
    f "Oye, [name], hay que darse prisa. Si no, no llegaremos a tiempo para la llegada de Chloe. "

# game/script.rpy:1621
translate spanish good_b4276bf7:

    # yn "Oh, yes. I'm sorry, but we're in a big hurry to get home. Can we talk tomorrow?"
    yn "Ah, sí. Lo siento, pero tenemos mucha prisa por llegar a casa. ¿Podemos hablar mañana?"

# game/script.rpy:1624
translate spanish good_6fb8e7c5:

    # "Nick turned even more pale. He seemed to say something quietly, maybe something like, «Yes, of course...» but you decided not to ask. "
    "Nick palideció aún más. Pareció decir algo en voz baja, quizá algo como «Sí, claro...», pero decidiste no preguntar. "

# game/script.rpy:1625
translate spanish good_cac41315:

    # yn "If it's something important, I'll listen to you!"
    yn "¡Si es algo importante, te escucho!"

# game/script.rpy:1626
translate spanish good_63af143a:

    # n "{cps=13}...No, it's not."
    n "{cps=13}...No, no lo es."

# game/script.rpy:1629
translate spanish good_4e74a306:

    # "Nick turned around and quickly left in an unknown direction. You thought the poor guy was going to cry."
    "Nick se dio la vuelta y se marchó rápidamente en una dirección desconocida. Pensaste que el pobre chico se iba a poner a llorar."

# game/script.rpy:1631
translate spanish good_175a2d87:

    # f "God, he was so fucking upset. "
    f "Dios, estaba hecho polvo, joder. "

# game/script.rpy:1635
translate spanish good_26301078:

    # f "You're such an asshole."
    f "Eres de lo peor."

# game/script.rpy:1636
translate spanish good_d78255ca:

    # yn "WHAT? AM I THE ASSHOLE? You played me without a second thought! "
    yn "¡¿QUÉ?! ¡¿YO SOY LO PEOR?! ¡Me engañaste sin pensártelo dos veces! "

# game/script.rpy:1637
translate spanish good_3f1c0315:

    # yn "And right now my conscience is killing me. I will apologize to him tomorrow. Let's go home. "
    yn "Y ahora me remuerde la conciencia. Mañana me disculparé con él. Vámonos a casa. "

# game/script.rpy:1639
translate spanish good_e274df11:

    # "You and Fred walked slowly toward home, teasing each other along the way and talking about things as if you hadn't spoken all day. "
    "Tú y Fred caminaron despacio hacia casa, picándose el uno al otro por el camino y hablando de cosas como si no hubieran hablado en todo el día. "

# game/script.rpy:1643
translate spanish good_1bbc4cca:

    # f "Phew, I'm tired. Nothing to eat again? "
    f "Uf, estoy cansado. ¿Otra vez no hay nada para comer? "

# game/script.rpy:1644
translate spanish good_b4a5e518:

    # yn "Coffee. And yogurt. "
    yn "Café. Y yogur. "

# game/script.rpy:1645
translate spanish good_198bab2a:

    # f "As always. I forgot about that! I'll get us something to eat. "
    f "Como siempre. ¡Se me había olvidado! Yo pediré algo de comer. "

# game/script.rpy:1646
translate spanish good_6c6019fc:

    # yn "I'm still looking for a part-time job, I don't have much money to pay for food delivery... "
    yn "Todavía busco un trabajo de medio tiempo, no tengo mucho dinero para pagar comida a domicilio... "

# game/script.rpy:1649
translate spanish good_9566a2b2:

    # f "Lord, I'll pay for you. Do you really think I'll eat while you drool and sip coffee? "
    f "Dios, yo te invito. ¿De verdad crees que voy a comer mientras tú babeas y sorbes café? "

# game/script.rpy:1651
translate spanish good_d8943f3c:

    # f "I'm a good friend!"
    f "¡Soy un buen amigo!"

# game/script.rpy:1652
translate spanish good_a3e47427:

    # yn "Thank you very much, I'll give you the money later. For the first time in a month I'm going to eat normally! "
    yn "Muchas gracias, te daré el dinero después. ¡Por primera vez en un mes voy a comer normal! "

# game/script.rpy:1653
translate spanish good_541a391b:

    # "Fred rolled his eyes, but he knew he couldn't change your mind and make you not pay him back. "
    "Fred puso los ojos en blanco, pero sabía que no podía hacerte cambiar de idea ni evitar que le pagaras. "

# game/script.rpy:1655
translate spanish good_b9f43014:

    # f "U-u-ugh, excuse me for using profanity and not speaking French in your high society. "
    f "U-u-ugh, perdón por decir palabrotas y no hablar francés en tu alta sociedad. "

# game/script.rpy:1656
translate spanish good_169a4c11:

    # "You tapped Fred on the shoulder with a laugh."
    "Le diste a Fred una palmada en el hombro entre risas."

# game/script.rpy:1657
translate spanish good_3145f910:

    # f "{sc}UGH! PLEASE DON'T KILL ME!{/sc} I'll remember something in French!!! "
    f "{sc}¡UGH! ¡POR FAVOR, NO ME MATES!{/sc} ¡Recordaré algo en francés!!! "

# game/script.rpy:1660
translate spanish good_d361155e:

    # f "Chasse à la chouette! Parlez-vous français?!"
    f "Chasse à la chouette! Parlez-vous français?!"

# game/script.rpy:1661
translate spanish good_8dabc063:

    # "His voice, when he portrayed something, made you cry with laughter. "
    "Su voz, cuando imitaba algo, te hacía llorar de risa. "

# game/script.rpy:1662
translate spanish good_660fcaf8:

    # "You turned away and ran to the bathroom so you wouldn't have to hear his shouting in broken French anymore. "
    "Te diste la vuelta y corriste al baño para no tener que oír más sus gritos en un francés chapurreado. "

# game/script.rpy:1665
translate spanish good_de5e658f:

    # "You shut the door behind you and began to undress to take a bath. "
    "Cerraste la puerta tras de ti y empezaste a desvestirte para bañarte. "

# game/script.rpy:1666
translate spanish good_c182df77:

    # "The hot water was always cozy, almost like a bed, but... Wet."
    "El agua caliente siempre era acogedora, casi como una cama, pero... mojada."

# game/script.rpy:1669
translate spanish good_eeefd1ac:

    # "You turned on the faucet and, with your knees to your chest, leaned against the wall of the tub. "
    "Abriste el grifo y, con las rodillas contra el pecho, te apoyaste en la pared de la bañera. "

# game/script.rpy:1670
translate spanish good_a4f0c950:

    # "It's cold. And the water hasn't warmed up yet. It's awful... "
    "Hace frío. Y el agua todavía no se ha calentado. Es horrible... "

# game/script.rpy:1671
translate spanish good_f1c49f41:

    # "Thoughts of today filled your head and you remembered Nick. Poor thing. "
    "Los pensamientos del día te llenaron la cabeza y recordaste a Nick. Pobrecito. "

# game/script.rpy:1672
translate spanish good_6083e4d2:

    # yn "I hope he's not offended by me. Why didn't I listen to him at all? Ugh... We'll talk tomorrow for sure. "
    yn "Espero que no esté ofendido conmigo. ¿Por qué no lo escuché en absoluto? Ugh... Mañana hablaremos seguro. "

# game/script.rpy:1674
translate spanish good_5bbbe82e:

    # "A shadow appeared behind the bathroom curtain. You chuckled. Fred was either trying to scare you or fooling around again. "
    "Apareció una sombra detrás de la cortina del baño. Te reíste. Fred intentaba asustarte o volvía a hacer el tonto. "

# game/script.rpy:1675
translate spanish good_0d58a475:

    # "You weren't embarrassed by his presence, he was like a little brother to you, so you weren't afraid to be alone with him."
    "Su presencia no te avergonzaba, era como un hermano pequeño para ti, así que no te daba miedo estar a solas con él."

# game/script.rpy:1676
translate spanish good_ff9aff2d:

    # "Even naked. In the bathtub. "
    "Incluso sin ropa. En la bañera. "

# game/script.rpy:1677
translate spanish good_22d8212d:

    # yn "Fred, if you open that curtain, I'll kick you out of the house. "
    yn "Fred, si abres esa cortina, te echo de casa a patadas. "

# game/script.rpy:1680
translate spanish good_9e899eb6:

    # "{cps=20}But for some reason he didn't move. "
    "{cps=20}Pero por alguna razón no se movió. "

# game/script.rpy:1681
translate spanish good_04048055:

    # "You felt uncomfortable and pressed your knees harder. "
    "Sentiste incomodidad y apretaste más las rodillas. "

# game/script.rpy:1682
translate spanish good_0ae65630:

    # yn "Fred? Please say something... "
    yn "Fred? Por favor, di algo... "

# game/script.rpy:1683
translate spanish good_248d4ec5:

    # yn "You know I'm easily frightened. Don't be a bastard. We've talked about this so many times. "
    yn "Sabes que me asusto con facilidad. No seas cabrón. Ya hemos hablado de esto muchas veces. "

# game/script.rpy:1684
translate spanish good_ec6a4780:

    # "{cps=12}But he just stood still."
    "{cps=12}Pero él se quedó inmóvil."

# game/script.rpy:1685
translate spanish good_e78bac23:

    # "You were about to open the curtain and look behind it, but... "
    "Ibas a abrir la cortina y mirar detrás, pero... "

# game/script.rpy:1686
translate spanish good_9b33c007:

    # "{cps=15}Your hands were shaking. The thought that it wasn't Fred standing there made you shiver. You'd better not see who's standing there... "
    "{cps=15}Te temblaban las manos. La idea de que no fuera Fred quien estaba allí te hizo estremecer. Mejor no ver quién está ahí... "

# game/script.rpy:1687
translate spanish good_d8f43a2c:

    # "{cps=15}Your breath is out of breath. You were so fucking scared. "
    "{cps=15}Se te cortaba la respiración. Tenías muchísimo miedo, joder. "

# game/script.rpy:1688
translate spanish good_844fbc0d:

    # "{cps=15}There was nothing at hand that could be your weapon. And you just hoped that this shadow would disappear. "
    "{cps=15}No había nada a mano que pudiera servir de arma. Y solo esperabas que esa sombra desapareciera. "

# game/script.rpy:1691
translate spanish good_5b255806:

    # "You heard a quiet hum that made you flinch. "
    "Oíste un zumbido tenue que te hizo sobresaltar. "

# game/script.rpy:1693
translate spanish good_0f755382:

    # "You opened your eyes with horror and... no one else was on the other side of that damn curtain. "
    "Abriste los ojos con horror y... ya no había nadie al otro lado de esa maldita cortina. "

# game/script.rpy:1694
translate spanish good_8852fbbc:

    # "Tears came out of your eyes. You felt so miserable. "
    "Te brotaron las lágrimas. Sentiste una desdicha enorme. "

# game/script.rpy:1695
translate spanish good_507a5bb7:

    # yn "{sc}What the hell was that...{/sc} I'm going to hit him, I'm going to seriously smash his freaking' face in. "
    yn "{sc}¿Qué demonios fue eso...{/sc} Voy a pegarle, le voy a romper la maldita cara. "

# game/script.rpy:1697
translate spanish good_062fd5be:

    # "Fear was replaced by anger and you pulled the curtain open with force. "
    "El miedo dio paso a la ira y abriste la cortina de un tirón. "

# game/script.rpy:1699
translate spanish good_57c72150:

    # "No one was there."
    "No había nadie."

# game/script.rpy:1700
translate spanish good_8c58aaed:

    # "You exhaled in relief and began to dress quickly. "
    "Exhalaste con alivio y empezaste a vestirte rápido. "

# game/script.rpy:1702
translate spanish good_49ccc4d0:

    # yn "{cps=40}{sc}FRED! FUCK! I'LL KILL YOU, COME HERE, YOU AS-{/sc}{w=0.2}{nw}"
    yn "{cps=40}{sc}¡FRED! ¡MIERDA! ¡TE VOY A MATAR, VEN AQUÍ, MALDI-{/sc}{w=0.2}{nw}"

# game/script.rpy:1704
translate spanish good_4997a655:

    # "{cps=12}You froze and stared in horror at what you saw in front of you. "
    "{cps=12}Se te heló la sangre y miraste con horror lo que tenías delante. "

# game/script.rpy:1707
translate spanish good_d8a8afa2:

    # n "{cps=15}You're finally here. "
    n "{cps=15}Por fin has llegado. "

# game/script.rpy:1708
translate spanish good_350fc385:

    # n "{cps=15}I already wanted to bring him to you."
    n "{cps=15}Ya quería traértelo."

# game/script.rpy:1709
translate spanish good_927675d1:

    # n "{cps=15}And he's heavy, you know. But for your sake I don't mind. "
    n "{cps=15}Y pesa, ¿sabes? Pero por ti no me importa. "

# game/script.rpy:1710
translate spanish good_82561c4b:

    # "You couldn't realize what was going on. It seemed as if this guy's voice was coming from somewhere far away. It was... Fred? In his hands... "
    "No podías comprender qué estaba pasando. Parecía que la voz de ese chico venía de muy lejos. Era... ¿Fred? En sus manos... "

# game/script.rpy:1711
translate spanish good_9a5ee71f:

    # "The room reeked of blood. "
    "La habitación apestaba a sangre. "

# game/script.rpy:1712
translate spanish good_5c7e95e8:

    # n "{cps=15}Hey, Fred. "
    n "{cps=15}Eh, Fred. "

# game/script.rpy:1713
translate spanish good_482ef54a:

    # n "{cps=15}{sc}Where's your head at?{/sc} "
    n "{cps=15}{sc}¿Dónde tienes la cabeza?{/sc} "

# game/script.rpy:1716
translate spanish good_5223df4b:

    # "You threw up. It was impossible.{sc} No. No. No...{/sc} "
    "Vomitaste. Era imposible.{sc} No. No. No...{/sc} "

# game/script.rpy:1719
translate spanish good_c25ae468:

    # "You clutched your hands to your head and huddled open your mouth to scream."
    "Te agarraste la cabeza con las manos y te encogiste, abriendo la boca para gritar."

# game/script.rpy:1722
translate spanish good_da3b980d:

    # "But in the same second, in one long jump, Nick was beside you and grabbed you by the throat, roughly pressed against the wall. "
    "Pero en ese mismo segundo, de un largo salto, Nick estaba a tu lado y te agarró por la garganta, apretándote con brusquedad contra la pared. "

# game/script.rpy:1723
translate spanish good_0de3ea37:

    # n "{cps=15}Don't even think about it. "
    n "{cps=15}Ni lo pienses. "

# game/script.rpy:1724
translate spanish good_9ee970da:

    # n "{sc}I HATE{/sc} loud noises. "
    n "{sc}ODIO{/sc} los ruidos fuertes. "

# game/script.rpy:1725
translate spanish good_295ac87c:

    # n "So be nice and keep quiet. Okay? "
    n "Así que pórtate bien y guarda silencio. ¿Vale? "

# game/script.rpy:1727
translate spanish good_b62b4cda:

    # n "I assure you, pretty soon you won't have to hold back your scream anymore. "
    n "Te aseguro que muy pronto ya no tendrás que contener el grito. "

# game/script.rpy:1728
translate spanish good_93e5ef52:

    # "You felt the lack of oxygen. Nick licked the knife, and it seems like his blood from the cut tongue mingled with Fred's. "
    "Sentías la falta de oxígeno. Nick lamió el cuchillo, y parece que la sangre de su lengua cortada se mezcló con la de Fred. "

# game/script.rpy:1729
translate spanish good_269206c5:

    # "When you remembered Fred's corpse, you involuntarily felt a mad rush of fear that coursed through your entire body. "
    "Al recordar el cadáver de Fred, sentiste involuntariamente una oleada enloquecedora de miedo que te recorrió todo el cuerpo. "

# game/script.rpy:1730
translate spanish good_78085812:

    # "Nick's grip got a little weaker, so you started screaming and calling for help again."
    "El agarre de Nick se aflojó un poco, así que volviste a gritar y a pedir ayuda."

# game/script.rpy:1732
translate spanish good_a76f5ca9:

    # n "{cps=15}{sc}Shut. Your. Fucking. Mouth. Dear.{/sc}"
    n "{cps=15}{sc}Cierra. Tu. Maldita. Boca. Cariño.{/sc}"

# game/script.rpy:1733
translate spanish good_dde0d772:

    # n "Is that too much to ask? Don't I deserve to enjoy my last seconds with you? Maybe after you fucked me up {sc}I WON'T EVEN KILL YOU!{/sc}"
    n "¿Es mucho pedir? ¿No merezco disfrutar de mis últimos segundos contigo? Quizá, después de lo que me hiciste, {sc}¡NI SIQUIERA TE MATARÉ!{/sc}"

# game/script.rpy:1734
translate spanish good_0be38a5a:

    # n "But no! You WILL get on my nerves, you will {sc}scream!{/sc}"
    n "¡Pero no! ¡Vas a ponerme de los nervios, vas a {sc}gritar!{/sc}"

# game/script.rpy:1736
translate spanish good_2001ef19:

    # n "Do you want it to hurt? Do you want to play with me? "
    n "¿Quieres que duela? ¿Quieres jugar conmigo? "

# game/script.rpy:1737
translate spanish good_93d733ee:

    # n "Let's play, sweetie. You'll be in so much pain that you'll start begging me to {cps=3}die!{/cps=3} "
    n "Juguemos, cielo. ¡Tendrás tanto dolor que empezarás a rogarme que te deje {cps=3}morir!{/cps=3} "

# game/script.rpy:1738
translate spanish good_1de92667:

    # n "{cps=15}Tomorrow I'll be eating the toughest steak I've ever had. "
    n "{cps=15}Mañana me comeré el filete más duro que he probado en mi vida. "

# game/script.rpy:1750
translate spanish good_0fcca4f1:

    # "You clutched your hands to your head and huddled open your mouth to scream. But you couldn't make a single sound."
    "Te agarraste la cabeza con las manos y te encogiste, abriendo la boca para gritar. Pero no pudiste emitir ni un solo sonido."

# game/script.rpy:1753
translate spanish good_da3b980d_1:

    # "But in the same second, in one long jump, Nick was beside you and grabbed you by the throat, roughly pressed against the wall. "
    "Pero en ese mismo segundo, de un largo salto, Nick estaba a tu lado y te agarró por la garganta, apretándote con brusquedad contra la pared. "

# game/script.rpy:1754
translate spanish good_0de3ea37_1:

    # n "{cps=15}Don't even think about it. "
    n "{cps=15}Ni lo pienses. "

# game/script.rpy:1755
translate spanish good_9ee970da_1:

    # n "{sc}I HATE{/sc} loud noises. "
    n "{sc}ODIO{/sc} los ruidos fuertes. "

# game/script.rpy:1756
translate spanish good_295ac87c_1:

    # n "So be nice and keep quiet. Okay? "
    n "Así que pórtate bien y guarda silencio. ¿Vale? "

# game/script.rpy:1758
translate spanish good_b62b4cda_1:

    # n "I assure you, pretty soon you won't have to hold back your scream anymore. "
    n "Te aseguro que muy pronto ya no tendrás que contener el grito. "

# game/script.rpy:1759
translate spanish good_2295a4a7:

    # "You shook your whole body even more. You were scared of death after all, but you were even more scared because of that knife in front of your face. "
    "Todo tu cuerpo tembló aún más. Le tenías miedo a la muerte, pero te asustaba aún más ese cuchillo frente a tu cara. "

# game/script.rpy:1760
translate spanish good_62beef5b:

    # "You nodded, and the tears came out of your eyes with renewed vigor. Maybe he wouldn't kill you if you were more obedient. "
    "Asentiste, y las lágrimas te brotaron con renovado vigor. Quizá no te mataría si eras más obediente. "

# game/script.rpy:1761
translate spanish good_96d51007:

    # n "We seem to have found common ground. That's great. So we'll say goodbye on a touching note. With a good impression of each other! "
    n "Parece que hemos encontrado un punto en común. Eso es genial. ¡Así que nos despediremos en una nota conmovedora. Con una buena impresión mutua! "

# game/script.rpy:1762
translate spanish good_2d89533a:

    # n "Oh, more precisely... I'm already impressed with you! No, no! I'm already in love with you!"
    n "Oh, más exactamente... ¡Ya me has impresionado! ¡No, no! ¡Ya estoy enamorado de ti!"

# game/script.rpy:1763
translate spanish good_34818a13:

    # n "{cps=20}Crazy... madly in love. "
    n "{cps=20}Locamente... perdidamente enamorado. "

# game/script.rpy:1764
translate spanish good_682682f3:

    # n "Isn't that what they call an addiction? I think it is! You know, when you can't live without something. Just as you can't live without air... "
    n "¿No es eso lo que llaman adicción? ¡Creo que sí! Ya sabes, cuando no puedes vivir sin algo. Igual que no puedes vivir sin aire... "

# game/script.rpy:1765
translate spanish good_50041180:

    # "Nick squeezed his hand harder around your neck. "
    "Nick apretó más la mano alrededor de tu cuello. "

# game/script.rpy:1767
translate spanish good_3381ac85:

    # n "...So I can't live without you."
    n "...Así que no puedo vivir sin ti."

# game/script.rpy:1768
translate spanish good_fff9f288:

    # n "Oh! I'm so embarrassed. Say this to you, looking into the eye... Too intimate."
    n "¡Oh! Qué vergüenza. Decirte esto, mirándote a los ojos... Demasiado íntimo."

# game/script.rpy:1769
translate spanish good_13dcc088:

    # "Nick bit his lip. He really did seem to find his words romantic. "
    "Nick se mordió el labio. De verdad parecía encontrar románticas sus palabras. "

# game/script.rpy:1770
translate spanish good_e215cfbe:

    # n "Oh, my gosh, I want to taste you so bad. "
    n "¡Oh, cielos, tengo tantas ganas de probarte! "

# game/script.rpy:1771
translate spanish good_19be5515:

    # "For a second when you heard those words, you started to believe that he was about to let you go, but..."
    "Por un segundo, al oír esas palabras, empezaste a creer que iba a soltarte, pero..."

# game/script.rpy:1772
translate spanish good_015207e5:

    # "{cps=12}Nick didn't unclench his hand. "
    "{cps=12}Nick no aflojó la mano. "

# game/script.rpy:1774
translate spanish good_2b1d7086:

    # "He started deliberately blocking your air, you felt an unbearable pain. "
    "Empezó a cortarte el aire deliberadamente, sentiste un dolor insoportable. "

# game/script.rpy:1775
translate spanish good_da2831a1:

    # n "Have you really thought about sex? After everything? God, sweetheart..."
    n "¿De verdad pensaste en sexo? ¿Después de todo? Dios, cielo..."

# game/script.rpy:1776
translate spanish good_4adcac22:

    # n "I was being literal."
    n "Lo decía en sentido literal."

# game/script.rpy:1777
translate spanish good_7f4b600c:

    # "{cps=15}Your lungs felt as if they were on fire."
    "{cps=15}Sentías los pulmones como si ardieran."

# game/script.rpy:1778
translate spanish good_fb8bad18:

    # "{cps=15}You struggled to scratch and tear at Nick's hand, but there was absolutely no strength left in your body."
    "{cps=15}Luchaste por arañar y arrancar la mano de Nick, pero no quedaba absolutamente ninguna fuerza en tu cuerpo."

# game/script.rpy:1779
translate spanish good_7cc34dcb:

    # n "{cps=20}{sc}The main course is right in front of me.{/sc} "
    n "{cps=20}{sc}El plato principal está justo frente a mí.{/sc} "

# game/script.rpy:1791
translate spanish good_11c0d9c2:

    # "Or maybe... forget everything? "
    "¿O quizá... olvidarlo todo? "

# game/script.rpy:1792
translate spanish good_9d76e9ff:

    # "I feel like I'm stuck in one place. It's like there's no way out and no new ending. "
    "Siento que no salgo del mismo sitio. Es como si no hubiera salida ni un nuevo final. "

# game/script.rpy:1793
translate spanish good_cee66beb:

    # "As if I would get nothing at the end of this journey, nothing but pain, fear and tears."
    "Como si al final de este viaje no fuera a obtener nada, nada más que dolor, miedo y lágrimas."

# game/script.rpy:1794
translate spanish good_26a0366f:

    # "I don't want that. I want a new path, a different future. "
    "No quiero eso. Quiero un nuevo camino, un futuro distinto. "

# game/script.rpy:1795
translate spanish good_bd880893:

    # "I'll just... I'll just start over. "
    "Simplemente... simplemente empezaré de nuevo. "

# game/script.rpy:1801
translate spanish end8_2b5bd529:

    # u "MMmhhh..."
    u "MMmhhh..."

# game/script.rpy:1803
translate spanish end8_2b6dbdc1:

    # u "Good morning! I feel like there should be good weather outside the window."
    u "¡Buenos días! Me parece que afuera de la ventana debe de hacer buen tiempo."

# game/script.rpy:1806
translate spanish end8_f9a046c4:

    # u "I can smell that my wonderful breakfast is ready!"
    u "¡Huelo que mi maravilloso desayuno está listo!"

# game/script.rpy:1812
translate spanish end8_2eaca2a5:

    # yn "Hi, [name], I love you so much! "
    yn "¡Hola, [name], te quiero muchísimo! "

# game/script.rpy:1813
translate spanish end8_9498ee08:

    # yn "You need to tell yourself that every morning, then you'll be in a good mood. "
    yn "Tienes que decírtelo cada mañana, así tendrás buen humor. "

# game/script.rpy:1814
translate spanish end8_b67432ba:

    # "You quickly got dressed and gathered all the necessary textbooks and notebooks. The sun's rays neatly illuminated your face through the slightly open curtains. "
    "Te vestiste rápido y reuniste todos los libros de texto y cuadernos necesarios. Los rayos del sol iluminaban pulcramente tu rostro a través de las cortinas entreabiertas. "

# game/script.rpy:1816
translate spanish end8_aa01a1fe:

    # "There was no one downstairs anymore, just the still warm breakfast your parents had left for you. "
    "Ya no había nadie abajo, solo el desayuno aún caliente que tus padres te habían dejado. "

# game/script.rpy:1817
translate spanish end8_c851241a:

    # "You happily ate everything quickly and mentally thanked your parents for the food. "
    "Te comiste todo rápidamente y con alegría, y agradeciste mentalmente a tus padres por la comida. "

# game/script.rpy:1819
translate spanish end8_76cb1294:

    # "It was warm outside, a light spring breeze blew over you, and you breathed a full chest of fresh air. "
    "Afuera hacía calor, soplaba una ligera brisa primaveral y respiraste a pleno pulmón el aire fresco. "

# game/script.rpy:1820
translate spanish end8_c11b114a:

    # yn "I love walking around the city, too bad it's not that far to the university. I'll have to go for a walk after school with my friends. "
    yn "Me encanta pasear por la ciudad, qué pena que la universidad no quede tan lejos. Tendré que dar una vuelta después de clase con mis amigos. "

# game/script.rpy:1821
translate spanish end8_94c01478:

    # yn "Maybe we should go to a cafe. Or a restaurant! I've wanted to go to a new place for a long time. "
    yn "Quizá deberíamos ir a una cafetería. ¡O a un restaurante! Hace tiempo que quiero ir a un sitio nuevo. "

# game/script.rpy:1824
translate spanish end8_9b567a48:

    # "You came to the institution quickly, though you tried to slow down."
    "Llegaste rápido a la universidad, aunque intentaste ir más despacio."

# game/script.rpy:1825
translate spanish end8_c7078b0a:

    # "Already at the entrance several of your fellows waved hello to you. "
    "Ya en la entrada, varios de tus compañeros te saludaron con la mano. "

# game/script.rpy:1826
translate spanish end8_68c1dbb9:

    # "You liked this place. Such a large number of potential acquaintances turned your head. You liked talking to new people, making friends."
    "Te gustaba este lugar. Tal cantidad de posibles conocidos te daba vueltas la cabeza. Te gustaba hablar con gente nueva, hacer amigos."

# game/script.rpy:1827
translate spanish end8_f67d513d:

    # "Every day you started with a good mood and a desire to finally go back to uni, talk to your buddies and learn something new."
    "Cada día empezabas con buen humor y con ganas de volver por fin a la uni, charlar con tus colegas y aprender algo nuevo."

# game/script.rpy:1828
translate spanish end8_efd3f465:

    # "It was wonderful. Your whole life was going great and you were grateful for it."
    "Era maravilloso. Toda tu vida iba de maravilla y lo agradecías."

# game/script.rpy:1830
translate spanish end8_ae122db4:

    # "You went away from the noisy students to a place where there was no one else."
    "Te alejaste de los estudiantes ruidosos hacia un lugar donde no había nadie más."

# game/script.rpy:1831
translate spanish end8_71f32b87:

    # "Except for one person."
    "Salvo una persona."

# game/script.rpy:1832
translate spanish end8_136df770:

    # "You looked around for him."
    "Lo buscaste con la mirada."

# game/script.rpy:1834
translate spanish end8_a493bb93:

    # u "Guess who!"
    u "¡Adivina quién!"

# game/script.rpy:1835
translate spanish end8_828306bb:

    # "You smiled shyly and touched the cold fingers that covered your eyes."
    "Sonreíste con timidez y tocaste los dedos fríos que te cubrían los ojos."

# game/script.rpy:1837
translate spanish end8_74be2c7c:

    # "At the same moment, this someone removed his hands and jumped back with a squeak."
    "En ese mismo momento, esa persona retiró las manos y retrocedió de un salto con un chillido."

# game/script.rpy:1838
translate spanish end8_d370ff16:

    # yn "Nick! Did I guess right?"
    yn "¡Nick! ¿Acerté?"

# game/script.rpy:1840
translate spanish end8_e2330817:

    # n "As always!"
    n "¡Como siempre!"

# game/script.rpy:1841
translate spanish end8_23ce391d:

    # "The guy covered mouth with his hand and giggled. Oh... He's so charming."
    "El chico se tapó la boca con la mano y soltó una risita. Oh... Qué encantador es."

# game/script.rpy:1842
translate spanish end8_db256b82:

    # n "You're finally here! I'm so glad to see you. "
    n "¡Por fin llegaste! Me alegra tanto verte. "

# game/script.rpy:1843
translate spanish end8_a5a59914:

    # yn "Come on, you're talking like we haven't seen each other in years, haha! "
    yn "Venga ya, hablas como si no nos hubiéramos visto en años, ¡jaja! "

# game/script.rpy:1844
translate spanish end8_c1342d40:

    # "Nick rubbed the back of his head shyly. How much more obvious could he be about his feelings for you?"
    "Nick se frotó la nuca con timidez. ¿Cuánto más evidentes podían ser sus sentimientos por ti?"

# game/script.rpy:1847
translate spanish end8_4fa8a23a:

    # n "You know how much I love you. It won't be enough for me even to be near you every second. "
    n "Sabes cuánto te quiero. Ni siquiera me bastaría con estar a tu lado cada segundo. "

# game/script.rpy:1848
translate spanish end8_0bdf2e0d:

    # "You gigled and got goose bumps. You know very well that Nick loves you, but you're not dating. Why not? You don't know the answer to that question yourself."
    "Soltaste una risita y se te puso la piel de gallina. Sabes muy bien que Nick te quiere, pero no son pareja. ¿Por qué no? Ni tú sabes la respuesta a esa pregunta."

# game/script.rpy:1849
translate spanish end8_ab6a8763:

    # "In fact, a few times you even made a move toward this relationship, but Nick immediately cut everything off and distanced himself. "
    "De hecho, un par de veces incluso diste un paso hacia esta relación, pero Nick enseguida lo cortó todo y se distanció. "

# game/script.rpy:1850
translate spanish end8_3ae485bb:

    # "It was really frustrating at first, but after a few conversations and a few years you get used to it. Although it really was hard to stay away from him and not do what all couples do. "
    "Al principio fue muy frustrante, pero tras unas cuantas conversaciones y unos cuantos años te acostumbras. Aunque de verdad era difícil mantener la distancia con él y no hacer lo que hacen todas las parejas. "

# game/script.rpy:1851
translate spanish end8_6133ec9b:

    # "You just had to remember to keep your distance and that nothing would go beyond compliments, declarations of love, and shy touches. "
    "Solo tenías que recordar mantener la distancia y que nada pasaría de los halagos, las declaraciones de amor y los toques tímidos. "

# game/script.rpy:1852
translate spanish end8_ada9033a:

    # "And yet you bit your lip with resentment."
    "Y aun así te mordiste el labio con resentimiento."

# game/script.rpy:1853
translate spanish end8_948aceb0:

    # "You couldn't live without him, but it seemed impossible to live with him in such a relationship. And every day you felt it more clearly."
    "No podías vivir sin él, pero parecía imposible vivir con él en una relación así. Y cada día lo sentías con más claridad."

# game/script.rpy:1854
translate spanish end8_b7b11b70:

    # "Today turned out to be a little different, something seemed to have changed forever, getting into your life, taking control of you."
    "Hoy resultó un poco distinto, algo parecía haber cambiado para siempre, metiéndose en tu vida, tomando el control de ti."

# game/script.rpy:1855
translate spanish end8_ea017738:

    # yn "«It feels like if I don't try now, I'll never be able to do it again!»"
    yn "«Siento que si no lo intento ahora, ¡nunca podré volver a hacerlo!»"

# game/script.rpy:1858
translate spanish end8_f028d8ed:

    # yn "Maybe we would have spent more time together if you had started dating me after all."
    yn "Quizá habríamos pasado más tiempo juntos si hubieras empezado a salir conmigo después de todo."

# game/script.rpy:1861
translate spanish end8_18195b81:

    # "Nick went pale. He obviously couldn't answer that."
    "Nick palideció. Era evidente que no podía responder a eso."

# game/script.rpy:1862
translate spanish end8_d77da2d4:

    # n "Let's not talk about it anymore... I really love you, I want to touch you, I want to be near you, I want to make you happier..."
    n "No hablemos más de eso... De verdad te quiero, quiero tocarte, quiero estar a tu lado, quiero hacerte más feliz..."

# game/script.rpy:1863
translate spanish end8_00a95c42:

    # n "{cps=250}{sc}I want to tear you to fucking pieces and hurt you so badly that you'll beg me to die- OH FUCK AGAIN! SORRY! SORRY!{/sc} {w=0.2}{nw}"
    n "{cps=250}{sc}Quiero destrozarte en pedazos y hacerte tanto daño que me supliques que te deje morir... ¡OH, MIERDA, OTRA VEZ! ¡PERDÓN! ¡PERDÓN!{/sc} {w=0.2}{nw}"

# game/script.rpy:1866
translate spanish end8_24796dbe:

    # n ". . ."
    n ". . ."

# game/script.rpy:1867
translate spanish end8_1c16d068:

    # "You felt the expression on his face as if it physically hurt you. He looked so devastated... "
    "Sentiste su expresión como si te doliera físicamente. Se veía tan destrozado... "

# game/script.rpy:1868
translate spanish end8_d4056ca3:

    # yn "I'm sorry, I just wanted to... Yeah, let's forget about this conversation. "
    yn "Perdón, solo quería... Sí, olvidemos esta conversación. "

# game/script.rpy:1871
translate spanish end8_617926a8:

    # "Nick smiled and gently took your hand. You felt how cold his fingers were and how much they shook. "
    "Nick sonrió y te tomó suavemente de la mano. Sentiste lo frías que estaban sus manos y cuánto temblaban. "

# game/script.rpy:1876
translate spanish end8_719915af:

    # "You sighed and decided not to think about it anymore. What stupidity! Of course you can discuss this later. "
    "Suspiraste y decidiste no pensar más en ello. ¡Qué tontería! Claro que puedes hablarlo más tarde. "

# game/script.rpy:1883
translate spanish nx_6656240b:

    # yn "You're pretty early today, usually I'm waiting for you, not the other way around. "
    yn "Hoy has llegado bastante temprano, normalmente soy yo quien te espera, no al revés. "

# game/script.rpy:1886
translate spanish nx_601ad81b:

    # n "Haha! I think I won this little race today. "
    n "¡Jaja! Creo que hoy gané esta pequeña carrera. "

# game/script.rpy:1887
translate spanish nx_9a5ae44a:

    # "Nick smiled softly and stroked your head, as if to soothe you. He loves to win."
    "Nick sonrió con suavidad y te acarició la cabeza, como para tranquilizarte. Le encanta ganar."

# game/script.rpy:1890
translate spanish nx_5b192f62:

    # n "Ah, you always give me warmth. I love touching you so much."
    n "Ah, siempre me das calidez. Me encanta tanto tocarte."

# game/script.rpy:1891
translate spanish nx_ba6c07cd:

    # "You touched your hot cheeks and tried to hide the shyness. But it was too obvious."
    "Te tocaste las mejillas ardientes e intentaste ocultar la timidez. Pero era demasiado evidente."

# game/script.rpy:1892
translate spanish nx_869341b3:

    # yn "No wonder! Warm blood flows in me, I'm alive after all, you're wa- Oh, right. "
    yn "¡No me extraña! Por mis venas corre sangre caliente, al fin y al cabo sigo con vida, tú eres cál... Ah, cierto. "

# game/script.rpy:1893
translate spanish nx_2f52fba0:

    # "You remembered that Nick's body is cool, like he's a snake. It was a little weird, but he was always sickly and examined in the hospital, so it wasn't a threat to his health."
    "Recordaste que el cuerpo de Nick es fresco, como si fuera una serpiente. Era un poco raro, pero siempre estuvo enfermizo y lo examinaban en el hospital, así que no suponía una amenaza para su salud."

# game/script.rpy:1894
translate spanish nx_d46474ae:

    # "Otherwise, doctors would have cured it long ago. "
    "De lo contrario, los médicos lo habrían curado hace mucho. "

# game/script.rpy:1897
translate spanish nx_cee5fb9f:

    # "Nick grinned for some reason. "
    "Nick sonrió con picardía por alguna razón. "

# game/script.rpy:1900
translate spanish nx_b05d564a:

    # n "I hope you continue to keep me warm, I really do. You're the only one I let touch me... "
    n "Espero que sigas manteniéndome caliente, de verdad. Eres la única persona a la que dejo tocarme... "

# game/script.rpy:1901
translate spanish nx_8e2d3727:

    # "Again. You can never get used to how cute he gets around you. It breaks your heart. "
    "Otra vez. Nunca podrás acostumbrarte a lo tierno que se pone a tu lado. Te rompe el corazón. "

# game/script.rpy:1904
translate spanish nx_c747a117:

    # n "Hey, I think today is too nice day to go to lectures, don't you think? Why don't we talk instead of studying? "
    n "Oye, creo que hoy es un día demasiado bonito para ir a clase, ¿no crees? ¿Por qué no hablamos en lugar de estudiar? "

# game/script.rpy:1905
translate spanish nx_f7530a72:

    # n "I'll take you to the movie tonight, if you want. "
    n "Si quieres, te llevo al cine esta noche. "

# game/script.rpy:1912
translate spanish nx_683951aa:

    # "You notice how Nick flinched. "
    "Notas cómo Nick se sobresalta. "

# game/script.rpy:1913
translate spanish nx_ac665545:

    # n "You should think about it some more... I'm not asking you to do something impossible, am I? "
    n "Deberías pensarlo un poco más... No te pido nada imposible, ¿verdad? "

# game/script.rpy:1916
translate spanish nx_c5c5053f:

    # n "Please... If you agree, I will make you so happy... "
    n "Por favor... Si aceptas, te haré tan feliz... "

# game/script.rpy:1917
translate spanish nx_7b333d5a:

    # "Nick's voice seemed to tremble."
    "La voz de Nick parecía temblar."

# game/script.rpy:1924
translate spanish nx_858b92e8:

    # n "Oh, I'm sorry, I didn't hear you. You said we were going out now, right? "
    n "Ay, perdón, no te oí. Dijiste que salíamos ahora, ¿verdad? "

# game/script.rpy:1931
translate spanish date_b972380e:

    # n "I'm so excited!"
    n "¡Estoy tan emocionado!"

# game/script.rpy:1932
translate spanish date_fbf5b7b0:

    # n "Maybe I'll even give you a... kiss. But that's all I can take! "
    n "Quizá incluso te dé un... beso. ¡Pero es todo lo que puedo soportar! "

# game/script.rpy:1933
translate spanish date_594fe74e:

    # "You blushed thickly. A kiss?! He barely held your hand for more than five seconds without starting to smile broadly, almost madly, and blush."
    "Te sonrojaste muchísimo. ¡¿Un beso?! Apenas te sostenía la mano más de cinco segundos sin empezar a sonreír ampliamente, casi con locura, y a sonrojarse."

# game/script.rpy:1936
translate spanish date_35f9dbf6:

    # "Now you've already started to look away and rubbing your hair. "
    "Ahora ya empezabas a desviar la mirada y a frotarte el pelo. "

# game/script.rpy:1937
translate spanish date_7528ded5:

    # yn "And why such an incredible gift? I thought you didn't want to get that close to me... Did something happen? "
    yn "¿Y por qué un regalo tan increíble? Pensaba que no querías acercarte tanto a mí... ¿Pasó algo? "

# game/script.rpy:1938
translate spanish date_cad1fcdd:

    # "Nick bit his lip and chuckled."
    "Nick se mordió el labio y rio por lo bajo."

# game/script.rpy:1941
translate spanish date_17eac4bf:

    # n "Aren't you happy about it?"
    n "¿No te hace feliz?"

# game/script.rpy:1942
translate spanish date_9801eb34:

    # yn "Of course I'm, silly! It's just that it still hurts me... you know that. "
    yn "¡Claro que sí, tonto! Es solo que todavía me duele... ya lo sabes. "

# game/script.rpy:1943
translate spanish date_952c6321:

    # n "{cps=250}{sc}I assure you, if we get close, you'll know what real pain is. {/sc} {w=0.2}{nw}"
    n "{cps=250}{sc}Te aseguro que, si nos acercamos, sabrás lo que es el dolor de verdad. {/sc} {w=0.2}{nw}"

# game/script.rpy:1944
translate spanish date_f186ca0e:

    # yn "What? "
    yn "¿Qué? "

# game/script.rpy:1947
translate spanish date_e201b593:

    # n "N-nothing... I mumble under my breath again. It's a really special day today, you can feel it too, right? "
    n "N-nada... Otra vez murmuré entre dientes. Hoy es un día muy especial, tú también lo sientes, ¿verdad? "

# game/script.rpy:1948
translate spanish date_1f77bfa6:

    # yn "Haha, yeah, truth be told I noticed that. This morning seemed unusual to me. Kind of... like it didn't belong to me. "
    yn "Jaja, sí, la verdad es que lo noté. Esta mañana me pareció inusual. Como si... no me perteneciera. "

# game/script.rpy:1949
translate spanish date_efba4723:

    # "Nick stroked your cheek and immediately pulled away, biting his lip. "
    "Nick te acarició la mejilla y enseguida se apartó, mordiéndose el labio. "

# game/script.rpy:1952
translate spanish date_543638b8:

    # n "Oh, that's okay, I think it's just- {w=0.2}{nw}"
    n "Oh, no pasa nada, creo que es solo- {w=0.2}{nw}"

# game/script.rpy:1956
translate spanish date_81cc9aff:

    # yn "Nick, you bit your lip again! You're bleeding..."
    yn "¡Nick, te mordiste el labio otra vez! Estás sangrando..."

# game/script.rpy:1957
translate spanish date_90b7f3c3:

    # "The guy smiled and licked a drop of blood dripping from his mouth. "
    "El chico sonrió y lamió una gota de sangre que le goteaba de la boca. "

# game/script.rpy:1958
translate spanish date_76abb304:

    # n "Oh? Haha, I know, sweetheart. "
    n "¿Oh? Jaja, lo sé, cielo. "

# game/script.rpy:1959
translate spanish date_05bf9feb:

    # n "Shall we go?"
    n "¿Nos vamos?"

# game/script.rpy:1962
translate spanish date_8984b7b3:

    # "You walked through a crowd of students. You were uncomfortable when you skipped classes, but next to Nick, all anxiety disappeared."
    "Caminaste entre una multitud de estudiantes. Te incomodaba saltarte las clases, pero junto a Nick toda la ansiedad desaparecía."

# game/script.rpy:1963
translate spanish date_c02f7e40:

    # "He always said that he would protect you, that he would be there no matter what. And it was the truth."
    "Siempre decía que te protegería, que estaría ahí pasara lo que pasara. Y era la verdad."

# game/script.rpy:1964
translate spanish date_706c2af3:

    # "Sometimes it was hard for you to imagine that someone loved you so much."
    "A veces te costaba imaginar que alguien te quisiera tanto."

# game/script.rpy:1965
translate spanish date_94463783:

    # "Nick liked listening to you more than he liked talking himself. So when you came out of the building and started winding circles around it, you didn't stop talking for a minute. "
    "A Nick le gustaba más escucharte que hablar él. Así que cuando saliste del edificio y empezaste a dar vueltas a su alrededor, no dejaste de hablar ni un minuto. "

# game/script.rpy:1966
translate spanish date_6fd915ed:

    # "It must have been at least a few hours. You went to a couple of cafes where Nick bought you coffee and sweets."
    "Debieron de ser al menos unas cuantas horas. Fuiste a un par de cafeterías donde Nick te compró café y dulces."

# game/script.rpy:1967
translate spanish date_af20b749:

    # "He usually didn't take anything for himself, preferring an glass of water."
    "Normalmente él no tomaba nada para sí, y prefería un vaso de agua."

# game/script.rpy:1969
translate spanish date_d8f28f2d:

    # "You loved how genuinely happy he was to be around you, but most of the time there was something about him that only you noticed."
    "Te encantaba lo genuinamente feliz que se ponía a tu lado, pero casi siempre había en él algo que solo tú notabas."

# game/script.rpy:1970
translate spanish date_53912b51:

    # "His eyes. They never smiled, no matter how hard you tried to make him happy. They would light up, there would be a spark in them."
    "Sus ojos. Nunca sonreían, por mucho que te esforzaras en hacerlo feliz. Se iluminaban, había una chispa en ellos."

# game/script.rpy:1971
translate spanish date_717e3e23:

    # "But they were always... dead."
    "Pero siempre estaban... muertos."

# game/script.rpy:1972
translate spanish date_0fb6ac23:

    # "It used to scare you, then you were just sad that you couldn't make him really happy, but now you know it's just his specialness. "
    "Antes te asustaba, luego solo te entristecía no poder hacerlo realmente feliz, pero ahora sabes que es simplemente su singularidad. "

# game/script.rpy:1973
translate spanish date_c6cf5e25:

    # "He was full of it. Sometimes you couldn't imagine that a person could combine so many rare features. "
    "Estaba lleno de peculiaridades. A veces no podías imaginar que una persona pudiera reunir tantos rasgos raros. "

# game/script.rpy:1974
translate spanish date_36be388c:

    # "He had pupils of different sizes, he felt almost no pain, his body was cold, he was incredibly tall, and finally he had a twin brother, whom, unfortunately, you have never seen."
    "Tenía pupilas de distinto tamaño, casi no sentía dolor, su cuerpo era frío, era increíblemente alto y, por último, tenía un hermano gemelo al que, por desgracia, nunca has visto."

# game/script.rpy:1975
translate spanish date_a4dcc21c:

    # "You haven't seen his family as a whole. Every time you brought up the subject, his eyes became even more blank. "
    "No has visto a su familia en conjunto. Cada vez que sacabas el tema, sus ojos se quedaban aún más vacíos. "

# game/script.rpy:1976
translate spanish date_3c8a0ed3:

    # "But it was hard. Every time you wondered why you couldn't even see them in a photo, your heart started to ache."
    "Pero era difícil. Cada vez que te preguntabas por qué ni siquiera podías verlos en una foto, el corazón empezaba a dolerte."

# game/script.rpy:1977
translate spanish date_cf97fd45:

    # "It's like he'll never let you get too close to him. Despite all his love, despite all your love in return."
    "Es como si nunca fuera a dejar que te acerques demasiado a él. A pesar de todo su amor, a pesar de todo tu amor a cambio."

# game/script.rpy:1980
translate spanish date_fc4b5e81:

    # yn "Nick... Since today is such an unusual day, maybe you'll make an exception and introduce me to your parents? Or at least show your family photo?.."
    yn "Nick... Ya que hoy es un día tan inusual, ¿por qué no haces una excepción y me presentas a tus padres? ¿O al menos me enseñas una foto de tu familia?.."

# game/script.rpy:1982
translate spanish date_77a7d5bd:

    # "The guy exhaled heavily, his smile fading in an instant. "
    "El chico exhaló con pesadez, su sonrisa se desvaneció en un instante. "

# game/script.rpy:1983
translate spanish date_948d9178:

    # n "We've talked about it so often, haven't we? I'm not angry, but this conversation really hurts me every time. "
    n "Hemos hablado tantas veces de esto, ¿no? No estoy enfadado, pero esta conversación me duele de verdad cada vez. "

# game/script.rpy:1984
translate spanish date_14dda739:

    # "You looked sideways. "
    "Miraste de reojo. "

# game/script.rpy:1985
translate spanish date_4d7bf812:

    # yn "I know, but I really care about that. Do you think they won't accept our... uh... me? "
    yn "Lo sé, pero de verdad me importa. ¿Crees que no aceptarán lo nuestro... eh... a mí? "

# game/script.rpy:1987
translate spanish date_6b8fa36a:

    # n "{cps=30}They didn't even fucking accept their own son!"
    n "{cps=30}¡Ni siquiera aceptaron a su propio hijo, joder!"

# game/script.rpy:1988
translate spanish date_50b51f19:

    # "Nick almost spat those words out and hissed angrily. "
    "Nick casi escupió esas palabras y siseó con rabia. "

# game/script.rpy:1993
translate spanish date_7c61e0e5:

    # n "Sorry, did I scare you, darling? I really don't want you to meet them. We're not family anymore and we never will be. "
    n "Perdón, ¿te asusté, cielo? De verdad no quiero que los conozcas. Ya no somos familia y nunca lo seremos. "

# game/script.rpy:1994
translate spanish date_4b34ea1d:

    # n "I'm sorry that I'm still so weak in terms of my emotions when it comes to talking about my family. "
    n "Siento seguir siendo tan débil emocionalmente cuando se trata de hablar de mi familia. "

# game/script.rpy:1995
translate spanish date_18bebfdf:

    # "But the truth is, you didn't feel scared, even when Nick raised his voice. You were only sorry to see how deep the past had left a scar on him. "
    "Pero la verdad es que no sentiste miedo, ni siquiera cuando Nick alzó la voz. Solo te dolió ver cuán hondo había dejado el pasado su cicatriz en él. "

# game/script.rpy:1996
translate spanish date_5b328830:

    # "A lot of scars. "
    "Muchas cicatrices. "

# game/script.rpy:1997
translate spanish date_6e5588b4:

    # "Which he concealed so diligently. "
    "Que ocultaba con tanto empeño. "

# game/script.rpy:1999
translate spanish date_e5f06f82:

    # yn "It's okay, really! I'm sorry to have broached the subject. Again. I should watch my words more often. "
    yn "¡No pasa nada, de verdad! Perdón por sacar el tema. Otra vez. Debería cuidar más mis palabras. "

# game/script.rpy:2000
translate spanish date_5b1612e8:

    # "Apparently you looked too upset, so Nick leaned over slightly and kissed the top of your head. You both flushed, and he squeezed his wrist hard. "
    "Por lo visto tu expresión era tan triste que Nick se inclinó un poco y te besó en la coronilla. Ambos se sonrojaron, y él se apretó la muñeca con fuerza. "

# game/script.rpy:2002
translate spanish date_f87f196d:

    # n "You're my dearest person, you know that, don't you? "
    n "Eres mi persona más querida, lo sabes, ¿verdad? "

# game/script.rpy:2003
translate spanish date_eaf47359:

    # "You smiled happily. Of course you know, he reminds you of that almost every day. And every time you're happy, it's like you're hearing it for the first time. "
    "Sonreíste feliz. Claro que lo sabes, te lo recuerda casi todos los días. Y cada vez te alegras, como si lo oyeras por primera vez. "

# game/script.rpy:2006
translate spanish date_e2fcfe5e:

    # "You exhaled heavily and seemed silent for a little longer than you expected. "
    "Exhalaste con pesadez y guardaste silencio un poco más de lo que esperabas. "

# game/script.rpy:2007
translate spanish date_d1ef2401:

    # "The guy looked at you a little surprised, seemingly guessing that you thought something bad."
    "El chico te miró un poco sorprendido, adivinando al parecer que pensabas algo malo."

# game/script.rpy:2011
translate spanish date2_3e8eee18:

    # "Nick gently rubbed your head. God... he's such a sweetheart. "
    "Nick te frotó la cabeza con suavidad. Dios... qué ternura de chico. "

# game/script.rpy:2012
translate spanish date2_773003f5:

    # n "Let's talk about good things, shall we? "
    n "Hablemos de cosas buenas, ¿vale? "

# game/script.rpy:2013
translate spanish date2_78f919d0:

    # yn "Yeah, like how I'm about to get kicked out of uni for truancy. "
    yn "Sí, como que estoy a punto de que me echen de la uni por faltar a clase. "

# game/script.rpy:2015
translate spanish date2_54063a69:

    # n "Not while I'm vouching for you! "
    n "¡No mientras yo responda por ti! "

# game/script.rpy:2016
translate spanish date2_687e21cf:

    # "You laughed and lightly pushed Nick in the chest. "
    "Te reíste y le diste un empujoncito a Nick en el pecho. "

# game/script.rpy:2017
translate spanish date2_3d1f8f2f:

    # yn "And what are you going to tell them not to do that? Come on, I want to know those magic words! "
    yn "¿Y qué les vas a decir para que no lo hagan? ¡Venga, quiero saber esas palabras mágicas! "

# game/script.rpy:2018
translate spanish date2_4239f419:

    # n "No words! I'll just smile charmingly at them and... They won't be able to resist!"
    n "¡Nada de palabras! Solo les sonreiré con encanto y... ¡No podrán resistirse!"

# game/script.rpy:2019
translate spanish date2_03d50c4b:

    # yn "Hehe, and if they don't succumb to your charm? "
    yn "Jeje, ¿y si no sucumben a tu encanto? "

# game/script.rpy:2020
translate spanish date2_ab03af22:

    # n "Then I'll have to go to extreme measures. "
    n "Entonces tendré que recurrir a medidas extremas. "

# game/script.rpy:2021
translate spanish date2_2ad7b9e8:

    # yn "And which ones, my hero?"
    yn "¿Y cuáles, mi héroe?"

# game/script.rpy:2023
translate spanish date2_5b024866:

    # n "I'll kill them all! And we'll have a nice dinner. You know how good a cook I am, so it's going to be a wonderful evening. "
    n "¡Los mataré a todos! Y tendremos una buena cena. Ya sabes lo buen cocinero que soy, así que será una noche maravillosa. "

# game/script.rpy:2024
translate spanish date2_9628d25d:

    # "You grinned crookedly. Nick often joked about these things, but you weren't amused by the humor. "
    "Sonreíste torcidamente. Nick bromeaba a menudo sobre estas cosas, pero a ti no te hacía gracia ese humor. "

# game/script.rpy:2025
translate spanish date2_05ad9f20:

    # "Nick realized that his joke didn't really make an impression on you, and began to babble quickly, as he usually did in situations when he said or did something wrong. "
    "Nick se dio cuenta de que su broma no te había causado gran impresión y empezó a parlotear rápidamente, como solía hacer cuando decía o hacía algo mal. "

# game/script.rpy:2026
translate spanish date2_57e0b6ee:

    # "It always amused you that he didn't know how to hide his excitement at all."
    "Siempre te divertía que no supiera esconder su nerviosismo en absoluto."

# game/script.rpy:2027
translate spanish date2_071824a3:

    # "Or maybe he didn't mean to. You were flattered to think that he was just completely open to you about his emotions and feelings. "
    "O quizá no era intencionado. Te halagaba pensar que simplemente era totalmente abierto contigo respecto a sus emociones y sentimientos. "

# game/script.rpy:2029
translate spanish date2_edf5d781:

    # n "Oh, it's so late already!"
    n "¡Oh, ya es tan tarde!"

# game/script.rpy:2030
translate spanish date2_bed9e6f3:

    # n "I don't think we'll make it to the movies. Especially since I didn't buy tickets in advance, I'm sorry... "
    n "No creo que lleguemos al cine. Sobre todo porque no compré las entradas con antelación, perdón... "

# game/script.rpy:2031
translate spanish date2_f0131022:

    # "You giggled and rubbed Nick's cheek. You noticed long ago that the sun had gone down, but you didn't want to go to a crowded place so much that someone would interrupt your conversation. "
    "Te reíste y le frotaste la mejilla a Nick. Hacía rato que habías notado que el sol se había puesto, pero no querías ir a un lugar concurrido donde alguien interrumpiera su conversación."

# game/script.rpy:2032
translate spanish date2_2a73ad88:

    # yn "It's okay, we'll go another time. Maybe you could come and stay with me tonight. I still want a kiss."
    yn "No pasa nada, iremos otro día. Quizá podrías venir a quedarte conmigo esta noche. Todavía quiero un beso."

# game/script.rpy:2034
translate spanish date2_bca7d99a:

    # "Nick blushed thickly, his pupils dilated. He covered his face."
    "Nick se sonrojó con fuerza, con las pupilas dilatadas. Se cubrió la cara."

# game/script.rpy:2036
translate spanish date2_4cccb682:

    # n "{sc}Ah! A kiss...{/sc} God, why did I make you this promise? Though perhaps today is the day when I can finally do it. "
    n "{sc}¡Ah! Un beso...{/sc} Dios, ¿por qué te hice esta promesa? Aunque quizá hoy sea el día en que por fin pueda hacerlo. "

# game/script.rpy:2037
translate spanish date2_e6bd4d65:

    # "You giggled again. He's so big and even slightly intimidating, the blush on his cheeks over such silliness almost made you cry with laughter. "
    "Volviste a reírte. Es tan grande y hasta un poco intimidante, el rubor de sus mejillas por semejante tontería casi te hizo llorar de risa."

# game/script.rpy:2039
translate spanish date2_f236c7f5:

    # "But still you went towards your house. The guy didn't resist, only occasionally started muttering something to himself."
    "Pero aun así fuiste hacia tu casa. El chico no se resistió, solo de vez en cuando empezaba a murmurar algo para sí."

# game/script.rpy:2043
translate spanish date2_7894648f:

    # "You were a little dizzy. Usually Nick didn't stay late at your place and now you were trembling with anticipation of how you would spend this evening."
    "Tenías un poco de mareo. Normalmente Nick no se quedaba hasta tarde en tu casa y ahora temblabas de expectación por cómo pasarían esta noche."

# game/script.rpy:2045
translate spanish date2_574b5a96:

    # "You entered the room and you looked at Nick, frozen at the entrance. A sad smile shone on his face, illuminated by the moonlight."
    "Entraste en la habitación y miraste a Nick, paralizado en la entrada. Una triste sonrisa brillaba en su rostro, iluminado por la luz de la luna."

# game/script.rpy:2048
translate spanish date2_7b38f893:

    # "He was clutching his wrist, as if restraining himself from something, as if he was in pain. You looked into his eyes and realized that they were glistening with approaching tears."
    "Se agarraba la muñeca, como conteniéndose de algo, como si sintiera dolor. Lo miraste a los ojos y comprendiste que brillaban por las lágrimas que se acercaban."

# game/script.rpy:2049
translate spanish date2_513273f1:

    # "Was he really so upset by this situation? Or your last conversation?"
    "¿De verdad le había afectado tanto esta situación? ¿O su última conversación?"

# game/script.rpy:2050
translate spanish date2_6d8e907e:

    # yn "Nick! Everything okay? I'm sorry, did I offend you in some way?"
    yn "¡Nick! ¿Todo bien? Perdón, ¿te ofendí de alguna manera?"

# game/script.rpy:2051
translate spanish date2_3d8c617c:

    # "Nick exhaled heavily and took a step back."
    "Nick exhaló con pesadez y retrocedió un paso."

# game/script.rpy:2052
translate spanish date2_88a28c55:

    # n "No. It's all good. I am well... We just got here so fast. I'm sorry that everything is coming to an end so quickly."
    n "No. Todo está bien. Estoy bien... Es solo que llegamos tan rápido. Lamento que todo esté llegando a su fin tan pronto."

# game/script.rpy:2053
translate spanish date2_cb85b484:

    # n "{cps=250}Already waiting? Let me say goodbye and you'll see what you want. {w=0.1}{nw}"
    n "{cps=250}¿Ya esperando? Déjame despedirme y verás lo que quieres. {w=0.1}{nw}"

# game/script.rpy:2054
translate spanish date2_9c1293be:

    # yn "What? The end? What are you talking about?"
    yn "¿Qué? ¿El final? ¿De qué hablas?"

# game/script.rpy:2057
translate spanish date2_18358020:

    # "Nick took a few wide steps and gently grabbed your chin. Just a couple of seconds he stroked your face with his fingers and looked at you with such sincere love that your legs gave way."
    "Nick dio unos pasos largos y te tomó suavemente de la barbilla. Solo un par de segundos te acarició el rostro con los dedos y te miró con un amor tan sincero que se te doblaron las piernas."

# game/script.rpy:2058
translate spanish date2_e454c44f:

    # "Then he leaned over and kissed you on the cheek."
    "Luego se inclinó y te besó en la mejilla."

# game/script.rpy:2059
translate spanish date2_500b704f:

    # "He didn't immediately pull away, starting to kiss all the other parts of your face. Nose, forehead, cheeks, eyes and finally you pulled him to you, kissing him on the lips."
    "No se apartó enseguida, y empezó a besar todas las demás partes de tu cara. Nariz, frente, mejillas, ojos, y por fin lo atrajiste hacia ti, besándolo en los labios."

# game/script.rpy:2060
translate spanish date2_7fa3b9cf:

    # "His mouth was hot. You felt the piercing in his tongue, which he passed over your lips."
    "Su boca estaba caliente. Sentiste el piercing de su lengua, que pasó por tus labios."

# game/script.rpy:2061
translate spanish date2_a7a5b5ef:

    # "Your heart was beating wildly, drowning out the noise of your rapid breathing and noisy exhalations. He ran his hands over your body, stroking your back and hips. It was as if you were slowly melting from his touch."
    "Tu corazón latía desbocado, ahogando el ruido de tu respiración acelerada y de tus ruidosos suspiros. Él recorrió tu cuerpo con las manos, acariciándote la espalda y las caderas. Era como si te derritieras lentamente con su contacto."

# game/script.rpy:2062
translate spanish date2_386bf627:

    # "He pressed his hot body against you and threw you on the bed without breaking the kiss. Before you know it, he's already left you in your underwear."
    "Apretó contra ti su cuerpo ardiente y te lanzó sobre la cama sin romper el beso. Antes de que te dieras cuenta, ya te había dejado en ropa interior."

# game/script.rpy:2063
translate spanish date2_a869da80:

    # "But you didn't feel shy around him, letting him examine and touch you."
    "Pero no sentías vergüenza ante él, dejando que te examinara y te tocara."

# game/script.rpy:2064
translate spanish date2_4603ca99:

    # "Nick went down to your neck, giving you gentle kisses and tickling hot breath. The guy ran his tongue over it, which made you involuntarily moan."
    "Nick bajó hasta tu cuello, dándote suaves besos y soplando un aliento caliente que hacía cosquillas. El chico pasó la lengua por él, lo que te hizo gemir involuntariamente."

# game/script.rpy:2065
translate spanish date2_83f473e3:

    # "He went down lower, making you shudder and blush. When the tip of his tongue went over your stomach, you grabbed his hair and pulled it roughly out of an overabundance of feelings."
    "Bajó aún más, haciéndote estremecer y sonrojar. Cuando la punta de su lengua recorrió tu estómago, le agarraste el pelo y se lo tiraste con fuerza, ante el exceso de sensaciones."

# game/script.rpy:2066
translate spanish date2_35e956db:

    # "The guy just smiled and considered it a challenge, starting to cover the bottom of your stomach with hot wet kisses."
    "El chico solo sonrió y lo tomó como un desafío, empezando a cubrirte la parte baja del vientre de besos calientes y húmedos."

# game/script.rpy:2067
translate spanish date2_a11f7586:

    # "He spread your legs apart, not giving you the opportunity to hide from him."
    "Te separó las piernas, sin darte oportunidad de esconderte de él."

# game/script.rpy:2069
translate spanish date2_0c6fb702:

    # "Nick sat between your legs, gently pressing against one of them and squeezing the skin on it with his fingers. His hot breath burned you, made you shiver. Both of you have been waiting for this for a long time and now your bodies were shaking with anticipation."
    "Nick se sentó entre tus piernas, presionando suavemente una de ellas y apretando la piel con los dedos. Su aliento caliente te quemaba, te hacía estremecer. Ambos llevaban mucho tiempo esperando esto y ahora sus cuerpos temblaban de expectación."

# game/script.rpy:2070
translate spanish date2_9f315b93:

    # "He didn't take his eyes off you, his gaze literally burned through you. It was again one of his games, in which you seem to lose again soon."
    "No apartaba los ojos de ti, su mirada te atravesaba literalmente. Era de nuevo uno de sus juegos, en el que, al parecer, volverás a perder pronto."

# game/script.rpy:2071
translate spanish date2_38358625:

    # "His face, wet with sweat, gently rubbed against you, but the drops seemed to evaporate from the skin that was heated to the limit. With his other hand, he slowly reached for your underwear, running his long, still cold fingers under it..."
    "Su rostro, empapado de sudor, se frotaba suavemente contra ti, pero las gotas parecían evaporarse de la piel calentada al límite. Con la otra mano alcanzó lentamente tu ropa interior, deslizando bajo ella sus largos dedos, todavía fríos..."

# game/script.rpy:2072
translate spanish date2_92aa2972:

    # "...from which you shuddered and let out a moan. "
    "...lo que te hizo estremecer y soltar un gemido. "

# game/script.rpy:2073
translate spanish date2_da3e9ac8:

    # "He touched you brazenly, without holding back, and did not look away. And it was maddening."
    "Te tocaba con descaro, sin contenerse, y no apartaba la mirada. Y era enloquecedor."

# game/script.rpy:2075
translate spanish date2_082ae5de:

    # n "Do you see that spark in my eyes? See this madness? It's all because of you. Only because of you!"
    n "¿Ves esa chispa en mis ojos? ¿Ves esta locura? Todo es por ti. ¡Solo por ti!"

# game/script.rpy:2076
translate spanish date2_b1a28d3d:

    # "The guy smiled and snuggled closer."
    "El chico sonrió y se acurrucó más cerca."

# game/script.rpy:2078
translate spanish date2_4dc4e8f5:

    # n "Oh, my God... isn't this a dream anymore?"
    n "Oh, Dios mío... ¿ya no es un sueño?"

# game/script.rpy:2079
translate spanish date2_de9c8db4:

    # "Nick's tongue ran along the inside of your thigh, leaving a wet trail and making you moan, he did not stop caressing you with his other hand. The guy exhaled noisily and bit the tender skin noticeably..."
    "La lengua de Nick recorrió el interior de tu muslo, dejando un rastro húmedo y haciéndote gemir, sin dejar de acariciarte con la otra mano. El chico exhaló ruidosamente y mordió la piel tierna hasta dejar marca..."

# game/script.rpy:2080
translate spanish date2_18fe860a:

    # "...after which he pulled away and licked the small cuts left from his fangs."
    "...tras lo cual se apartó y lamió los pequeños cortes que dejaron sus colmillos."

# game/script.rpy:2081
translate spanish date2_ad6b5197:

    # "This pain was different, it only inflamed the desire that already overwhelmed you."
    "Este dolor era distinto, solo avivaba el deseo que ya te desbordaba."

# game/script.rpy:2082
translate spanish date2_08dadcc7:

    # yn "Mhh, Nick... Nick, please..."
    yn "Mhh, Nick... Nick, por favor..."

# game/script.rpy:2083
translate spanish date2_ac962aea:

    # "You felt how wet you became, the guy easily caressed you at the bottom, occasionally removing his hand with a grin to enjoy your dissatisfied moan and the way you raise your hips, demanding continued caresses."
    "Sentiste cómo la humedad te empapaba; el chico te acariciaba con facilidad abajo, retirando de vez en cuando la mano con una sonrisa para disfrutar de tu gemido de insatisfacción y de cómo alzabas las caderas, exigiendo que continuaran las caricias."

# game/script.rpy:2085
translate spanish date2_cd20165c:

    # n "I hope you won't regret it, sweetheart. I'll show you all my love, we'll become closer than ever..."
    n "Espero que no te arrepientas, cielo. Te mostraré todo mi amor, seremos más cercanos que nunca..."

# game/script.rpy:2086
translate spanish date2_2c1292e7:

    # "Nick began to breathe faster and bit into your flesh again. His caresses became a little more aggressive."
    "Nick empezó a respirar más rápido y volvió a morderte la carne. Sus caricias se volvieron un poco más agresivas."

# game/script.rpy:2087
translate spanish date2_827584d4:

    # "You were going crazy with the desire for more, and his seemingly weightless touches only made you sob."
    "Enloquecías de deseo por más, y sus toques aparentemente ingrávidos solo te hacían sollozar."

# game/script.rpy:2088
translate spanish date2_a23d2c43:

    # "But then you noticed that even after Nick's fangs sank into your skin and bit through it, he didn't pull away."
    "Pero entonces notaste que incluso después de que los colmillos de Nick se hundieran en tu piel y la atravesaran, no se apartaba."

# game/script.rpy:2089
translate spanish date2_271ff094:

    # yn "Ugh! Nick, It's already getting hurt... Aaah, the game has gone too far..."
    yn "¡Ugh! Nick, ya me está doliendo... Aaah, el juego se ha ido demasiado lejos..."

# game/script.rpy:2092
translate spanish date2_322163f2:

    # "But he didn't hear, the guy clenched his jaws harder and harder until you started kicking in pain. Tears sprang from your eyes, and a scream escaped from your throat, it seemed to you as if you heard your tissues being torn."
    "Pero no oía; el chico apretaba la mandíbula cada vez más fuerte hasta que empezaste a patalear de dolor. Las lágrimas te brotaron de los ojos y un grito escapó de tu garganta; te pareció oír cómo se desgarraban tus tejidos."

# game/script.rpy:2093
translate spanish date2_52cbc8b3:

    # "Your body was shaking with insane pain, it didn't obey, you could not resist and for a second it went dark in your eyes. Your leg felt like it was on fire, you could hardly feel Nick stroking you soothingly."
    "Tu cuerpo temblaba de un dolor demencial, no te obedecía, no pudiste resistirte y por un segundo todo se oscureció ante tus ojos. Sentías la pierna en llamas, apenas notabas que Nick te acariciaba para calmarte."

# game/script.rpy:2094
translate spanish date2_b49509dc:

    # "The hellish pain has passed, the heat has been followed by a cold passing through your whole body."
    "El dolor infernal pasó; al calor le siguió un frío que recorrió todo tu cuerpo."

# game/script.rpy:2096
translate spanish date2_a0e50c41:

    # "You were able to look down, hoping that it was all just a dream, but a terrible picture appeared before you."
    "Pudiste mirar hacia abajo, con la esperanza de que todo fuera solo un sueño, pero ante ti apareció una imagen terrible."

# game/script.rpy:2098
translate spanish date2_b1b53943:

    # "It was more like a nightmare: you really lacked a piece of meat, which was now in the mouth of a smiling Nick."
    "Era más bien una pesadilla: realmente te faltaba un trozo de carne, que ahora estaba en la boca de un Nick sonriente."

# game/script.rpy:2099
translate spanish date2_33a5bed9:

    # n "Fuck, do you feel it too? This heat and excitement... Your flesh is in me! I've tasted you, you're just incredible, oh my God..."
    n "Joder, ¿tú también lo sientes? Este calor y esta excitación... ¡Tu carne está dentro de mí! Te he probado, eres simplemente increíble, oh, Dios mío..."

# game/script.rpy:2100
translate spanish date2_6f00bbc1:

    # "The guy was choking with excitement, but you couldn't stop crying from pain and fear."
    "El chico se ahogaba de excitación, pero tú no podías dejar de llorar de dolor y miedo."

# game/script.rpy:2102
translate spanish date2_7e4e3517:

    # n "Oh? Does it hurt? I'm sorry, I'll help you now."
    n "¿Oh? ¿Te duele? Perdona, te ayudaré ahora mismo."

# game/script.rpy:2103
translate spanish date2_c71defda:

    # "The feeling of hellish discomfort has not disappeared anywhere, but then you felt something... pleasure? Your brain seems to have stopped perceiving that you are being eaten as something terrible, out of the norm. Now it was a kind of manifestation of love."
    "La sensación de malestar infernal no había desaparecido, pero entonces sentiste algo... ¿placer? Tu cerebro parece haber dejado de percibir que te están comiendo como algo terrible, fuera de lo normal. Ahora era una especie de manifestación de amor."

# game/script.rpy:2104
translate spanish date2_91fb50c0:

    # "You touched your chest, your heart was beating painfully, the heat from it spread through your veins. Consciousness clouded, you began to breathe rapidly, as if you were covered with a fever."
    "Te tocaste el pecho, el corazón latía dolorosamente, el calor se extendía por tus venas. La consciencia se nubló, empezaste a respirar rápido, como si te cubriera la fiebre."

# game/script.rpy:2105
translate spanish date2_e5c8b385:

    # "Your whole body is filled with excitement and an unexpected thirst for blood."
    "Todo tu cuerpo se llena de excitación y de una inesperada sed de sangre."

# game/script.rpy:2107
translate spanish date2_46943ad6:

    # "You clung to Nick's neck and ran your nails into it, feeling warm blood spreading under them."
    "Te aferraste al cuello de Nick y le clavaste las uñas, sintiendo la sangre tibia extenderse bajo ellas."

# game/script.rpy:2108
translate spanish date2_b32c6c02:

    # "The guy moaned and leaned forward, helping you tear his skin. Hot blood dripped onto your body, the air was saturated with the sweet smell of iron."
    "El chico gimió y se inclinó hacia delante, ayudándote a desgarrarle la piel. La sangre caliente goteó sobre tu cuerpo, el aire se saturó del dulce olor a hierro."

# game/script.rpy:2110
translate spanish date2_f60dfceb:

    # "Nick arched his back and after another moan joined your lips, alternating passionate kisses with rough bites. You wound deeper and deeper, your hands were completely covered in blood."
    "Nick arqueó la espalda y, tras otro gemido, unió sus labios a los tuyos, alternando besos apasionados con mordiscos bruscos. Lo herías cada vez más hondo, tenías las manos completamente cubiertas de sangre."

# game/script.rpy:2111
translate spanish date2_c2b0cd05:

    # "He was shaking violently, you heard the clang of iron and realized that he finally got rid of his pants, which painfully hid his excitement."
    "Temblaba con violencia, oíste el tintineo del metal y comprendiste que por fin se había librado de los pantalones, que ocultaban dolorosamente su excitación."

# game/script.rpy:2112
translate spanish date2_7026d48c:

    # "Nick gave you access to his neck, which you happily began to bite through. The guy bit his wrist and took off his wet underwear, passing icy fingers over his cock."
    "Nick te ofreció su cuello, que empezaste a morder con deleite. El chico se mordió la muñeca y se quitó la ropa interior mojada, pasando sus dedos helados por su miembro."

# game/script.rpy:2113
translate spanish date2_4643a5a1:

    # "You felt hot from the realization that now you really tasted each other. You are in love and this form of your love was above any feelings. You're shivering."
    "Sentiste calor al darte cuenta de que ahora de verdad se saboreaban el uno al otro. Se aman y esta forma de su amor estaba por encima de cualquier sentimiento. Estás temblando."

# game/script.rpy:2114
translate spanish date2_3b42208f:

    # n "Come on, I want to hear what's on your mind right now, darling. Don't be shy~"
    n "Vamos, quiero oír lo que piensas ahora mismo, cielo. No te cortes~"

# game/script.rpy:2115
translate spanish date2_61aa89ff:

    # "You licked your lips and exhaled, almost moaning, said:"
    "Te lamiste los labios y exhalaste, casi gimiendo, y dijiste:"

# game/script.rpy:2116
translate spanish date2_f32c24b3:

    # yn "I beg... I want to tear you to pieces, I want to get my hands under your skin. Nick..."
    yn "Te lo suplico... Quiero destrozarte, quiero meter las manos bajo tu piel. Nick..."

# game/script.rpy:2117
translate spanish date2_942a7238:

    # "The guy pressed his hips against you and with a contented exhalation rubbed his excited hot cock against your stomach."
    "El chico presionó sus caderas contra ti y, con una exhalación de satisfacción, frotó su excitado miembro caliente contra tu vientre."

# game/script.rpy:2118
translate spanish date2_506802b2:

    # n "{cps=22}Well done~{/cps=22} You deserve a reward for your obedience, for your sincerity. Especially down here. You're so wet, fuck..."
    n "{cps=22}Muy bien~{/cps=22} Mereces una recompensa por tu obediencia, por tu sinceridad. Sobre todo aquí abajo. Cómo te has humedecido, joder..."

# game/script.rpy:2119
translate spanish date2_3463b28b:

    # "You sincerely begged him to continue. Oh God, it was a sincere feeling of love. The guy smiled and simultaneously with licking your wound again began to caress you below. Your body was struck by an electric current, you arched your back and clenched your legs, as if hiding."
    "Le suplicaste sinceramente que continuara. Oh, Dios, era un sentimiento sincero de amor. El chico sonrió y, a la vez que lamía tu herida, volvió a acariciarte abajo. Tu cuerpo fue recorrido por una corriente eléctrica, arqueaste la espalda y apretaste las piernas, como escondiéndote."

# game/script.rpy:2120
translate spanish date2_3c05b476:

    # "The guy laughed and bit the bare tissues of your leg without stopping the stimulation with his hand."
    "El chico rio y mordió los tejidos expuestos de tu pierna sin detener el estímulo con la mano."

# game/script.rpy:2121
translate spanish date2_baacbf51:

    # n "You came... Oh. it's so cute. I couldn't even dream of it... I'll eat you, I swear, I won't leave a piece! You will beg me for it, you will cry out in pain, and I will consider it my highest reward. I love you!"
    n "Te corriste... Oh, qué ternura. Ni siquiera podía soñarlo... ¡Te comeré, lo juro, no dejaré ni un trozo! Me lo suplicarás, gritarás de dolor, y lo consideraré mi mayor recompensa. ¡Te amo!"

# game/script.rpy:2122
translate spanish date2_5358fb8c:

    # "You were overwhelmed with hot desires, clouding your mind: to put your hands into his warm insides, to break his bones — pain, like love. You wanted to be closer, to break him, to tear him apart, to show your true feelings that go beyond the boundaries of normal."
    "Te desbordaban cálidos deseos que nublaban tu mente: meter las manos en su cálido interior, romperle los huesos; dolor, como amor. Querías estar más cerca, destrozarlo, despedazarlo, mostrar tus verdaderos sentimientos, que van más allá de los límites de lo normal."

# game/script.rpy:2123
translate spanish date2_a741d30b:

    # "Was that what he felt all the time? Because of this crazy feeling he didn't want to touch you? You bit your lip. It drive you crazy to think that someone want you so much."
    "¿Era eso lo que él sentía todo el tiempo? ¿Por este sentimiento enloquecedor no quería tocarte? Te mordiste el labio. Te enloquece pensar que alguien te desee tanto."

# game/script.rpy:2125
translate spanish date2_934e23d3:

    # "Nick scratched your skin, ate your flesh and drank your blood, which is why you flooded the room with loud moans and sobs. His hand continued to stimulate your sensitive spots, which caused your body to be shot through with discharges."
    "Nick te arañó la piel, se comió tu carne y bebió tu sangre, por lo que llenaste la habitación de fuertes gemidos y sollozos. Su mano seguía estimulando tus puntos sensibles, lo que hacía que descargas recorrieran tu cuerpo."

# game/script.rpy:2126
translate spanish date2_f4687637:

    # "You could come from just the pain and the sight of your lover devouring your flesh."
    "Podrías llegar al clímax solo con el dolor y la visión de tu amante devorando tu carne."

# game/script.rpy:2127
translate spanish date2_cc56f6e7:

    # "The guy breathed hotly in your ear and almost mockingly held his cock between your legs without going further."
    "El chico respiró caliente en tu oído y, casi con burla, mantuvo su miembro entre tus piernas sin ir más allá."

# game/script.rpy:2128
translate spanish date2_2784aacc:

    # "From time to time, Nick took his hand away and, mixing your lubricant with blood, bent down and licked his lips, after that, for the show, he ran his fingers over his erect cock, which you wanted to feel so much in yourself."
    "De vez en cuando, Nick retiraba la mano y, mezclando tu lubricación con sangre, se inclinaba y se lamía los labios; después, para exhibirse, se pasó los dedos por su miembro erecto, que tanto deseabas sentir dentro de ti."

# game/script.rpy:2129
translate spanish date2_a7f9e360:

    # "Because of this spectacle — a heated Nick, smeared with your blood, torn flesh and his clouded, full of desire look — you, without noticing it, began to quietly beg the guy to finally fuck you..."
    "Ante este espectáculo —un Nick acalorado, manchado de tu sangre, de carne desgarrada y con su mirada nublada, llena de deseo— empezaste, sin darte cuenta, a rogarle en voz baja al chico que por fin te follara..."

# game/script.rpy:2130
translate spanish date2_5c250355:

    # "...tear out another piece of meat and finally give the opportunity to tear Nick apart."
    "...que arrancara otro trozo de carne y por fin te diera la oportunidad de despedazar a Nick."

# game/script.rpy:2132
translate spanish date2_4e41292f:

    # "The guy briefly moved closer to you and, after a short hot kiss, went down again, settling between your legs."
    "El chico se acercó brevemente a ti y, tras un corto beso ardiente, volvió a bajar, acomodándose entre tus piernas."

# game/script.rpy:2134
translate spanish date2_c55fd067:

    # "Your head was spinning, probably from all the lost blood, but no less from excitement and heat."
    "La cabeza te daba vueltas, probablemente por toda la sangre perdida, pero no menos por la excitación y el calor."

# game/script.rpy:2135
translate spanish date2_13f732f9:

    # "You didn't hold back your moans, your body shook every time Nick's tongue passed over your sensitive spots. You no longer felt shame, only insane pleasure and an unquenchable thirst for the continuation of his touches."
    "No contenías tus gemidos, tu cuerpo se estremecía cada vez que la lengua de Nick pasaba por tus puntos sensibles. Ya no sentías vergüenza, solo un placer enloquecedor y una sed insaciable de que continuaran sus caricias."

# game/script.rpy:2136
translate spanish date2_2364234a:

    # "You heard only the wet sounds that filled the room, your moans and the heavy breathing of an excited Nick."
    "Solo oías los sonidos húmedos que llenaban la habitación, tus gemidos y la respiración pesada de un Nick excitado."

# game/script.rpy:2137
translate spanish date2_31ecd21f:

    # "Nick kept touching you with his free hand, scratching and tearing your skin. You screamed when you felt the blade in your stomach, but at the same moment you shook in orgasm."
    "Nick seguía tocándote con la mano libre, arañando y desgarrándote la piel. Gritaste cuando sentiste la hoja en el estómago, pero en ese mismo instante temblaste en un orgasmo."

# game/script.rpy:2138
translate spanish date2_fd60b245:

    # "The guy never left you for a second, giving you the most beautiful pain and the most unbearable pleasure at the same time."
    "El chico no te dejó ni un segundo, dándote el dolor más hermoso y el placer más insoportable a la vez."

# game/script.rpy:2140
translate spanish date2_0cf8ede2:

    # "With every second your vision became more and more blurry, you slowly began to lose touch with reality. Now you realize why Nick looked so devastated."
    "Con cada segundo tu visión se volvía más y más borrosa, poco a poco empezabas a perder el contacto con la realidad. Ahora comprendes por qué Nick parecía tan destrozado."

# game/script.rpy:2141
translate spanish date2_711c467e:

    # "You enjoyed every second of this evening, remembering every wound given to you by your lover."
    "Disfrutaste cada segundo de esta noche, recordando cada herida que te hizo tu amante."

# game/script.rpy:2144
translate spanish date2_2911ed26:

    # yn "Nick, I love you!"
    yn "¡Nick, te amo!"

# game/script.rpy:2145
translate spanish date2_3a2fd248:

    # yn "Please don't leave a single piece of me. I bequeath to you my body, my soul, my blood and my love. Enjoy it and remember it until your very last breath."
    yn "Por favor, no dejes ni un trozo de mí. Te lego mi cuerpo, mi alma, mi sangre y mi amor. Disfrútalo y recuérdalo hasta tu último aliento."

# game/script.rpy:2146
translate spanish date2_2f3eb336:

    # n "Of course, my love. You will remain mine forever. We will become one."
    n "Claro, mi amor. Seguirás siendo mío para siempre. Nos haremos uno."

# game/script.rpy:2148
translate spanish date2_08a3216d:

    # "You touched Nick's hair for the last time, after which your consciousness sank into darkness. Forever."
    "Tocaste el pelo de Nick por última vez, tras lo cual tu consciencia se hundió en la oscuridad. Para siempre."

# game/script.rpy:2150
translate spanish date2_38b708da:

    # "{cps=2}. . ."
    "{cps=2}. . ."

# game/script.rpy:2153
translate spanish date2_c9e65e8d:

    # n "Well... It seems that this was the end."
    n "Bueno... Parece que este fue el final."

# game/script.rpy:2154
translate spanish date2_a5d2bd56:

    # n "It upsets me, it really upsets. But nothing lasts forever."
    n "Me disgusta, me disgusta de verdad. Pero nada dura para siempre."

# game/script.rpy:2156
translate spanish date2_09ef4de5:

    # n "It is not in my power to prolong our love, to stay here a little longer. With you."
    n "No está en mi mano prolongar nuestro amor, quedarme aquí un poco más. Contigo."

# game/script.rpy:2157
translate spanish date2_80a33f28:

    # n "You're probably a little embarrassed that I'm talking to you and not to MC, but you were the one who managed all this, weren't you? And since you're here, listening to me, it means your feelings are as strong as mine."
    n "Probablemente te dé un poco de vergüenza que te hable a ti y no a MC, pero fuiste tú quien se encargó de todo esto, ¿verdad? Y como estás aquí, escuchándome, significa que tus sentimientos son tan fuertes como los míos."

# game/script.rpy:2158
translate spanish date2_e0a3a5bd:

    # n "Ha ha, though what am I talking about! It will only be a little fun for you, but I will never forget it. I exist, I feel only when you are here. You are my whole world, my whole life!"
    n "Jaja, ¡aunque de qué estoy hablando! Para ti solo será un poco de diversión, pero yo nunca lo olvidaré. Existo, siento, solo cuando tú estás aquí. ¡Eres todo mi mundo, toda mi vida!"

# game/script.rpy:2161
translate spanish date2_5d55e9c6:

    # n "I love you! Thank you for all the time you spent with me. Unfortunately, I wasn't a typical romantic, but this world belongs to me, so... Since you have stayed, then you are satisfied with my manifestation of love. Mad love."
    n "¡Te amo! Gracias por todo el tiempo que pasaste conmigo. Por desgracia, no fui un romántico típico, pero este mundo me pertenece, así que... Ya que te has quedado, entonces mi manera de demostrarte amor te ha bastado. Amor loco."

# game/script.rpy:2162
translate spanish date2_becfc955:

    # n "Maybe we'll meet again. Who knows? Thank you for everything."
    n "Quizá volvamos a vernos. ¿Quién sabe? Gracias por todo."

# game/script.rpy:2163
translate spanish date2_52c2767e:

    # n "You know, I've done a lot of bad things... That's why I'm here. Where I can't hurt anyone, where we can both enjoy the blood."
    n "Sabes, he hecho muchas cosas malas... Por eso estoy aquí. Donde no puedo hacerle daño a nadie, donde ambos podemos disfrutar de la sangre."

# game/script.rpy:2164
translate spanish date2_bcfc7df2:

    # n "Ah, I can talk forever! You are the one and only for me. Be happy, [name]!"
    n "¡Ah, podría hablar por siempre! Eres lo único para mí. ¡Sé feliz, [name]!"

translate spanish strings:

    # game/script.rpy:122
    old "Put on your weird necklace"
    new "Ponerte tu extraño collar"

    # game/script.rpy:155
    old "Help him"
    new "Ayudarlo"

    # game/script.rpy:282
    old "Run home as soon as possible"
    new "Correr a casa lo antes posible"

    # game/script.rpy:336
    old "{sc}G i v e u p{/sc}"
    new "{sc}R e n d i r s e{/sc}"

    # game/script.rpy:452
    old "Continue"
    new "Continuar"

    # game/script.rpy:454
    old "Open your eyes"
    new "Abrir los ojos"

    # game/script.rpy:492
    old "OF COURSE NOT, WHAT THE FUCK!"
    new "¡CLARO QUE NO, QUÉ CARAJO!"

    # game/script.rpy:494
    old "Being nice and obey"
    new "Ser amable y obedecer"

    # game/script.rpy:502
    old "SHUT UP!"
    new "¡CÁLLATE!"

    # game/script.rpy:508
    old "What the hell was that..."
    new "Qué demonios fue eso..."

    # game/script.rpy:575
    old "Thank you so much for the gift! You are so wonderful and thoughtful"
    new "¡Muchas gracias por el regalo! Eres tan maravilloso y atento"

    # game/script.rpy:686
    old "Another answer? Seriously? You are so heartless"
    new "¿Otra respuesta? ¿En serio? Qué falta de corazón tienes"

    # game/script.rpy:719
    old "Gather your strength and run away"
    new "Reunir fuerzas y huir"

    # game/script.rpy:779
    old "Quietly turn around and go the other way"
    new "Girarte en silencio e ir por otro camino"

    # game/script.rpy:824
    old "Forget about that"
    new "Olvidar eso"

    # game/script.rpy:906
    old "Talk to him a little bit."
    new "Hablar un poco con él."

    # game/script.rpy:1097
    old "Quickly say hello and go to the nurse."
    new "Saludar rápido e ir a la enfermería."

    # game/script.rpy:1193
    old "I'm not in the mood today"
    new "Hoy no estoy de humor"

    # game/script.rpy:1327
    old "...go away and leave the two of you alone."
    new "...irte y dejarlos a los dos solos."

    # game/script.rpy:1452
    old "{sc}Don't open the door{/sc}"
    new "{sc}No abrir la puerta{/sc}"

    # game/script.rpy:1573
    old "Eat (Correct answer)"
    new "Comer (Respuesta correcta)"

    # game/script.rpy:1578
    old "Further to be ungrateful (WRONG ANSWER)"
    new "Seguir mostrando ingratitud (RESPUESTA INCORRECTA)"

    # game/script.rpy:1590
    old "Okay"
    new "Vale"

    # game/script.rpy:1593
    old "Fuck off"
    new "Vete a la mierda"

    # game/script.rpy:1616
    old "...intervene between the two of you and then go home together."
    new "...intervenir entre los dos y luego irse juntos a casa."

    # game/script.rpy:1718
    old "Scream"
    new "Gritar"

    # game/script.rpy:1749
    old "Silent"
    new "Guardar silencio"

    # game/script.rpy:1789
    old "Start a new life"
    new "Empezar una nueva vida"

    # game/script.rpy:1857
    old "Try again"
    new "Intentarlo de nuevo"

    # game/script.rpy:1875
    old "Forget about it"
    new "Olvidarlo"

    # game/script.rpy:1907
    old "Sure, I'd love to spend time with you"
    new "Claro, me encantaría pasar tiempo contigo"

    # game/script.rpy:1909
    old "No, I'm sorry, study comes first"
    new "No, lo siento, primero están los estudios"

    # game/script.rpy:1919
    old "Yes"
    new "Si"

    # game/script.rpy:1921
    old "No"
    new "No"

    # game/script.rpy:1926
    old "Yes, because I love you, because you're so handsome and polite and don't want to kill me at all! "
    new "Sí, porque te amo, ¡porque eres tan guapo y educado y no quieres matarme en absoluto! "

    # game/script.rpy:1979
    old "The last hope"
    new "La última esperanza"

    # game/script.rpy:2166
    old "I love you, Nick"
    new "Te quiero, Nick"
    
    old "Who are u today huh?"
    new "¿Quién eres hoy, eh?"
    
    old "Who are you?"
    new "¿Quién eres?"
    
    old "Lecturer"
    new "Docente"


