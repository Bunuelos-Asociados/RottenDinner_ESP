﻿# TODO: Translation updated at 2026-11-11 21:31

translate spanish strings:

    # game/options.rpy:15
    old "Rotten Dinner"
    new "Rotten Dinner"

    # game/options.rpy:32
    old "Rotten Dinner\n\nMy thanks to everyone who supported me! I love you all, you can't imagine how much each comment and like meant to me! I want to say special thanks to my best friend, without whom I would not have started working on this novel — Evdogoriy Vagina-Risovalnik As well as to the guys from Twitter: Maddy Moreau (@MaddyMoreau_), KAINE-CHAN (@KainechanUwU), Skentric (@eskentric) Your comments and posts have been incredibly helpful to me! And also thanks for ninety percent of the music to the site melobytes.com\n\nAuthor: wwwormeow (https://wwwormeow.itch.io/) Twitter: Chervyatochina (@wwwormeow) Telegram: wwwormeow"
    new "Rotten Dinner\n\n¡Gracias a todos los que me apoyaron! Los quiero a todos, ¡no se imaginan lo mucho que significó para mí cada comentario y cada like! Quiero dar las gracias especialmente a mi mejor amigo, sin quien no habría empezado a trabajar en esta novela: Evdogoriy Vagina-Risovalnik. También a la gente de Twitter: Maddy Moreau (@MaddyMoreau_), KAINE-CHAN (@KainechanUwU) y Skentric (@eskentric). ¡Sus comentarios y publicaciones me ayudaron muchísimo! Y gracias también por el noventa por ciento de la música al sitio melobytes.com\n\nAutor: wwwormeow (https://wwwormeow.itch.io/) Twitter: Chervyatochina (@wwwormeow) Telegram: wwwormeow"