﻿# TODO: Translation updated at 2026-11-11 21:31

translate spanish strings:

    # game/screens.rpy:256
    old "Back"
    new "Atrás"

    # game/screens.rpy:257
    old "History"
    new "Historial"

    # game/screens.rpy:258
    old "Skip"
    new "Saltar"

    # game/screens.rpy:259
    old "Auto"
    new "Auto"

    # game/screens.rpy:260
    old "Save"
    new "Guardar"

    # game/screens.rpy:261
    old "Q.Save"
    new "G. rápido"

    # game/screens.rpy:262
    old "Q.Load"
    new "C. rápida"

    # game/screens.rpy:263
    old "Prefs"
    new "Ajustes"

    # game/screens.rpy:322
    old "End Replay"
    new "Terminar repetición"

    # game/screens.rpy:326
    old "Main Menu"
    new "Menú principal"

    # game/screens.rpy:481
    old "Return"
    new "Volver"

    # game/screens.rpy:558
    old "About"
    new "Acerca de"

    # game/screens.rpy:565
    old "Version [config.version!t]\n"
    new "Versión [config.version!t]\n"

    # game/screens.rpy:571
    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Hecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:602
    old "Load"
    new "Cargar"

    # game/screens.rpy:607
    old "Page {}"
    new "Página {}"

    # game/screens.rpy:607
    old "Automatic saves"
    new "Guardados automáticos"

    # game/screens.rpy:607
    old "Quick saves"
    new "Guardados rápidos"

    # game/screens.rpy:649
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %B %d %Y, %H:%M"

    # game/screens.rpy:649
    old "empty slot"
    new "espacio vacío"

    # game/screens.rpy:666
    old "<"
    new "<"

    # game/screens.rpy:669
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:672
    old "{#quick_page}Q"
    new "{#quick_page}R"

    # game/screens.rpy:678
    old ">"
    new ">"

    # game/screens.rpy:724
    old "Preferences"
    new "Ajustes"

    # game/screens.rpy:735
    old "Display"
    new "Pantalla"

    # game/screens.rpy:736
    old "Window"
    new "Ventana"

    # game/screens.rpy:737
    old "Fullscreen"
    new "Pantalla completa"

    # game/screens.rpy:742
    old "Unseen Text"
    new "Texto no visto"

    # game/screens.rpy:743
    old "After Choices"
    new "Después de opciones"

    # game/screens.rpy:744
    old "Transitions"
    new "Transiciones"

    # game/screens.rpy:757
    old "Text Speed"
    new "Velocidad del texto"

    # game/screens.rpy:761
    old "Auto-Forward Time"
    new "Tiempo de avance automático"

    # game/screens.rpy:768
    old "Music Volume"
    new "Volumen de la música"

    # game/screens.rpy:775
    old "Sound Volume"
    new "Volumen de los sonidos"

    # game/screens.rpy:781
    old "Test"
    new "Probar"

    # game/screens.rpy:785
    old "Voice Volume"
    new "Volumen de las voces"

    # game/screens.rpy:796
    old "Mute All"
    new "Silenciar todo"

    # game/screens.rpy:915
    old "The dialogue history is empty."
    new "El historial de diálogos está vacío."

    # game/screens.rpy:974
    old "Help"
    new "Ayuda"

    # game/screens.rpy:983
    old "Keyboard"
    new "Teclado"

    # game/screens.rpy:984
    old "Mouse"
    new "Mouse"

    # game/screens.rpy:987
    old "Gamepad"
    new "Control"

    # game/screens.rpy:1000
    old "Enter"
    new "Enter"

    # game/screens.rpy:1001
    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."

    # game/screens.rpy:1004
    old "Space"
    new "Espacio"

    # game/screens.rpy:1005
    old "Advances dialogue without selecting choices."
    new "Avanza el diálogo sin seleccionar opciones."

    # game/screens.rpy:1008
    old "Arrow Keys"
    new "Teclas de flecha"

    # game/screens.rpy:1009
    old "Navigate the interface."
    new "Navega por la interfaz."

    # game/screens.rpy:1012
    old "Escape"
    new "Esc"

    # game/screens.rpy:1013
    old "Accesses the game menu."
    new "Abre el menú del juego."

    # game/screens.rpy:1016
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1017
    old "Skips dialogue while held down."
    new "Salta el diálogo mientras se mantiene presionada."

    # game/screens.rpy:1020
    old "Tab"
    new "Tab"

    # game/screens.rpy:1021
    old "Toggles dialogue skipping."
    new "Activa o desactiva el salto de diálogo."

    # game/screens.rpy:1024
    old "Page Up"
    new "Re Pág"

    # game/screens.rpy:1025
    old "Rolls back to earlier dialogue."
    new "Retrocede a diálogos anteriores."

    # game/screens.rpy:1028
    old "Page Down"
    new "Av Pág"

    # game/screens.rpy:1029
    old "Rolls forward to later dialogue."
    new "Avanza a diálogos posteriores."

    # game/screens.rpy:1033
    old "Hides the user interface."
    new "Oculta la interfaz de usuario."

    # game/screens.rpy:1037
    old "Takes a screenshot."
    new "Toma una captura de pantalla."

    # game/screens.rpy:1041
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Activa o desactiva la {a=https://www.renpy.org/l/voicing}autovoz{/a} de asistencia."

    # game/screens.rpy:1045
    old "Opens the accessibility menu."
    new "Abre el menú de accesibilidad."

    # game/screens.rpy:1051
    old "Left Click"
    new "Clic izquierdo"

    # game/screens.rpy:1055
    old "Middle Click"
    new "Clic central"

    # game/screens.rpy:1059
    old "Right Click"
    new "Clic derecho"

    # game/screens.rpy:1063
    old "Mouse Wheel Up\nClick Rollback Side"
    new "Rueda del mouse hacia arriba\nClic en el lado de retroceso"

    # game/screens.rpy:1067
    old "Mouse Wheel Down"
    new "Rueda del mouse hacia abajo"

    # game/screens.rpy:1074
    old "Right Trigger\nA/Bottom Button"
    new "Gatillo derecho\nA/Botón inferior"

    # game/screens.rpy:1078
    old "Left Trigger\nLeft Shoulder"
    new "Gatillo izquierdo\nBotón superior izquierdo"

    # game/screens.rpy:1082
    old "Right Shoulder"
    new "Botón superior derecho"

    # game/screens.rpy:1087
    old "D-Pad, Sticks"
    new "Cruceta, palancas"

    # game/screens.rpy:1091
    old "Start, Guide"
    new "Start, Guía"

    # game/screens.rpy:1095
    old "Y/Top Button"
    new "Y/Botón superior"

    # game/screens.rpy:1098
    old "Calibrate"
    new "Calibrar"

    # game/screens.rpy:1210
    old "Skipping"
    new "Saltando"

    # game/screens.rpy:1433
    old "Menu"
    new "Menu"
